// frontend.h
//
// FrontEnd class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __FRONTEND_GRID_H
#define __FRONTEND_GRID_H

#include <string>
#include "typedefs.h"
#include "channeltype.h"

namespace gpstk { class ConfDataReader; }

class FrontEnd {
  struct SignalParameters {
    // Intermediate frequency of the signal, in Hz
    f64 FREQ_IF_HZ_;
    // Code phase bias, in meters.  Subtract this value from differential
    // pseudorange measurements (rho - rhoRef) to approximate the difference
    // in pseudorange due to ionospheric delay, where rho is the pseudorange
    // of this object's signal and rhoRef is the pseudorange of the reference
    // signal (the reference signal is usually assumed to be GPS L1 C/A).
    f64 CODE_PHASE_BIAS_METERS_;
    // Indicates high (-1) or low (1) side mixing
    s32 PLL_SIGN_FPLL_;
    s32 PADDING_;
  };
public:
  FrontEnd();
  ~FrontEnd(){cleanup();}
  
  void createBobynDualFreq();
  void createMitelDualFreq();
  // Populate FrontEndConfig with data read from a configuration file by a
  // ConfDataReader.  This function requires the GPSTk and so is not meant to
  // be invoked on the DSP platform.  Its implementation can be found in
  // importconfiguration.cpp.
  void importConfiguration(gpstk::ConfDataReader * cr, 
                           const std::string& name);
  void importConfiguration(const u32 * pa, s32& index);
  void exportConfiguration(u32 * pa, s32& index)const;
  bool isInitialized() const { return isInitialized_; }
  std::string name() const { return name_; }
  s64 SAMPLE_FREQ_NUMERATOR() const { return SAMPLE_FREQ_NUMERATOR_; }
  s32 SAMPLE_FREQ_DENOMINATOR() const { return SAMPLE_FREQ_DENOMINATOR_; }
  s32 QUANTIZATION() const { return QUANTIZATION_; }
  s32 NUM_SUPPORTED_SIGNAL_TYPES() const { return NUM_SUPPORTED_SIGNAL_TYPES_; }
  const SignalType* SUPPORTED_SIGNAL_TYPES() const 
  { return SUPPORTED_SIGNAL_TYPES_; }
  f64 FREQ_IF_HZ(SignalType signalType) const; 
  s32 TWO_SIGMAIQSQ(SignalType signalType) const; 
  s32 PLL_SIGN_FPLL(SignalType signalType) const; 
  f64 CODE_PHASE_BIAS_METERS(SignalType signalType) const;
  
private:
  void cleanup();
  void createArrays();
  s32 getIndex(SignalType signalType) const;
  
  bool isInitialized_;
  std::string name_;
  // It is assumed that the sampling frequency of any RF front end supported
  // by this code can be expressed in Hz as a ratio of two integers.  For
  // example, the sampling frequency for the Zarlink/Plessey front end is
  // 40e6/7 Hz, which would correspond to SAMPLE_FREQ_NUMERATOR = 40e6 and
  // SAMPLE_FREQ_DENOMINATOR = 7.  It is further assumed that double precision
  // is sufficient to represent the time within a single interval of
  // SAMPLE_FREQ_DENOMINATOR seconds.
  s64 SAMPLE_FREQ_NUMERATOR_; 
  s32 SAMPLE_FREQ_DENOMINATOR_;
  // The number of bits used in the front end's quantization scheme.
  s32 QUANTIZATION_;
  s32 NUM_SUPPORTED_SIGNAL_TYPES_;
  // An array listing the supported signal types.  In the arrays that follow,
  // data at the iith index correspond to the signal type at the iith index.
  SignalType* SUPPORTED_SIGNAL_TYPES_;
  SignalParameters* signalParameters_;
};

#endif
