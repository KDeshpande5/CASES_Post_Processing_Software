// masterconfig.h
//
// MasterConfig class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __MASTER_CONFIG_GRID_H
#define __MASTER_CONFIG_GRID_H

#include <string>
#include <vector>
#include "typedefs.h"
#include "parameters.h"
#include "channeltype.h"
#include "signaltype.h"
#include "navsolconfig.h"

namespace gpstk { class ConfDataReader; }
class BankConfig;
class FrontEnd;
class CarrierGenerator;
class OversampledCodeGenerator;
class ReportDataLogConfig;
class Bank;
class DataBitManager;

// MasterConfig is the master configuration object for the GRID.  Its defaults
// configure the GRID for standard operation.
class MasterConfig {
public:
  enum {
    SYNC_SEQUENCE = 0xDEADBEEF
  };
  MasterConfig();
  ~MasterConfig();
  void initDefault();
  // Populate MasterConfig with data read from a configuration file by a
  // ConfDataReader.  This function requires the GPSTk and so is not meant to
  // be invoked on the DSP platform.  Its implementation can be found in
  // importconfiguration.cpp.
  void importConfiguration(gpstk::ConfDataReader * cr);
  // Populate MasterConfig with data read from an array of ints.
  s32 importConfiguration(const u32 * pa);
  // Export MasterConfig to an array of ints. Use pa = NULL to determine the
  // number of ints the object requires without writing to an actual array.
  s32 exportConfiguration(u32 * pa)const;
  // Populate the dataBitManager
  ReturnValue importDataBits(SignalType signalType, const u32* bitArray);
  void exportDataBits(SignalType signalType, u32* bitArray, u32 &arrSize);
  void exportScintParams(u32* bitArray, u32 &arrSize);
  u32 configurationIndex()const{return configurationIndex_;}
  BankConfig const * const * bankConfigArray()const{return bankConfigArray_;}
  s32 nBankConfigs()const{return nBankConfigs_;}
  const NavSolConfig * navSolConfig()const{return &navSolConfig_;}
  bool loadedCachedParameters()const{return loadedCachedParameters_;}

private:
  s32  frontEndIndex(const std::string& name)const;
  void setDependentParameters();
  void checkParameterValidity();
  void createDefaultFrontEnds();
  void createDefaultBanks();
  void destroyBankConfigArray();
  void destroyFrontEndArray();
  void destroyCarrierGeneratorArray();
  void destroyOversampledCodeGeneratorArray();
  void destroyDataBitManagerArray();
  // Creates a BankConfig object based on the specified channel type with
  // default parameters. Make sure to delete the object when you are done 
  // with it. The implementation of this function does not reside in
  // masterconfig.cpp. Each incarnation of the GRID receiver will have its
  // own implementation.
  BankConfig * newBankConfig(SignalType signalType);
  
  // An index that gets incremented each time there is a change in the value
  // of some element in MasterConfig.  Objects that depend on MasterConfig can
  // poll configurationIndex_ periodically to determine whether they need to
  // update their local configurations.
  u32 configurationIndex_;
  // BaseTime gpsWeekReference
  s32 gpsWeekReference_;
  // Pointer to an array of pointers to BankConfig objects
  BankConfig ** bankConfigArray_;
  s32 nBankConfigs_;
  // Pointer to an array of FrontEnd objects
  FrontEnd * frontEndArray_;
  s32 nFrontEnds_;
  // Pointer to an array of CarrierGenerator objects.  The code in
  // setOptimalCarrierGeneratorConfiguration will automatically choose the
  // minimum required number of CarrierGenerator objects.
  CarrierGenerator ** carrierGeneratorArray_;
  s32 nCarrierGenerators_;
  // Vector of pointers to OversampledCodeGenerator objects. 
  std::vector<OversampledCodeGenerator *> oversampledCodeGeneratorArray_;
  NavSolConfig navSolConfig_;   
  // Pointer to an array of DataBitManager objects.  There will be as many
  // DataBitManager objects as there are BankConfig objects.
  DataBitManager * dataBitManagerArray_;
  // Indicates if cached parameters were loaded.
  bool loadedCachedParameters_;
};  

#endif

