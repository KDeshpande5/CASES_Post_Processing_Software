// serialutil.h
//
// Serialization utility functions
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __SERIALUTIL_GRID_H
#define __SERIALUTIL_GRID_H

#include "typedefs.h"

namespace serialutil {
  
  void getbin(const u32 * pa, s32& index, u8 * val, s32 size);
  void gets32(const u32 * pa, s32& index, s32& val);
  void gets64(const u32 * pa, s32& index, s64& val);
  void getu32(const u32 * pa, s32& index, u32& val);
  void getu64(const u32 * pa, s32& index, u64& val);
  void getf32(const u32 * pa, s32& index, f32& val);
  void getf64(const u32 * pa, s32& index, f64& val);
  
  void setbin(u32 * pa, s32& index, const u8 * val, s32 size);
  void sets32(u32 * pa, s32& index, s32 val);
  void sets64(u32 * pa, s32& index, s64 val);
  void setu32(u32 * pa, s32& index, u32 val);
  void setu64(u32 * pa, s32& index, u64 val);
  void setf32(u32 * pa, s32& index, f32 val);
  void setf64(u32 * pa, s32& index, f64 val);
  
} // namespace

#endif
 
