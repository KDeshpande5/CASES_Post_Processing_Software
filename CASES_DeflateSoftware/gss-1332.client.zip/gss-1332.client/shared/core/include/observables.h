// observables.h
//
// Observables classes
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

// The Observables objects bundle signal observables for a particular channel
// type.  All derived observables objects inherit from ObservablesBase.

#ifndef __OBSERVABLES_GRID_H
#define __OBSERVABLES_GRID_H

#include "parameters.h"
#include "basetime.h"
#include "channeltype.h"

class Observables {
public:
  virtual ~Observables(){}
  virtual void init(SignalType signalType) = 0;
  static void init_tOffset();
  static BaseTime tMeasurement() {return tMeasurement_;}
  static BaseTime tOffset() {return tOffset_;}
  static bool tOffsetValid() {return tOffsetValid_;}
  SignalType signalType() const {return signalType_;}
  s32 nChannels() const {return nChannels_;}
  static void set_tMeasurement(const BaseTime& tMeasurement); 
  static void set_tOffset(const BaseTime& tOffset); 
  static void set_tOffsetValid(bool tOffsetValid); 
  void set_signalType(SignalType signalType); 
  void set_nChannels(s32 nChannels);
  
protected:
  SignalType signalType_;
  s32 nChannels_;
private:
/* NOTE: tMeasurement, tOffset, and tOffsetValid are declared as static
     variables because by RINEX convention all GNSS observables should apply
     at the same measurement time and we wish to extend this convention to all
     observables, GNSS or otherwise. All observables are presumed to be
     traceable to the same receiver reference oscillator.*/
  // Measurement time at which the observables apply, according to the
  // receiver clock. This measurement time is not fixed up with tOffset; it is
  // simply a conversion from the raw number of samples elapsed.
  static BaseTime tMeasurement_;
  // Offset that gets added to tMeasurement to bring tMeasurement close
  // to GPS time.  Receiver time as used in the calculation of pseudorange
  // includes this offset. 
  static BaseTime tOffset_;
  // Indicates whether (true) or not (false) tOffset is valid
  static bool tOffsetValid_;
};

#endif
