// binhelper.h
// 
// Binflate helper functions
// 
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __BINHELPER_GRID_H
#define __BINHELPER_GRID_H 

#include "parameters.h"
#include <iostream>
#include <fstream>

bool readFile(std::istream& logFile, char * buffer, u32 bytes, s32 waitTimeout,
              bool verboseLevel);
ReturnValue checkVersionAndAlign(std::fstream& binFile, s32 waitTimeout,
                                 bool verboseLevel);
bool syncAndStripDummies(std::string fIn, bool verboseLevel, std::string& fOut);

#endif
