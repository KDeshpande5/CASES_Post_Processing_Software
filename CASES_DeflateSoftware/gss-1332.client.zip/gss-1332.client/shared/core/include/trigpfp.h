// trigpfp.h
//
// Header file for the fixed-point trigonometric functions that are based on
// pic arithmetic.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __TRIGPFP_GRID_H
#define __TRIGPFP_GRID_H

#include "parameters.h"

s64  TRIGP_atan(const s32 x);
s64  TRIGP_atan2(const s64 Y, const s64 X);
void TRIGP_fillAtanTable(void);
void TRIGP_fillSinCosTables(void);
s16 TRIGP_sin(const s64 theta);
s16 TRIGP_cos(const s64 theta);

#endif
