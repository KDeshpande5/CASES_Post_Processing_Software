// carriergenerator.h
//
// Header file for the carrier generator class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __CARRIER_GENERATOR_GRID_H
#define __CARRIER_GENERATOR_GRID_H

#include "parameters.h"

// CarrierGeneratorConfig is the Carrier Generator configuration object.
// Its data members define the configuration of the Carrier Generator
class CarrierGeneratorConfig {
public:
  // Intermediate carrier frequency (Hz)
  f64 InterFreqHz;
  // Front-end sampling interval (s)
  f64 DeltaT;
  // Nominal sub-accumulation period (s)
  f64 NomSubAccumPeriod;
  // Nominal minimum Doppler search frequency (Hz).  The actual minimum
  // Doppler search frequency, fDoppMin, is within dfDopp/2 of fDoppMinNom.
  f64 NomMinDopplerFreqHz;
  // Nominal maximum Doppler search frequency (Hz).  The actual maximum
  // Doppler search frequency, fDoppMin, is within dfDopp/2 of fDoppMaxNom.
  f64 NomMaxDopplerFreqHz;
  // The Doppler search step interval (Hz)
  f64 DopplerFreqStepHz;
};

class CarrierGenerator {
public:
  CarrierGenerator();
  virtual ~CarrierGenerator();
  
  // Configuration function
  ReturnValue init(const CarrierGeneratorConfig& carrierCeneratorConfig);
public:
  s32 NWORD_PER_SUBACCUM() const { return NWORD_PER_SUBACCUM_; }
  s32 NUM_DOPPLER_FREQS() const { return NUM_DOPPLER_FREQS_; }
  // INPUTS
  // fk         frequency in cycles/sample scaled by SF_B
  // thetak     phase in cycles/sample scaled by SF_B
  // if_offset  IF offset in cycles/sample scaled by SF_B
  virtual void load(s64 fk, s64 thetak, s64 if_offset,
                    u32 * __restrict sinS, u32 * __restrict cosS,
                    u32 * __restrict sinM, u32 * __restrict cosM) const = 0;
  virtual void load(s64 fk, s64 thetak, s64 if_offset,
                    u32 * __restrict sinS, u32 * __restrict sinM) const = 0;
  const CarrierGeneratorConfig& config() const { return co_; }
protected:
  static void quantTwoBit(f64 val, f64 thresh, u32& S, u32& M);
  static void genSin(s64& phi, const s64 phi_step,
                     u32& packedSinS, u32& packedSinM);
  static void genSinCos(s64& phi, const s64 phi_step,
                        u32& packedSinS, u32& packedSinM,
                        u32& packedCosS, u32& packedCosM);
  virtual ReturnValue initSpecialized(){return RETVAL_SUCCESS;}
  
  // CarrierGenerator configuration object
  CarrierGeneratorConfig co_;
  // The number of Nbpw-bit words allocated for each local carrier replica at
  // each Doppler frequency
  s32 NWORD_PER_SUBACCUM_;
  // The number of Doppler search frequencies in the local carrier arrays.
  s32 NUM_DOPPLER_FREQS_;
  // The actual minimum Doppler frequency.
  f64 MIN_DOPPLER_FREQ_HZ_;
  // The actual maximum Doppler frequency.
  f64 MAX_DOPPLER_FREQ_HZ_;
  // The intermediate frequency in cycles/sample scaled by SF_B
  s64 FP_INTER_FREQ_;
  s32 MIN_DOPPLER_FREQ_PIC_;
  s32 DOPPLER_FREQ_STEP_PIC_; 
  s32 DOPPLER_FREQ_STEP_PIC_HALF_;
};

#endif


 
	      
  




