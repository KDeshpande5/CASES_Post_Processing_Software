// txid.h
//
// TxId (transmitter identifier) class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#ifndef __TXID_GRID_H
#define __TXID_GRID_H

#include "typedefs.h"
#include "system.h"

// TxId is used to identify the transmitter whose signal is being tracked.
// Transmitters are associated with a unique system and number combination.
// For example, GPS PRN 15 has system GPS and number 15.

class TxId {
public:
  enum TxIdExtrema {
    GPS_SVID_MIN = 1,
    GPS_SVID_MAX = 32,
    GPS_FEEDBACK_SVID = 0,
    GPS_MAX_NUM_SVS = 32
  };
  
  TxId();
  ~TxId(){};
  TxId(System system, s32 number);
  TxId(const TxId& txId);
  void init();
  bool isValid() const;
  TxId& operator = (const TxId& txId);
  TxId operator++(int);
  System system() const {return system_;}
  s32 number() const {return number_;}
  void set_system(System system){system_ = system;}
  void set_number(s32 number){number_ = number;}

private:
  System system_;
  s32 number_;
};

bool operator == (const TxId& txId1, const TxId& txId2);
bool operator != (const TxId& txId1, const TxId& txId2);



#endif
