// parameters.h
//
// GRID configuration file containing all constants whose value must be known
// at compile time for static allocation of arrays.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

// EXPLANATORY NOTES: (e.g., E1, E2, ...) are found at the bottom of this
// file.

#include "typedefs.h"
#include "gridassert.h"
#include "masterconfig.h"
#include "parametersextern.h"

#ifndef __PARAMETERS_GRID_H
#define __PARAMETERS_GRID_H

//======= Circular buffers
#ifdef DSPARCH
enum{
  CBUFFSIZEL = 11,
  DBUFFSIZE = 1024  // See note (E1)
};   
#else
enum{
  CBUFFSIZEL = 19
};
#endif

//======= General
enum {
  CBUFFSIZE = (0x1<<CBUFFSIZEL), // Must be power of 2 and at least DBUFFSIZE/4 
  CBUFFSIZEM = CBUFFSIZE - 1,    // Masking value
  NUM_CACODE_CHIPS = 1023,     
  NUM_CLCODE_CHIPS = 767250,
  NUM_CMCODE_CHIPS = 10230,
  NUM_CACODES_PER_DATA_BIT = 20,
  NUM_CDMA_CHIPS_PER_SYMBOL = 256,
  NUM_SYMBOLS_PER_SYNC_FRAME = 128,
  DELTA_PILOT_OFFSET_CHIPS = 64,
  GPS_WEEK_MIN  = 0,
  GPS_WEEK_MAX  = 8192,
  SEC_PER_WEEK  = 604800,
  MAX_TRUNC_TOW = 100800,
  GPS_WEEK_ROLLOVER = 1024,
  BITS_PER_WORDL = 5,                 // LOG2 of bits per word (32 bits per word)
  BITS_PER_WORD = (0x1<<BITS_PER_WORDL),
  BITS_PER_WORDM = BITS_PER_WORD - 1, // Masking value
  SAMPS_PER_CBUFFER = BITS_PER_WORD*CBUFFSIZE,
  SAMPS_PER_CBUFFERM = SAMPS_PER_CBUFFER-1, // Masking value
  REP_BUFFSIZEL = 11,
  REP_BUFFSIZE = (0x1<<REP_BUFFSIZEL), // size of report buffer in bytes
  REP_BUFFSIZEM = REP_BUFFSIZE -1,
  SYNC_LENGTH = 32
};

//======= FFT-based acquisition 
enum {
  FFT_NFFTL = 13,                // log2 of NFFT
  FFT_NFFT = (0x1<<FFT_NFFTL)
};

//======= Channel 
enum {
  CH_DATA_BIT_BUFFER_SIZE =   660,  // 660 to accommodate two complete TLM/HOW pairs
  CH_DATA_BITS_PER_SUBFRAME = 300
};

//======= Fixed-point scaling factors
// For further explanation of the scaling factors, see note E2 below.
enum ScalingFactors {
  SF_SL = 14,  // 14 is adequate
  SF_HL = 20,  // 20 is adequate
  SF_TL = 24,  // 24 is adequate; must be greater than or equal to SF_HL; Used to scale tFracIndexk.
  SF_AL = 29,  // 29 is adequate; overflow at 31.  Used for calculating NCA, the number of samples in a C/A code period.
  SF_IL = 23,  // 23 is adequate; used as the x-coordinate scaling factor in the linear interpolation function
  SF_QL = 3,   // 3 is adequate; used as the y-coordinate scaling factor in the linear interpolation function
  SF_PL = 33,  // 33 is adequate; SF_PL + SF_FL must be <= 64
  SF_FL = 17,  // 16 is adequate; SF_PL + SF_FL must be <= 64
  SF_DDSL = 16,
  SF_BL = 60   // overflow at 63; used as phase scaling factor in carrier gen.
};

//======= Enumeration types meant to be widely accessible
enum PingPong {
  PING,
  PONG
};
enum ReturnValue {
  RETVAL_SUCCESS = 0,
  RETVAL_FAILURE = -1
};
enum ChannelStatus {
  // Channel has been created and is in its zero state
  STATUS_NULL,
  // Channel has been primed for acquisition but has not yet acquired
  STATUS_ALLOCATED,
  STATUS_ACQUIRED,     
  STATUS_SYMBOL_LOCK,     
  STATUS_FREQ_LOCK,    
  STATUS_PHASE_LOCK,   
  STATUS_DATA_LOCK, 
  NUM_CHANNEL_STATUS_VALUES,
  // Initialization value
  UNDEFINED_CHANNEL_STATUS  
};
enum SolverResult {
  SOL_CONVERGED, 
  SOL_FAILED_TO_CONVERGE, 
  SOL_TOO_FEW_SVS_AFTER_PRUNING,
  SOL_ITAR_VIOLATION,
  SOL_CONVERGED_BUT_LARGE_RESIDUAL,
  SOL_TOO_FEW_SVS
};

#endif

// Explanatory notes:
//
// (E1) Must be a power of 2 greater than or equal to 1024.  The 1024
//      constraint is required because apparently smaller sizes cause the HWI
//      to want to execute faster than allowed by functions that block it (the
//      FFT function).  At least this is my current hypothesis.  Also, values
//      larger than 1024 require less servicing of the EDMA-triggered HWI (see
//      edma.cpp), but cursory testing shows that larger values don't lead to
//      a significant improvement in overall CPU usage.  Thus, 1024 appears to
//      be a good value.  At this value, the HWI gets serviced approximately
//      every 1.4 ms.  
//
// (E2) SF_SL is log2 of the "standard" scaling factor, in units per
//      units. SF_HL is log2 of the high precision scaling factor used for
//      internal PLL variables.  SF_TL is log2 of the time scaling factor, in
//      units per second.
//
//      Scaling of phases and frequencies is based on subintervals of a cycle,
//      called pics.  One cycle is equivalent to SF_P pics.  SF_PL is log2 of
//      SF_P.  Frequency is measured in pics per front-end sampling interval.
//      Phase resolution is 1/SF_P cycles, and frequency resolution is 1 pic
//      per sample.  Choosing SF_PL = 34 ensures that phase errors remain
//      below 0.004 cycles after propagation over an accumulation interval 10
//      seconds long (the longest coherent accumulation we've ever
//      contemplated) at a sampling interval of 175 ns.  This should be
//      adequate for all practical purposes.
//
//      SF_FL is log2 of SF_F, which is the scaling factor for fractional
//      pics.  Fractional pics are used, for example, in propagating the
//      intermediate frequency fIF to get the nominal signal carrier phase.
//      If only pics and not fractional pics were used in this case, then
//      errors equivalent to a substantial fraction of a cycle build up after
//      a few hours. Setting SF_FL + SF_PL = 50 ensures that the frequency
//      resolution in fIF is good to better than 10 nano-Hz for a sampling
//      interval of 175 ns.  This would lead to a less than 0.0002-cycle error
//      buildup in the internal representation of the nominal signal carrier
//      phase over an interval of 8 hours.
   

