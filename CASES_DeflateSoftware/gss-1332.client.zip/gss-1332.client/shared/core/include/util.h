// util.h
//
// General utility functions
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __UTIL_GRID_H
#define __UTIL_GRID_H

#include "typedefs.h"

namespace util {
  
  // isPresent
  //
  // Return true if value is present in array of size length; otherwise return
  // false.
  //
  template <class T>
  bool isPresent(const T value, const T array[], const s32 length){

    for(s32 ii=0;ii<length;ii++)
      if(array[ii] == value)
        return true;
    return false;
  }

  // findIndex
  //
  // Return index of first instance of value if value is present in array
  // of size length; otherwise return -1.
  //
  template <class T>
  s32 findIndex(const T value, const T array[], const s32 length) {
    for(s32 ii=0;ii<length;ii++)
      if(array[ii] == value)
        return ii;
    return -1;
  }

  template <class T>
  T getMax (T a, T b) {
    return (a>b)? a : b;
  }
  template <class T>
  T getMin (T a, T b) {
    return (a<b)? a : b;
  }

  // Note: We'll leave these sign functions un-templated for fast execution
  inline
  s32 sign(const s32 X){ 
    return (X >= 0 ? 1 : -1); 
  }
  inline
  s64 sign(const s64 X){ 
    return (X >= 0 ? 1 : -1); 
  }
  inline
  f32 sign(const f32 X){ 
    return (X >= 0.0F ? 1.0F : -1.0F); 
  }
  inline
  f64 sign(const f64 X){ 
    return (X >= 0.0 ? 1.0 : -1.0); 
  }
  
  inline 
  u32 shiftroundu32(const u32 val, const s32 il, const s32 fl){
    const u32 imf_half = 1U<<(il-fl-1);
    return (val+imf_half)>>(il-fl);
  }
  
  inline 
  s32 shiftrounds32(const s32 val, const s32 il, const s32 fl){
    const s32 imf_half = 1<<(il-fl-1);
    return (val+imf_half)>>(il-fl);
  }

  inline 
  s64 shiftrounds64(const s64 val, const s32 il, const s32 fl){
    const s64 imf_half = static_cast<s64>(1)<<(il-fl-1);
    return (val+imf_half)>>(il-fl);
  }

 
  void clearDisplayScreen();
    
} // namespace

#endif
