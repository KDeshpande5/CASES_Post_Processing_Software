// system.h
//
// System enumerations
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#ifndef __SYSTEM_GRID_H
#define __SYSTEM_GRID_H

// Each radionavigation signal is broadcast by a specific system.  System
// enumerates the possible systems for the GRID receiver.
enum System {
  GPS,
  GALILEO,
  GLONASS,
  CDMA,
  NUM_SYSTEMS,
  UNDEFINED_SYSTEM  // Initialization value
};

#endif



