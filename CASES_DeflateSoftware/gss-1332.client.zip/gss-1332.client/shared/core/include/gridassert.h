// gridassert.h
//
// Customized ASSERT functions for the GRID receiver
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __GRIDASSERT_GRID_H
#define __GRIDASSERT_GRID_H

// The header file assert.h is defined both in Code Composer Studio and in the
// gcc standard library.  Hence, the following mapping of the ASSERT macro
// works for real-time- and post-processing.  To disable assertions, define
// the macro NDEBUG before including assert.h.

#ifdef DSPARCH
#define NDEBUG  // Uncomment to disable ASSERTs
#endif

#include <assert.h>
#define ASSERT(condition__) assert(condition__)


#endif
