// basetime.h
//
// BaseTime class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __BASETIME_GRID_H
#define __BASETIME_GRID_H

#include "parameters.h"

// BaseTime offers a common representation of time for use within GRID
class BaseTime {
public:
  BaseTime(){ init();}
  BaseTime(s32 week, s32 secondsOfWeek, f64 fractionOfSecond);
  ~BaseTime(){}
  BaseTime(const BaseTime& right);
  void init();
  s32 disambiguateGpsWeek(s32 WN);
  static s32 gpsWeekReference() {return gpsWeekReference_;}
  static void set_gpsWeekReference(s32 gpsWeekReference)
  {gpsWeekReference_ = gpsWeekReference;}
  static bool ensureApproximateGpsWeekReference(s32 leapSecond, s32 WN);
  ReturnValue set(s32 week, s32 secondsOfWeek, f64 fractionOfSecond);
  ReturnValue setWithTruncatedSampleTime(const BaseTime& ref,
                                         const u64 tIndex,
                                         const s32 tFracIndex,
                                         const s64 sampFreqNumerator, 
                                         const s32 sampFreqDenominator);
  ReturnValue setWithSampleTime(const u64 tIndex,const s32 tFracIndex,
                                const s64 sampFreqNumerator, 
                                const s32 sampFreqDenominator);
  ReturnValue setWithNavDataTime(const u32 week,const u32 truncTOW,
                                 const u32 iiDataBit,const u32 iiSubSym, 
                                 const f64 secPerSubaccum);
  void get(s32& week, s32& secondsOfWeek, f64& fractionOfSecond) const;
  s32 getWeek() const {return week_;}
  s32 getSecondsOfWeek() const {return secondsOfWeek_;}
  f64 getFractionOfSecond() const {return fractionOfSecond_;}
  BaseTime& operator=(const BaseTime& right);
  BaseTime& addSeconds(f64 seconds);
  BaseTime operator-(const BaseTime& right) const;
  BaseTime operator+(const BaseTime& right) const;
  bool operator==(const BaseTime& right) const;
  bool operator!=(const BaseTime& right) const;
  
private:
  // gpsWeekReference is an approximate value of the unambiguous GPS week
  // number that is used to disambiguate the 10-bit (modulo GPS_WEEK_ROLLOVER)
  // GPS week number received in the GPS L1 C/A navigation data bit stream.
  // Disambiguation will be successful whenever gpsWeekReference is within 512
  // weeks of the true unambiguous GPS week number. The value of
  // gpsWeekReference may be loaded from flash memory on startup.  It is
  // periodically checked -- and if necessary, corrected -- by the function
  // BaseTime::ensureApproximateGpsWeekReference.
  static s32 gpsWeekReference_;
  // The unambiguous GPS week.
  s32 week_;
  // Integer seconds elapsed since the start of the GPS week.
  s32 secondsOfWeek_;
  // Fraction of a second beyond the integer secondsOfWeek_.
  f64 fractionOfSecond_;
  BaseTime& add(s32 week,s32 secondsOfWeek,f64 fractionOfSecond);
  ReturnValue normalize();  
};
f64 diff(const BaseTime& left, const BaseTime& right);

#endif
