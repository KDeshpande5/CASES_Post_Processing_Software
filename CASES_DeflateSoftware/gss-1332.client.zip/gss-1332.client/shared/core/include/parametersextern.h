// parametersextern.h
//
// GRID configuration file containing "extern" references to all constants
// whose values are not used to statically allocate arrays.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __PARAMETERSEXTERN_GRID_H
#define __PARAMETERSEXTERN_GRID_H
#include "parameters.h"

//======= Immutable constants
extern const f32 TWOPI;
extern const f64 PI;
extern const f64 TWOPI_DOUBLE; 
extern const s32 SPEED_LIGHT_MPS;
extern const f64 NOM_CACODE_PERIOD_SEC;
extern const f64 FREQ_L1_HZ; 
extern const f64 FREQ_L2_HZ; 
extern const f64 DEG_TO_RAD; 
extern const f64 LOCAL_CARRIER_THRESH;

//======= FFT Parameters
extern const s32 FFT_DOPP_FREQ_STEP;
extern const s32 FFT_NUM_K_AND_THRESH;  
extern const s32 FFT_THRESH_ADDITIONAL_SCALE_FACTOR;
extern const u32 FFT_K_ARRAY[];
extern const u32 FFT_THRESH_ARRAY[];


//======= Fixed-point scaling factors
extern const s32 SF_S2TL; 
extern const s32 SF_ILMQL;
extern const s32 SF_NFFTLPQL;
extern const s32 SF_S; 
extern const s64 SF_H; 
extern const s32 SF_T; 
extern const s64 SF_A; 
extern const s32 SF_I; 
extern const s64 SF_P; 
extern const s64 SF_F; 
extern const s64 SF_B;
extern const s64 SF_P_MASK;
extern const s32 SF_S_MASK;
extern const s64 SF_H_MASK;
extern const s32 SF_T_MASK;
extern const s64 SF_B_MASK;

//======= Dependent constants
extern const f64 NOM_CA_CHIPRATE_CPS; 
extern const s64 FP_L2_L1_RATIO; 
extern const s32 FP_SF_H_HALF; 
extern const s32 FP_SF_S_HALF;
extern const s32 FP_SF_T_HALF;

//======= WGS84 constants
extern const f64 sqrt_muearth_WGS84; 
extern const f64 AA_WGS84; 
extern const f64 BB_WGS84; 
extern const f64 OmegaE_WGS84; 
extern const f64 e_WGS84;
extern const f64 esquare_WGS84;

//======= Miscellaneous constants
extern const s32 NV_WN_INVALID;

#endif
