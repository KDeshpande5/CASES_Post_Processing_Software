// signaltype.h
//
// SignalType enumerations
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#ifndef __SIGNAL_TYPE_GRID_H
#define __SIGNAL_TYPE_GRID_H

#include <string>
#include "typedefs.h"
#include "system.h"
#include "txid.h"

// Each GNSS signal can be identified with a specific system, frequency, and
// code.  SignalType enumerates the possible signals for the GRID receiver.
// Each value is constructed as: SYSTEM_FREQUENCY_CODE.
enum SignalType {
  GPS_L1_CA,      // GPS L1 legacy civil code 
  GPS_L2_CM,      // GPS L2 civil M code
  GPS_L2_CL,      // GPS L2 civil L code
  GPS_L2_CLM,     // GPS L2 M+L combined tracking 
  GPS_L1_CA_ALT1, // GPS L1 C/A for alternative L1C bank
  CDMA_UHF_PILOT, // Cellular CDMA pilot, I+Q signal
  CDMA_UHF_SYNC,  // Cellular CDMA pilot+sync, I+Q signal
  NUM_SIGNAL_TYPES,
  UNDEFINED_SIGNAL_TYPE = 255 // Initialization value
};

System getSystem(SignalType signalType);
bool isCombinationValid(SignalType signalType, TxId txId);
const std::string * getSignalTypeNames();

#endif



