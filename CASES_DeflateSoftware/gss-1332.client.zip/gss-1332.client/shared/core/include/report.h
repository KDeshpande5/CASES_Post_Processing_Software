// report.h
//
// Report classes
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __REPORT_GRID_H
#define __REPORT_GRID_H
#include "parameters.h"
#include "basetime.h"
#include "signaltype.h"
#include "system.h"

namespace Report {
     
  enum {
    // If changes are made in this file that affect the interpretation of
    // existing reports from the GRID receiver, then VERSION should be
    // incremented.  VERSION is embedded as the least-significant byte in
    // header2 of ReportObservablesMeasurementTime. VERSION must satisfy 0 <=
    // VERSION <= 255.
    VERSION = 2,
    // SYNCHRONIZATION_SEQUENCE precedes VERSION in the second header of
    // ReportObservablesMeasurementTime.  Thus, one can search for this
    // sequence and then examine the following byte to determine VERSION.  The
    // value of SYNCHRONIZATION_SEQUENCE and its position relative to VERSION
    // should never be changed.
    SYNCHRONIZATION_SEQUENCE = 0xdecade
  };

  // Do NOT change the order of any the enumerations already defined. Always
  // add a new enumeration to the bottom of the list (before the final
  // enumeration entry such as NUM_REPORT_TYPES or NO_TYPE).
  enum ReportType{
    DUMMY_REPORT,
    IQ, 
    GNSS_OBSERVABLES,
    OBSERVABLES_MEASUREMENT_TIME,
    NAVIGATION_SOLUTION,
    DATA_LOG_CONFIG,
    COMMAND_MSG,
    ASSIMILATOR_STATUS,
    TRANSMITTER_INFO,
    IQ_METADATA,
    SCINTILLATION_PARAMETERS,
    IONOSPHERE,
    DIAGNOSTICS_INFO,
    TASK_CPU,
    BENCHMARK,
    NUM_REPORT_TYPES
  };

  // Control commands for SBC-DSP interaction
  enum CommandMsgs{
    SYNC_REQ,    // request for sync confirmation, data[0] = any int
    SYNC_ACK,    // reply to sync request, data[0] = same int as in the request 
    PROG_MODE,   // DSP should enter flash programming mode, no data
    PROG_READY,  // DSP ready to receive program, no data
    BEGIN_TRANS, // DSP data transfer header, data[0] = total data size in bytes
    DATA_TRANS,  // data = sequential chunks of the data
    TRANS_DONE
  };
  
  enum DataTransType{
    UPLOAD_DSPIMG,
    DBM_STATUS,
    ZERO_TARGET,
    UPLOAD_DATABITS,
    SPOOFER_TARGET_VELOCITY,
    SPOOFER_ACCELERATION,
    SPOOFER_NUM_CHANNELS,
    SPOOFER_SWAP_SV,
    DOWNLOAD_DATABITS,
    PHASE_LOCK_STATUS,
    FEEDBACK_STATUS,
    SET_ATT_LEVEL,
    EQUALIZE_AMP_STATUS,
    PROGRAM_PLL_SYNTH,
    UPLOAD_DSPCONFIG,
    NO_TYPE
  };
  
  enum DiagnosticsType{
    NO_DIAGNOSTICS_TYPE
  };
  
  enum TaskId{
    TASK_TOTAL_CPU,
    TASK_ACQUIRE,
    TASK_UPDATE,
    TASK_NAVSOL,
    NUM_TASK_IDS,
    NO_TASK_ID
  };
  
  enum BenchmarkId{
    BM_UPDATE_L1C,
    BM_UPDATE_L2C,
    BM_CORRELATION,
    BM_NAVSOL,
    BM_CODE_GEN_L2C,
    BM_CARRIER_GEN,
    BM_UPDATE_SPOOFER,
    NUM_BENCHMARK_IDS,
    NO_BENCHMARK_ID
  };

  ReportType getReportType(u32 header);
  ReportType getReportTypeAndSize(u32 header, u32& size);

} // namespace

// Note: It would be nice to include the init and serialize/deserialize
// functions within ReportBase as a virtual function, but it turns out that
// this increases the size of the ReportBase object.  We want to keep these
// reports as slim as possible.
//
// CRITICAL: All reports (both the base and derived classes) must have
// sizeof() be aligned to the largest type in the class.  This is because the
// DSP does this alignment and the SBC does not, so transmitting reports
// becomes more complicated if they are not.  Add the requisite amount of
// padding to new classes or modify exisiting ones as appropriate!
class ReportBase {
public:
  Report::ReportType getReportType() const {
    return static_cast<Report::ReportType> ((header >> 24)&0xFF);
  }
protected:
  u32 header;
  u32 header2;
};

class ReportIQ : public ReportBase {
public:
  ReportIQ();
  ~ReportIQ(){}
  void init();
  void packHeader(SignalType signalType, s32 svId, s32 dataBit);
  void unpackHeader(Report::ReportType& reportType, SignalType& signalType, 
                    s32& svId, s32& dataBit) const;
  void packHeader2(u64 tIndexk, s32 tFracIndexk);
  void unpackHeader2(u64& tIndexk, s32& tFracIndexk) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | SignalType << 16 | TXID << 8 | 
  //            dataBit | (tIndexk >> (32-SF_SL)) & 0x7F]
  // header2 = [tIndexk << SF_SL | tFracIndexk >> (SF_TL-SF_SL)]

  // Note: To reduce computational load, the sample time (as expressed in
  // tIndexk and tFracIndexk) is not converted to BaseTime format.  Also, to
  // minimize throughput requirements, only the least significant (39-SF_SL)
  // bits of tIndexk are sent in ReportIQ.  Any ambiguity is resolved by the
  // ReportObservablesMeasurementTime report, which is sent out at a rate 
  // lower than that of ReportIQ.

  // The in-phase and quadrature accumulations over one accumulation interval
  // ending at the time specified by tIndexk and tFracIndexk, in receiver
  // front-end units.
  s32 I,Q;
  // The carrier tracking loop's estimate of the beat carrier phase at the
  // time specified by tIndexk and tFracIndexk, in pics (1 pic = 1/SF_P
  // cycles). thetahat is related to ReportGnssObservables::thetahatk as follows:
  // ReportGnssObservables::thetahatk = -PLL_SIGN_FPLL*thetahat/SF_P,
  // where PLL_SIGN_FPLL is -/+ for high/low-side mixing in the RF front end.
  s64 thetahat;
};

class ReportObservablesMeasurementTime : public ReportBase {
public:
  ReportObservablesMeasurementTime();
  ~ReportObservablesMeasurementTime(){}
  void init();
  void packHeader(SignalType signalType, s32 reportId);
  void unpackHeader(Report::ReportType& reportType, 
                    SignalType& signalType, s32& reportId) const ;
  void unpackHeader2(u32& synchronizationSequence, u8& version) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | SignalType << 16 | reportId << 8 ]
  // header2 = [Report::SYNCHRONIZATION_SEQUENCE << 8 | Report::VERSION]

  // Raw receiver time (RRT) at which the above observables apply.  For a
  // definition of RRT, see note E1 below.
  BaseTime tMeasurement;
  // Offset that gets added to tMeasurement to bring tMeasurement close to GPS
  // time. Offset receiver time (ORT) includes this offset.
  BaseTime tOffset;
};

class ReportGnssObservables : public ReportBase {
public:  
  ReportGnssObservables();
  ~ReportGnssObservables(){}
  void init();
  void packHeader(SignalType signalType, s32 svId, s32 channel);
  void unpackHeader(Report::ReportType& reportType, SignalType& signalType, 
                    s32& svId, s32& channel) const ;
  void packHeader2(ChannelStatus channelStatus, bool phaseErrorFlag, 
                   s32 reportId, bool validObsFlag);
  void unpackHeader2(ChannelStatus& channelStatus, bool& phaseErrorFlag, 
                     s32& reportId, bool& validObsFlag) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | SignalType << 16 | TXID << 8 | Channel]
  // header2 = 
  // [ChannelStatus << 24 | phaseErrorFlag << 16 | reportId << 8 | validObsFlag]
  // CRITICAL: Make sure that you group f32 (and probably u32) members into pairs.
  // Otherwise, the DSP and SBC don't agree on the size.

  // Doppler in Hz (positive for approaching SVs)
  f32 fpll;     
  // Carrier-to-noise ratio in dB-Hz
  f32 C_N0dB;      
  // Beat carrier phase in cycles (changes in the same sense as pseudorange --
  // same as RINEX convention).
  f64 thetahatk;  
  // Pseudorange, in meters.
  f64 pseudoRange;
};

class ReportNavigationSolution : public ReportBase {
public:  
  ReportNavigationSolution();
  ~ReportNavigationSolution(){}
  void init();
  void packHeader(SolverResult solverResult);
  void unpackHeader(Report::ReportType& reportType, 
                    SolverResult& solverResult) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header = [ReportType << 24 | SolverResult << 16]

  // Offset receiver time (ORT) at which the navigation solution applies.  See
  // note E1 below for a definition of ORT.  To convert ORT to true GPS time,
  // subtract deltatRxMeters/cLight, where cLight is the speed of light in
  // meters/second.
  BaseTime tSolution;
  // ECEF X, Y, Z position given in meters 
  f64 xval,yval,zval;
  // Clock bias given in meters 
  f64 deltatRxMeters;  
  // ECEF X, Y, Z velocity in m/s
  f64 xvelocity,yvelocity,zvelocity;
  // Clock rate bias given in meters/sec
  f64 deltatRxDotMetersPerSecond; 
};

class ReportDataLogConfig : public ReportBase {
public:
  ReportDataLogConfig();
  ~ReportDataLogConfig(){}
  void init();
  void packHeader(const s32 configId, const SignalType signalType,
                  const s32 numChannels);
  void unpackHeader(Report::ReportType& reportType, s32& configId,
                    SignalType& signalType, s32& numChannels) const;
  u32 buildId() const { return header2; }
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | configId << 16 | SignalType << 8 | numChannels]
  // header2 = GRID Build Id
};

class ReportTransmitterInfo : public ReportBase {
public:
  ReportTransmitterInfo();
  ~ReportTransmitterInfo(){}
  void init();
  void packHeader(s32 healthStatus, s32 reportId);
  void unpackHeader(Report::ReportType& reportType, s32& healthStatus, 
                    s32& reportId) const;
  void packHeader2(TxId txId);
  void unpackHeader2(TxId& txId) const;
  void serialize(u32 * pa) const;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | healthStatus << 16 | reportId << 8]
  // header2 = [TxIdSystem << 24 | TxIdNumber << 16]
  f32 azimuthDeg;
  f32 elevationDeg;
};

class ReportCommand : public ReportBase {
public:
  ReportCommand();
  ~ReportCommand(){}
  void init();
  void packHeader(Report::DataTransType dataTransType);
  void serialize(u32 * pa) const;
  void deserialize(const u32 * pa);
  void setCommandMsg(Report::CommandMsgs msg);
  Report::CommandMsgs commandMsg() const;
  Report::DataTransType dataTransType() const;
  // header = [ReportType << 24 | dataTransType << 16];
  // header2 = commandMsg
  enum {DataSize = 30};
  u32 commandData[DataSize]; // data depends on message type
};

class ReportAssimilatorStatus : public ReportBase {
public:
  ReportAssimilatorStatus();
  ~ReportAssimilatorStatus(){}
  void init();
  void serialize(u32* pa) const;
  void deserialize(const u32* pa);
  void packHeader(s32 databitPredictionEnabled, s32 phaseLockEnabled, 
                  s32 feedbackEnabled, s32 equalizeAmplitude,
                  u32 digitalAttenuatorSettingdB);
  void unpackHeader(Report::ReportType& reportType,
                    s32& databitPredictionEnabled, s32& phaseLockEnabled, 
                    s32& feedbackEnabled, s32& equalizeAmplitude,
                    u32& digitalAttenuatorSettingdB) const;
  void clearSvSpoofBits() { header2 = 0; }
  void setSvSpoofed(s32 svId);
  bool isSvSpoofed(s32 svId);
  void unpackHeader2();
  // header = [ReportType << 24 | databitPredicitonEnabled << 23 |
  //           phaseLockEnabled << 22 | feedbackEnabled << 21 |
  //           equalizeAmplitudes << 20 | digitalAttenuatorSettingdB]
  // 
  // header2 = bits indicate which SVs are being spoofed
  f32 dxval,dyval,dzval;
  f32 ddeltatRxMeters;
  f32 dxvelocity,dyvelocity,dzvelocity;
  // Clock rate bias given in meters/sec
  f32 ddeltatRxDotMetersPerSecond; 
  s32 tIndexkAlignmentOffset;
  s32 tFracIndexkAlignmentOffset;
};

class ReportIQMetadata : public ReportBase {
public:
  ReportIQMetadata();
  ~ReportIQMetadata(){}
  void init();
  void serialize(u32* pa) const;
  void deserialize(const u32* pa);
  void packHeader(const SignalType signalType, const s32 pllSignFpll);
  void unpackHeader(Report::ReportType& reportType,
                    SignalType& signalType, s32& pllSignFpll) const;
  void packHeader2(const s32 scaleFactorPL);
  void unpackHeader2(s32& scaleFactorPL) const;
  // header  = [ReportType << 24 | SignalType << 16 | pllSignFpll]
  // header2 = [SF_PL << 24]
  
  // The noise floor corresponding to one accumulation period
  s32 twoSigmaIqSq;
  // Denominator of the sampling rate
  s32 sampleFreqDenominator;
  // Coherent accumulation period seconds
  f64 accumPeriod;
  // Numerator of the sampling rate
  s64 sampleFreqNumerator;
};

class ReportScintillationParameters : public ReportBase {
public:  
  ReportScintillationParameters();
  ~ReportScintillationParameters(){}
  void init();
  void packHeader(SignalType signalType, s32 svId, s32 refId);
  void unpackHeader(Report::ReportType& reportType, SignalType& signalType, 
                    s32& svId, s32& refId) const ;
  void packHeader2(f32 measurementIntervalLengthSec);
  void unpackHeader2(f32& measurementIntervalLengthSec) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | SignalType << 16 | TXID << 8 | RefId]
  // header2 = [(f32)measurementIntervalLengthSec]
  //
  // RefId denotes whether this channel is used as a reference channel (1 or 2) 
  // or a normal channel (0).
  
  // Offset receiver time (ORT) corresponding to the end of the interval over
  // which the scintillation parameters were measured.  For a definition of
  // ORT, see note E1 below.
  BaseTime tReceiver;
  // Scintillation amplitude indices over the full measurement interval and
  // over the first and second halves of the interval.
  f32 S4_Full, S4_Half[2];
  // Scintillation phase indices over the full measurement interval and over
  // the first and second halves of the interval, in cycles.
  f32 sigmaPhi_Full, sigmaPhi_Half[2];
  // Measured decorrelation time over the full measurement interval, in
  // seconds.  A tau0 value of -1 indicates that scintillation was too weak or
  // too slow to enable calculation of tau0.  
  f32 tau0;
  // Scintillation power ratio over the full measurement interval, in dB.
  f32 SPRdB;
};

class ReportIonosphere : public ReportBase {
public:
  ReportIonosphere();
  ~ReportIonosphere(){}
  void init();
  void packHeader(s32 svId);
  void unpackHeader(Report::ReportType& reportType, s32& svId) const ;
  void packHeader2(f32 TEC);
  void unpackHeader2(f32& TEC) const;
  void serialize(u32 * pa) const ;
  void deserialize(const u32 * pa);
  // header  = [ReportType << 24 | TXID]
  // header2 = [(f32)TEC] (pseudorange-based TEC in TECU)
  //
  // Change in phase-based TEC estimate from last measurement, in TECU.
  f64 deltaPhiTec; 
  // Offset receiver time (ORT) corresponding to the end of the interval over
  // which the ionospheric parameters were measured.  For a definition of ORT,
  // see note E1 below.
  BaseTime tReceiver;
};

class ReportDiagnosticsInfo : public ReportBase {
public:
  ReportDiagnosticsInfo();
  ~ReportDiagnosticsInfo(){}
  void init();
  void unpackHeader(Report::ReportType& reportType) const;
  void packHeader2(Report::DiagnosticsType diagsType);
  void unpackHeader2(Report::DiagnosticsType& diagsType) const;
  void serialize(u32 * pa) const;
  void deserialize(const u32 * pa);
  // header = [ReportType << 24]
  // header2 = diagsType
  
  enum {DataSize = 40};
  char diagnosticsMessage[DataSize];
};

class ReportTaskCpu : public ReportBase {
public:
  ReportTaskCpu();
  ~ReportTaskCpu(){}
  void init();
  void unpackHeader(Report::ReportType& reportType) const;
  void packHeader2(Report::TaskId taskId);
  void unpackHeader2(Report::TaskId& taskId) const;
  void serialize(u32 * pa) const;
  void deserialize(const u32 * pa);
  std::string getTaskName();
  // header = [ReportType << 24]
  // header2 = taskId
  
  // The percent of the CPU used by this task over the observation window 
  // (set in df_common.xs as the clock period for semCpuReport)
  u32 taskPercCpu;
};

class ReportBenchmark : public ReportBase {
public:
  ReportBenchmark();
  ~ReportBenchmark(){}
  void init();
  void unpackHeader(Report::ReportType& reportType) const;
  void packHeader2(Report::BenchmarkId benchmarkId);
  void unpackHeader2(Report::BenchmarkId& benchmarkId) const;
  void serialize(u32 * pa) const;
  void deserialize(const u32 * pa);
  std::string getBenchmarkName();
  // header = [ReportType << 24]
  // header2 = benchmarkId
  
  // average, maximum, and minimum time spent on a single excecution of the code
  // between benchmark's startTick and stopTick
  u32 avgTime;
  u32 maxTime;
  u32 minTime;
};

#endif


// Explanatory notes:
//
// (E1) This file refers totTwo types of measurement time stamps:
//
//     (1) Raw Receiver Time (RRT): This time stamp is linked directly to the
//     receiver's sampling clock.  It starts at zero when the receiver is
//     initialized and is never interrupted or adjusted.
//
//     (2) Offset Receiver Time (ORT): This time stamp is equal to RRT plus an
//     offset that brings the result close (within a few ms) to true GPS time:
//
//     ORT = RRT + tOffset
//
//     The offset gets adjusted every so often to bring ORT back within a few ms
//     of true GPS time.  When the offset is adjusted, a small jump in ORT is
//     introduced.  For maximum resolution, ORT is given in separate columns for
//     week, whole second, and fractional seconds.
