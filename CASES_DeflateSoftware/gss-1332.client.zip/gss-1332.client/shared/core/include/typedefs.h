// typedefs.h
//
// Type definitions that associate native types with precise bit sizes.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __TYPEDEFS_GRID_H
#define __TYPEDEFS_GRID_H

#ifdef DSPARCH
#define __restrict restrict  
#endif
#ifdef WIN32
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;
typedef unsigned __int64 u64;
typedef __int64 s64;
typedef float f32;
typedef double f64;
#else
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;
typedef unsigned long long u64;
typedef signed long long s64;
typedef float f32;
typedef double f64;
#endif

#endif

