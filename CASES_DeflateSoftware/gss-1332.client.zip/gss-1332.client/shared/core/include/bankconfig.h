// bankconfig.h
//
// BankConfig class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __BANK_CONFIG_GRID_H
#define __BANK_CONFIG_GRID_H

#include <string>
#include "typedefs.h"
#include "channeltype.h"
// Instead of forward declaring these classes, we include them so we can inline
// certain accessors.
#include "frontend.h"
#include "carriergenerator.h"

class CodeGenerator;
class OversampledCodeGenerator;
namespace gpstk { class ConfDataReader; }
class DataBitManager;

class BankConfig {
public: 
  // Types of phase tracking loop discriminators
  enum DiscriminatorType {
    // four-quadrant decision-directed arctangent (atan2(Q*sign(I),I*sign(I)))
    DDAT_DISC, 
    // four-quadrant decision-directed arctangent (atan2(Q*sign(I),I*sign(I)))
    // with data bit aiding from the DataBitManager, when available.
    DDAT_DBA_DISC, 
    // two-quadrant arctangent (atan(Q/I)) 
    AT_DISC,   
    // decision-directed (sign(I)*Q*nconst_d)
    DD_DISC,    
    // conventional Costas (Q*I*nconst_c)
    CC_DISC,   
    // four-quadrant arctangent (atan2(Q,I) -- for data-free signals) 
    AT4_DISC   
  };
  // Possible closed-loop loop orders for phase tracking loops.
  enum LoopOrder {
    ORDER1,
    ORDER2,
    ORDER3
  };
  // Types of oversampled code generators
  enum CodeGenType {
    NONE,
    PSIAKI,
    LOOKUP,
    FULL_PRECISION
  };
private:
  struct IndependentParameters {
    // Nominal minimum Doppler frequency used in the carrier replica arrays.
    f64 NOM_MIN_DOPPLER_FREQ_HZ_;
    // Nominal maximum Doppler frequency used in the carrier replica arrays.
    f64 NOM_MAX_DOPPLER_FREQ_HZ_;
    // Doppler frequency step
    f64 DOPPLER_FREQ_STEP_HZ_;
    // Nominal chipping rate of PRN code, in chips per second
    f64 NOM_CHIPRATE_CPS_;
    // Nominal carrier frequency, in Hz
    f64 FREQ_CARRIER_HZ_;
    // Spacing between early and late correlators, in chips.
    f64 EML_CHIP_SPACING_;
    // Number of chips per subaccumulation
    // NUM_CHIPS_PER_SUBACCUM_ must be an integer divisor of the number of 
    // chips in a PRN code cycle (NUM_CHIPS_PER_CODE_).
    s32 NUM_CHIPS_PER_SUBACCUM_;
    // Number of chips in PRN code
    s32 NUM_CHIPS_PER_CODE_;
    // Number of subaccumulations per symbol
    u32 NUM_SUBACCUM_PER_SYMBOL_;
    // Maximum number of channels that the Bank object is allowed to have.
    s32 MAXCHANNELS_;
    // Integer number of subaccumulation intervals per accumulation interval.
    // If the signal to be tracked is data modulated, then
    // NUM_SUBACCUM_PER_ACCUM_ must be an integer divisor of the number of
    // subaccumulations per data symbol (NUM_SUBACCUM_PER_SYMBOL_).
    s32 NUM_SUBACCUM_PER_ACCUM_;  
    // Time constant for the low-pass filter that smoothes the
    // one-C/A-code-period I^2 + Q^2 quantities to get E[I^2 + Q^2]
    f32 CH_IQSQ_FILTER_TAU_SEC_;
    // Nominal pruning interval (in subaccumulations)
    s32 CH_PRUNE_INTERVAL_SUBACCUMS_;
    // Number of consecutive times a signal must fail the pruning criteria in
    // Bank::pruneChannels, which is called every
    // CH_PRUNE_INTERVAL_SUBACCUMS_, before it gets pruned.
    s32 CH_PRUNE_THRESHOLD_;
    // Maximum acquisition search depth
    s32 MAX_ACQ_SEARCH_DEPTH_;

    //----- PLL 
    LoopOrder PLL_DEFAULT_LOOP_ORDER_; 
    f32 PLL_DEFAULT_BANDWIDTH_HZ_; 
    // Choose among DDAT_DISC, AT_DISC, DD_DISC, CC_DISC, and AT4_DISC
    DiscriminatorType PLL_DEFAULT_DISCRIMINATOR_TYPE_; 
    // The PLL's phase lock threshold is compared against the phase lock statistic
    // in Equation 118 on page 393 of the Blue Book, volume 1.
    f32 PLL_PHASE_LOCK_THRESHOLD_;
    // Determines when a phase lock flag is raised to indicate possible cycle
    // slippage
    f32 PLL_PHASE_FLAG_THRESHOLD_;
    // Number of subaccumulations per phase lock detection interval. 
    s32 PLL_NUM_SUB_PER_PHASELOCK_;
    
    //======= DLL 
    f32 DLL_DEFAULT_BANDWIDTH_HZ_; 
    bool DLL_COUPLE_FLAG_;
    bool PADDING_1_, PADDING_2_, PADDING_3_;
    
    //======= FLL
    f32 FLL_NOM_BANDWIDTH_HZ_;
    f32 FLL_WEAK_BANDWIDTH_HZ_; 
    // Upper thresholds for the histogram-based data bit synchronization
    // process, nominal-strength and weak signals.  See details in Blue Book
    // volume 1 p. 395.
    s8  FLL_NBS1_NOM_,FLL_NBS1_WEAK_;
    // Lower thresholds for the histogram-based data bit synchronization
    // process, nominal-strength and weak signals.  See details in Blue Book
    // volume 1 p. 395.
    s8  FLL_NBS2_NOM_,FLL_NBS2_WEAK_; 
    
    //======= CODEGEN (oversampled ranging code generation) 
    CodeGenType CODEGEN_TYPE_;
    s32 MSAMPFRAC_;
  };
protected:
  void checkParameterValidity();
  void setDependentParameters();
  virtual void checkParameterValidityDerived() = 0;
  virtual void setDependentParametersDerived() = 0;
  virtual void importConfigurationDerived(gpstk::ConfDataReader * cr) = 0;
  virtual void importConfigurationDerived(const u32 * pa, s32& index) = 0;
  virtual void exportConfigurationDerived(u32 * pa, s32& index)const = 0;
  
public:
  virtual ~BankConfig(){}
  virtual void init() = 0;
  virtual ChannelType channelType() = 0;
  void importConfiguration(gpstk::ConfDataReader * cr);
  void importConfiguration(const u32 * pa, s32& index);
  void exportConfiguration(u32 * pa, s32& index)const;
  
  void updateTwoSigmaIQSq(s32 numOnesM, s32 numBitsM);
  void setCarrierGenerator(const CarrierGenerator* c);
  void setOversampledCodeGenerator(OversampledCodeGenerator* oscg){
    oversampledCodeGenerator_ = oscg;
  }
  void setFrontEnd(const FrontEnd* fe){FRONT_END_ = fe;}
  void setDataBitManager(DataBitManager* dbm){dataBitManager_ = dbm;}
  void setSignalType(SignalType signalType){signalType_ = signalType;}
  const CarrierGenerator* carrierGenerator()const{return carrierGenerator_;}
  OversampledCodeGenerator* oversampledCodeGenerator()const
    {return oversampledCodeGenerator_;}
  const FrontEnd * FRONT_END()const{return FRONT_END_;}
  DataBitManager * dataBitManager()const{return dataBitManager_;}
  SignalType signalType() const {return signalType_;}
 
  s32 NUM_CHIPS_PER_CODE()const{return indep_.NUM_CHIPS_PER_CODE_;}
  s32 NUM_CHIPS_PER_SUBACCUM()const{return indep_.NUM_CHIPS_PER_SUBACCUM_;}
  u32 NUM_SUBACCUM_PER_SYMBOL()const{return indep_.NUM_SUBACCUM_PER_SYMBOL_;}
  f64 NOM_CHIPRATE_CPS()const{return indep_.NOM_CHIPRATE_CPS_;}
  f64 FREQ_CARRIER_HZ()const{return indep_.FREQ_CARRIER_HZ_;}
  s32 MAXCHANNELS() const {return indep_.MAXCHANNELS_;}
  s32 NUM_SUBACCUM_PER_ACCUM()const{return indep_.NUM_SUBACCUM_PER_ACCUM_;}
  f64 EML_CHIP_SPACING()const{return indep_.EML_CHIP_SPACING_;}
  f32 CH_IQSQ_FILTER_TAU_SEC()const{return indep_.CH_IQSQ_FILTER_TAU_SEC_;}
  f64 NOM_MIN_DOPPLER_FREQ_HZ()const{return indep_.NOM_MIN_DOPPLER_FREQ_HZ_;}
  f64 NOM_MAX_DOPPLER_FREQ_HZ()const{return indep_.NOM_MAX_DOPPLER_FREQ_HZ_;}
  f64 DOPPLER_FREQ_STEP_HZ()const{return indep_.DOPPLER_FREQ_STEP_HZ_;}
  s32 MAX_ACQ_SEARCH_DEPTH()const{return indep_.MAX_ACQ_SEARCH_DEPTH_;}
  s32 CH_PRUNE_INTERVAL_SUBACCUMS()const{return indep_.CH_PRUNE_INTERVAL_SUBACCUMS_;}
  s32 CH_PRUNE_THRESHOLD()const{return indep_.CH_PRUNE_THRESHOLD_;}
  LoopOrder PLL_DEFAULT_LOOP_ORDER()const{return indep_.PLL_DEFAULT_LOOP_ORDER_;} 
  f32 PLL_DEFAULT_BANDWIDTH_HZ()const{return indep_.PLL_DEFAULT_BANDWIDTH_HZ_;} 
  DiscriminatorType PLL_DEFAULT_DISCRIMINATOR_TYPE()const
  {return indep_.PLL_DEFAULT_DISCRIMINATOR_TYPE_;} 
  f32 PLL_PHASE_LOCK_THRESHOLD()const{return indep_.PLL_PHASE_LOCK_THRESHOLD_;}
  f32 PLL_PHASE_FLAG_THRESHOLD()const{return indep_.PLL_PHASE_FLAG_THRESHOLD_;}
  s32 PLL_NUM_SUB_PER_PHASELOCK()const{return indep_.PLL_NUM_SUB_PER_PHASELOCK_;}
  f32 DLL_DEFAULT_BANDWIDTH_HZ()const{return indep_.DLL_DEFAULT_BANDWIDTH_HZ_;} 
  f32 DLL_COUPLE_FLAG()const{return indep_.DLL_COUPLE_FLAG_;} 
  f32 FLL_NOM_BANDWIDTH_HZ()const{return indep_.FLL_NOM_BANDWIDTH_HZ_;}
  f32 FLL_WEAK_BANDWIDTH_HZ()const{return indep_.FLL_WEAK_BANDWIDTH_HZ_;} 
  s8 FLL_NBS1_NOM()const{return indep_.FLL_NBS1_NOM_;}
  s8 FLL_NBS1_WEAK()const{return indep_.FLL_NBS1_WEAK_;}
  s8 FLL_NBS2_NOM()const{return indep_.FLL_NBS2_NOM_;}
  s8 FLL_NBS2_WEAK()const{return indep_.FLL_NBS2_WEAK_;} 
  CodeGenType CODEGEN_TYPE()const{return indep_.CODEGEN_TYPE_;}
  s32 MSAMPFRAC()const{return indep_.MSAMPFRAC_;}
  s64 SAMPLE_FREQ_NUMERATOR()const{return FRONT_END_->SAMPLE_FREQ_NUMERATOR();} 
  s32 SAMPLE_FREQ_DENOMINATOR()const{return FRONT_END_->SAMPLE_FREQ_DENOMINATOR();}
  s32 QUANTIZATION()const{return FRONT_END_->QUANTIZATION();}
  f64 FREQ_IF_HZ()const{return FRONT_END_->FREQ_IF_HZ(signalType_);}
  s8  PLL_SIGN_FPLL()const{return FRONT_END_->PLL_SIGN_FPLL(signalType_);}
  f64 CODE_PHASE_BIAS_METERS()const{return FRONT_END_->CODE_PHASE_BIAS_METERS(signalType_);}
  f64 SUBACCUM_PERIOD()const{return SUBACCUM_PERIOD_;}
  s32 NUM_SUBACCUM_PER_CODE()const{return NUM_SUBACCUM_PER_CODE_;}
  s64 FP_FREQ_CARRIER_HZ()const{return FP_FREQ_CARRIER_HZ_;}
  s64 FREQ_CARRIER_PIC()const{return FREQ_CARRIER_PIC_;}
  u64 FREQ_IF_PIC_AND_FRAC_PIC()const{return FREQ_IF_PIC_AND_FRAC_PIC_;}
  s32 NWORD_PER_SUBACCUM()const{return NWORD_PER_SUBACCUM_;}
  s64 FP_IF_OFFSET()const{return FP_IF_OFFSET_;} 
  f64 TACCUM_SEC()const{return TACCUM_SEC_;}
  f64 SAMPLE_FREQ_HZ()const{return SAMPLE_FREQ_HZ_;}
  f64 DELTA_T()const{return DELTA_T_;}
  f64 NOM_SAMPS_PER_SUBACCUM()const{return NOM_SAMPS_PER_SUBACCUM_;}
  s32 SAMPS_PER_CBUFFER()const{return SAMPS_PER_CBUFFER_;}
  s64 FP_NOM_SAMPS_PER_SUBACCUM()const{return FP_NOM_SAMPS_PER_SUBACCUM_;}
  s32 FLOOR_NOM_SAMPS_PER_SUBACCUM()const{return FLOOR_NOM_SAMPS_PER_SUBACCUM_;}
  s32 CEIL_NOM_SAMPS_PER_SUBACCUM()const{return CEIL_NOM_SAMPS_PER_SUBACCUM_;}
  f64 DELTA_SAMPS_PER_SUBACCUM()const{return DELTA_SAMPS_PER_SUBACCUM_;}
  s64 FP_DELTA_SAMPS_PER_SUBACCUM()const{return FP_DELTA_SAMPS_PER_SUBACCUM_;}
  s32 TWO_SIGMAIQSQ()const{return TWO_SIGMAIQSQ_;}
  s32 TWO_SIGMAIQSQ_FFTACQ()const{return TWO_SIGMAIQSQ_FFTACQ_;}
  f64 FFT_DELT()const{return FFT_DELT_;}
  s32 FP_FFT_DX()const{return FP_FFT_DX_;}
  f32 FFT_CYC_PER_SAMP()const{return FFT_CYC_PER_SAMP_;}
  f32 CH_IQSQ_FILTER_K()const{return CH_IQSQ_FILTER_K_;}
  f32 CH_IQSQ_FILTER_K_SUB()const{return CH_IQSQ_FILTER_K_SUB_;} 
  s32 FLL_TRANSIENT_NOM_MS()const{return FLL_TRANSIENT_NOM_MS_;} 
  s32 FLL_TRANSIENT_WEAK_MS()const{return FLL_TRANSIENT_WEAK_MS_;}
  s32 FLL_WEAK_THRESH()const{return FLL_WEAK_THRESH_;} 
  s32 FP_CH_IQSQ_FILTER_K_SUB()const{return FP_CH_IQSQ_FILTER_K_SUB_;}
  
protected:
  const FrontEnd * FRONT_END_;
  const CarrierGenerator* carrierGenerator_;
  OversampledCodeGenerator* oversampledCodeGenerator_;
  DataBitManager * dataBitManager_;

  //================== Independent parameters =========================
  IndependentParameters indep_;
  SignalType signalType_;  
  
  //================== Dependent parameters =========================
  // Number of subaccumulations per code
  s32 NUM_SUBACCUM_PER_CODE_;
  // Number of words per subaccumulation (copy from CarrierGenerator).
  s32 NWORD_PER_SUBACCUM_;
  // Frequency parameters
  u64 FREQ_IF_PIC_AND_FRAC_PIC_;
  s64 FREQ_CARRIER_PIC_;
  // Offset between this frontend's IF and the local carrier replicas' IF,
  // in cycles/sample scaled by SF_B
  s64 FP_IF_OFFSET_; 
  // Fixed-point version of nominal carrier frequency, scaled by SF_S
  s64 FP_FREQ_CARRIER_HZ_;
  // Subaccumulation period in seconds
  f64 SUBACCUM_PERIOD_;
  // Accumulation interval, in seconds
  f64 TACCUM_SEC_;
  // Sampling frequency, in Hz
  f64 SAMPLE_FREQ_HZ_;
  // Sampling interval, in seconds
  f64 DELTA_T_;
  // Nominal number of samples (and fractional samples) per subaccumulation
  f64 NOM_SAMPS_PER_SUBACCUM_;
  // Number of samples that fit within the circular buffer
  s32 SAMPS_PER_CBUFFER_;
  s64 FP_NOM_SAMPS_PER_SUBACCUM_;
  // Floor of nominal number of samples per C/A code
  s32 FLOOR_NOM_SAMPS_PER_SUBACCUM_;
  // Ceil of nominal number of samples per C/A code
  s32 CEIL_NOM_SAMPS_PER_SUBACCUM_;
  // This is the error in the estimate of the number of samples per 
  // subaccumulation period caused by the frequency resolution of the 
  // acquisition routine. Multiplying this quantity by the number of 
  // subaccumulations over which an offset is to be propagated gives the 
  // maximum error in samples between the true subaccumulation start/stop time
  // and the propagated subaccumulation start stop time. 
  // Should be near 0.00063 for GPS L1 C/A.
  f64 DELTA_SAMPS_PER_SUBACCUM_;
  s64 FP_DELTA_SAMPS_PER_SUBACCUM_;
  // The I^2 + Q^2 filter is a digitized low-pass filter of the form y(k+1) =
  // y(k) + (T/tau)*(x(k) - y(k)) where x(k) = I(k)^2 + Q(k)^2 and y(k) is the
  // averaged value with time constant tau.
  f32 CH_IQSQ_FILTER_K_;
  f32 CH_IQSQ_FILTER_K_SUB_; 
  // Number of ms to wait so that 5 time constants elapse (FLL settles) before
  // attempting to do bit synchronization; nominal and weak cases
  s32 FLL_TRANSIENT_NOM_MS_; 
  s32 FLL_TRANSIENT_WEAK_MS_;
  // The threshold against which the initial subaccumulation I^2 + Q^2 value
  // will be compared to determine whether to initialize the FLL with weak
  // (slower pull-in) or nominal (faster pull-in) parameters.
  s32 FLL_WEAK_THRESH_; 
  s32 FP_CH_IQSQ_FILTER_K_SUB_;
  // See notes (E1) and (E2) below
  s32 TWO_SIGMAIQSQ_;
  // Noise floor parameter used for thresholds in FFT-based acquisition based
  // on FFTs of size NFFT.  This is scaled by a factor of
  // NFFT/NOM_SAMPS_PER_SUBACCUM compared with TWO_SIGMAIQSQ simply because the
  // data is resampled and NFFT samples are used instead of
  // NOM_SAMPS_PER_SUBACCUM.
  s32 TWO_SIGMAIQSQ_FFTACQ_;
  // Sampling interval for for FFT-based acquisition as forced by
  // interpolation, in seconds.
  f64 FFT_DELT_;
  // Resampling step size for interpolation of data in the FFT-based
  // acquisition algorithm on the DSP target, expressed as a scaled fraction
  // of DELTA_T
  s32 FP_FFT_DX_;
  f32 FFT_CYC_PER_SAMP_;
};

#endif

// Explanatory notes:
//
// (E1) The theoretical value for the noise floor (2*sigmaIQ^2) for L1 C/A
//      channels is 224650.  Here, sigmaIQ^2 is the variance of the random
//      component of the I and of the Q accumulation over 1 C/A code interval
//      (1 ms).  The value of sigmaIQ^2 is calculated as described in the
//      document "CALCULATING THE CARRIER-TO-NOISE RATIO IN A GPS RECEIVER"
//      from Feb. 21, 2006 (plessey_noise.pdf), with local carrier replicas
//      quantized to +/-1 and +/- 3 values instead of +/- 1 and +/- 2 values.
//      The actual value used (as opposed to the theoretical value) is a more
//      realistic empirical value that leads to more accurate estimates of
//      C/N0.  For best results, the empirical value must be tailored to each
//      hardware platform.
//
// (E2) The noise floor of the L2CM and L2CL channels can be related to the
//      noise floor of the L1 C/A channels as follows.  Referring to the
//      document "CALCULATING THE CARRIER-TO-NOISE RATIO IN A GPS RECEIVER"
//      from Feb. 21, 2006 (plessey_noise.pdf), one notes from Eq. 9a that
//      sigmaIQ^2 scales as the number of samples Nk.  Since the L2CM code and
//      the L2CL code are "off" half the time, an ideal correlation with each
//      code taken separately will involve half the samples as correlation
//      with the C/A code.  This reduces the noise floor of L2CM and L2CL by a
//      factor of two compared with the L1 C/A noise floor.  But in
//      implementation in this receiver, the L2CM and L2CL codes are formed by
//      correlating with (CM + CL) and then with (CM - CL) and then summing or
//      differencing the result to get the desired code.  Summing yields 2*CM
//      and differencing yields 2*CL.  Hence, the correlation statistic is
//      multiplied by a factor of 2.  This implies that its variance increases
//      by a factor of 4.  The combined effects of "half the samples" and
//      "multiply by two" increase CM or CL correlation variance sigmaIQ^2 by
//      a factor of 2 compared to L1 C/A channels.  Hence, TWO_SIGMAIQSQL2 =
//      TWO_SIGMAIQSQ*2.  Of course, because of slight differences in the
//      automatic gain controllers of the L1 C/A and the L2C front-ends, the
//      relation TWO_SIGMAIQSQL2 = TWO_SIGMAIQSQ*2 will only hold
//      approximately.  The actual value used above is an empirical value that
//      leads to accurate estimates of C_N0.  For best results, the empirical
//      value must be tailored to each hardware platform.
//
//      While the above is all true for tracking L2CL and L2CM separately, if
//      the CM code is data-free, then we can simply track the combined CM+CL
//      code and the L2 noise floor becomes identical to that of the L1 C/A
//      signal.


