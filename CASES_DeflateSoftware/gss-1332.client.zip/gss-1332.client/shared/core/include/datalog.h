// datalog.h
//
// DataLog class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __DATALOG_GRID_H
#define __DATALOG_GRID_H
#include <string>
#include <vector>
#include "parameters.h"
#include "report.h"

// Aggregates data from all reports generated during a given time interval.
// Includes methods for displaying these data and writing to file.
class DataLog {
  enum LogType {
    BINARY,
    DISPLAY,
    CHANNEL,
    IQ,
    NAVSOL,
    TXINFO,
    SCINT,
    IONO,
    NUM_LOG_TYPES
  };

public:
  // Note: Because the DataLog class is meant to live independent of the other
  // core code (for example, only on a host computer or on the SBC, but not in
  // the DSP), we can't make it depend on a particular GRID configuration
  // where each bank has its own number of channels.  Therefore, we use a
  // configuration report to set the number of banks and the number of
  // channels for each bank. 
  DataLog();
  ~DataLog();
private:
  void cleanup();
public:
  void init();
  void insertReport(u32 * tempArray);
  void setCommand(std::string& cmd);
  s32 openDisplay(const std::string& dispName, s32 redrawPer);
  s32 openBinlog(const std::string& binName);

private:
  s32 openLog(LogType lt);
  s32 closeLog(LogType lt);
  void displayAndLog();
  void logNavData();
  void logIqData();
  void logTxInfoData();

  ReportObservablesMeasurementTime rpTime_;
  s32 reportId_;
  u32 buildId_;
  // redrawPeriod_ is expressed in log intervals.  Thus, display data printed
  // to stdout or to file every redrawPeriod_ log intervals.
  s32 redrawPeriod_;
  bool isConfigured_;
  bool isAssimilator_;
  s32 numBanks_;
  s32 signalTypeToIndexMap_[NUM_SIGNAL_TYPES];
  s32 numChannels_[NUM_SIGNAL_TYPES];
  std::vector<ReportIQ> rpIq_[NUM_SIGNAL_TYPES];
  std::vector<ReportTransmitterInfo> rpTxInfo_;
  ReportIQMetadata rpIqMetadata_[NUM_SIGNAL_TYPES];
  ReportGnssObservables ** rpObs_;
  ReportNavigationSolution rpNav_;
  ReportAssimilatorStatus rpAssim_;
  std::vector<ReportDiagnosticsInfo> rpDiagsInfoVec_;
  ReportTaskCpu rpTaskCpuArray_[Report::NUM_TASK_IDS];
  ReportBenchmark rpBenchmarkArray_[Report::NUM_BENCHMARK_IDS];
  bool receivedReportTaskCpu_,receivedReportBenchmark_;
  std::vector<FILE *> logFilePointers_;
  std::string uploadCommand_;
  bool firstFlag;
};

#endif
