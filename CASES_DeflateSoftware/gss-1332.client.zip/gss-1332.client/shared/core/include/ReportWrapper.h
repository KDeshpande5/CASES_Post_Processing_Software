// ReportWrapper.h
//
// Handles transmission of various data reports
//
// Copyright (c) 2010 the GRID Software Project.  All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __REPORT_WRAPPER_GRID_H
#define __REPORT_WRAPPER_GRID_H

#include "report.h"

namespace ReportWrapper{
  extern u8 gBufReportDummy[REP_BUFFSIZE];
#ifdef DSPARCH
  extern u8 gBufRepRcvPing[REP_BUFFSIZE];
  extern u8 gBufRepRcvPong[REP_BUFFSIZE];
#endif
  void init();
  bool attemptSync(u8 syncbuf[REP_BUFFSIZE], s32 &offset);
  void enqueue(const void* report, s32 repSize);
  u8* nextBuffer();
  void forceReady();
}//namepsace


#endif

