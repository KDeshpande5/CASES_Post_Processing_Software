// logger.h
//
// Simple logger macro
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf 

#ifndef __LOGGER_GRID_H
#define __LOGGER_GRID_H

#define LOG_printf(...) logger::printf(__FILE__, __LINE__, __VA_ARGS__)

void pabort(const char* s);

namespace logger {
  void printf(const char* file, int line, const char* format, ...);
}

#endif

