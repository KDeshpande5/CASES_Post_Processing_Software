// navsolconfig.h
//
// NavSolConfig class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __NAVSOL_CONFIG_GRID_H
#define __NAVSOL_CONFIG_GRID_H

#include "typedefs.h"

namespace gpstk { class ConfDataReader; }

class NavSolConfig {
public:
  NavSolConfig();
  ~NavSolConfig(){};
  
  void importConfiguration(gpstk::ConfDataReader * cr);
  void importConfiguration(const u32 * pa, s32& index);
  void exportConfiguration(u32 * pa, s32& index)const;
  
  bool AVERAGE_NAV_SOLN()const{return AVERAGE_NAV_SOLN_;}
  f32  NAV_FILTER_K()const{return NAV_FILTER_K_;} 
  bool USE_IONO_CORR()const{return USE_CORR_ & IONO_CORR;} 
  bool USE_TROPO_CORR()const{return USE_CORR_ & TROPO_CORR;} 
  bool ALLOW_DELTRX_FIXUPS()const{return ALLOW_DELTRX_FIXUPS_;}
  f64  MAX_ABS_DELTRX_SEC()const{return MAX_ABS_DELTRX_SEC_;}
  bool ENFORCE_STRICT_SELECTION()const{return ENFORCE_STRICT_SELECTION_;}
  f64  ELEVATION_MASK_ANGLE_RAD()const{return ELEVATION_MASK_ANGLE_RAD_;}
  // This quantity is time fixup resolution, in seconds.  A time fixup DELTRX
  // is always chosen to be an integer multiple of this quantity.  This
  // implies that DELTRX_FIXUP_RESOLUTION_SEC must be chosen such that for any
  // carrier frequency fc considered within the code,
  // fc*DELTRX_FIXUP_RESOLUTION_SEC is an integer number of cycles.
  f64  DELTRX_FIXUP_RESOLUTION_SEC()const{return 0.0001;}
  
private:
  void setDependentParameters();
  void checkParameterValidity();
  
private:
  enum {
    // Make all correction flags a power of 2 for bit packing.
    IONO_CORR =  0x1,
    TROPO_CORR = 0x2
  };
  // When enabled, Navsol allows only phase-error-free signals and satellites
  // that satisfy the elevation mask to participate in the navigation solution.
  // Also, if averaging, Navsol only uses solutions which have converged within
  // the residual tolerance.
  bool ENFORCE_STRICT_SELECTION_;
  // Bitpacked corrections flags.
  u8  USE_CORR_; 
  bool ALLOW_DELTRX_FIXUPS_;
  // For a stationary receiver, set this to true to average the nav solution
  bool AVERAGE_NAV_SOLN_;
  // This averages over approximately 1/NAV_FILTER_K solutions 
  f32  NAV_FILTER_K_; 
  // Maximum permitted absolute value of receiver clock bias relative to true
  // GPS time, expressed in seconds.  If, due to clock drift or initialization
  // error, the absolute value of receiver clock bias exceeds this value, a
  // receiver clock fixup will be triggered.  As part of this clock fixup,
  // concomitant changes to pseudorange and carrier phase observables will be
  // made to keep the observables consistent, as required by the RINEX
  // standard (See RINEX discussion under "DEFINITION OF THE OBSERVABLES").
  // Larger values of MAX_ABS_DELTRX_METERS will lead to less frequent clock
  // fixups.  Due to constraints in how the fixup is performed and to avoid
  // overflow in the carrier phase container, MAX_ABS_DELTRX_SEC must satisfy
  // the following inequality: DELTRX_FIXUP_RESOLUTION_SEC() <=
  // MAX_ABS_DELTRX_SEC <= DELTRX_FIXUP_MAX_SEC()
  f64 MAX_ABS_DELTRX_SEC_; 
  // Elevation mask angle, in radians.  Signals arriving at the receiver below
  // the elevation mask angle will be excluded from the navigation solution.
  // Set to -PI/2 to prevent elevation masking.  In the receiver config file,
  // the elevation mask angle is given in degrees as ELEVATION_MASK_ANGLE_DEG.
  // Conversion occurs in NavSolConfig::importConfiguration.
  f64 ELEVATION_MASK_ANGLE_RAD_;
};

#endif
