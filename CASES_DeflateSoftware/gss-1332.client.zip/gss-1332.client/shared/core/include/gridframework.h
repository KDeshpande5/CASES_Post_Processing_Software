// gridframework.h
// 
// GRID Extension of the basic framework for programs in the GPS toolkit
// 
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __GRID_FRAMEWORK_H
#define __GRID_FRAMEWORK_H

#include "BasicFramework.hpp"

/** @defgroup appframegroup Framework for GRID Applications
  *
  * This is an extension of the GPStk BasicFramework class.
  * See BasicFramework for more documentation.
  */

class GRIDFramework : public gpstk::BasicFramework
{
public:


  /** Constructor for GRIDFramework.
  *
  * @param applName   name of the program (argv[0]).
  * @param applDesc   text description of program's function
  *                   (used by CommandOption help).
  */
  GRIDFramework( const std::string& applName,
                 const std::string& applDesc,
                 const std::string& programName,
                 const std::string& versionNumber,
                 const std::string& maintainerEmail );

  /// Destructor.
  virtual ~GRIDFramework() {};

  /** Process command line arguments. When this method is overridden,
  *  make sure to call the parent class's initialize().
  *
  * @param argc    same as main() argc.
  * @param argv    same as main() argv.
  * @param pretty  Whether the 'pretty print' option will be used when
  *                printing descriptions. It is 'TRUE' by default.
  *
  * @return true if normal processing should proceed (i.e. no
  *         command line errors or help requests).
  */
  virtual bool initialize( int argc,
                            char *argv[],
                            bool pretty = true )
      throw();

private:
  // Options
  gpstk::CommandOptionNoArg versionOption;
  
  std::string programName;
  std::string versionNumber;
  std::string maintainerEmail;

  // Do not allow the use of the default constructor.
  GRIDFramework();

};

#endif   // __GRID_FRAMEWORK_H
