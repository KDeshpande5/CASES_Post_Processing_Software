// channeltype.h
//
// ChannelType enumerations
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#ifndef __CHANNEL_TYPE_GRID_H
#define __CHANNEL_TYPE_GRID_H

#include "signaltype.h"

// ChannelType enumerates all possible channel types.  Some signal types are
// so similar (e.g., GPS_L2_CL and GPS_L2_CM) that it makes sense to track
// them with the same bank and channel "machinery."  We associate the bank and
// channel appropriate for tracking a subset of signal types with a unique
// channel type.  There is a many-to-one mapping from signal types to channel
// types.  For example, signal types GPS_L2_CL, GPS_L2_CM, and GPS_L2_CLM all
// map to CT_GPS_L2_C.  This mapping is defined by the function
// signalTypeToChannelTypeMap.
enum ChannelType {
  CT_GPS_L1_C,       // GPS L1 civil codes
  CT_GPS_L2_C,       // GPS L2 civil codes
  CT_CDMA,           // Cellular CDMA signals
  NUM_CHANNEL_TYPES,
  UNDEFINED_CHANNEL_TYPE = 255 // Initialization value
};

ChannelType signalTypeToChannelTypeMap(SignalType signalType);

#endif


