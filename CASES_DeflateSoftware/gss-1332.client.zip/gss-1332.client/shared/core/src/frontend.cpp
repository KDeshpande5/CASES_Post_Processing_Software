// frontend.cpp
//
// FrontEnd class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "frontend.h"
#include "util.h"
#include "serialutil.h"
#include "parameters.h"

FrontEnd::FrontEnd() {
  isInitialized_ = false;
  NUM_SUPPORTED_SIGNAL_TYPES_ = 0;
}

void FrontEnd::cleanup() {
  if(isInitialized_){
    delete[] SUPPORTED_SIGNAL_TYPES_;
    delete[] signalParameters_;
    isInitialized_ = false;
  }
}

void FrontEnd::createArrays() {
  cleanup();
  ASSERT(NUM_SUPPORTED_SIGNAL_TYPES_ != 0);
  SUPPORTED_SIGNAL_TYPES_ = new SignalType[NUM_SUPPORTED_SIGNAL_TYPES_];
  signalParameters_ = new SignalParameters[NUM_SUPPORTED_SIGNAL_TYPES_];
  isInitialized_ = true;
}

void FrontEnd::createBobynDualFreq(){
  name_ = "BOBYN_DUAL_FREQ";
  SAMPLE_FREQ_NUMERATOR_ = 40000000;
  SAMPLE_FREQ_DENOMINATOR_ = 7;
  QUANTIZATION_ = 2;
  NUM_SUPPORTED_SIGNAL_TYPES_ = 5;
  createArrays();
  SUPPORTED_SIGNAL_TYPES_[0] = GPS_L1_CA;
  SUPPORTED_SIGNAL_TYPES_[1] = GPS_L2_CM;
  SUPPORTED_SIGNAL_TYPES_[2] = GPS_L2_CL;
  SUPPORTED_SIGNAL_TYPES_[3] = GPS_L2_CLM;
  SUPPORTED_SIGNAL_TYPES_[4] = GPS_L1_CA_ALT1;
  signalParameters_[0].FREQ_IF_HZ_ = 1610476.19047612;
  signalParameters_[1].FREQ_IF_HZ_ = 1610989.01098901;
  signalParameters_[2].FREQ_IF_HZ_ = 1610989.01098901;
  signalParameters_[3].FREQ_IF_HZ_ = 1610989.01098901;
  signalParameters_[4].FREQ_IF_HZ_ = 1610476.19047612;
  signalParameters_[0].PLL_SIGN_FPLL_ = 1;
  signalParameters_[1].PLL_SIGN_FPLL_ = 1;
  signalParameters_[2].PLL_SIGN_FPLL_ = 1;
  signalParameters_[3].PLL_SIGN_FPLL_ = 1;
  signalParameters_[4].PLL_SIGN_FPLL_ = 1;
  signalParameters_[0].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[1].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[2].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[3].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[4].CODE_PHASE_BIAS_METERS_ = 0.0;
}

void FrontEnd::createMitelDualFreq(){
  name_ = "MITEL_DUAL_FREQ";
  SAMPLE_FREQ_NUMERATOR_ = 40000000;
  SAMPLE_FREQ_DENOMINATOR_ = 7;
  QUANTIZATION_ = 2;
  NUM_SUPPORTED_SIGNAL_TYPES_ = 5;
  createArrays();
  SUPPORTED_SIGNAL_TYPES_[0] = GPS_L1_CA;
  SUPPORTED_SIGNAL_TYPES_[1] = GPS_L2_CM;
  SUPPORTED_SIGNAL_TYPES_[2] = GPS_L2_CL;
  SUPPORTED_SIGNAL_TYPES_[3] = GPS_L2_CLM;
  SUPPORTED_SIGNAL_TYPES_[4] = GPS_L1_CA_ALT1;
  signalParameters_[0].FREQ_IF_HZ_ = 1.405396825396879e+006;
  signalParameters_[1].FREQ_IF_HZ_ = 1.405396825396879e+006 - 6086.9565;
  signalParameters_[2].FREQ_IF_HZ_ = 1.405396825396879e+006 - 6086.9565;
  signalParameters_[3].FREQ_IF_HZ_ = 1.405396825396879e+006 - 6086.9565;
  signalParameters_[4].FREQ_IF_HZ_ = 1.405396825396879e+006;
  signalParameters_[0].PLL_SIGN_FPLL_ = -1;
  signalParameters_[1].PLL_SIGN_FPLL_ = -1;
  signalParameters_[2].PLL_SIGN_FPLL_ = -1;
  signalParameters_[3].PLL_SIGN_FPLL_ = -1;
  signalParameters_[4].PLL_SIGN_FPLL_ = -1;
  signalParameters_[0].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[1].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[2].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[3].CODE_PHASE_BIAS_METERS_ = 0.0;
  signalParameters_[4].CODE_PHASE_BIAS_METERS_ = 0.0;
}

f64 FrontEnd::FREQ_IF_HZ(SignalType signalType) const {
  return signalParameters_[getIndex(signalType)].FREQ_IF_HZ_;
}
s32 FrontEnd::PLL_SIGN_FPLL(SignalType signalType) const {
  return signalParameters_[getIndex(signalType)].PLL_SIGN_FPLL_;
}
f64 FrontEnd::CODE_PHASE_BIAS_METERS(SignalType signalType) const {
  return signalParameters_[getIndex(signalType)].CODE_PHASE_BIAS_METERS_;
}

s32 FrontEnd::getIndex(SignalType signalType) const {
  s32 ii = util::findIndex<SignalType>(signalType,
                                       SUPPORTED_SIGNAL_TYPES_,
                                       NUM_SUPPORTED_SIGNAL_TYPES_);
  ASSERT(ii != -1);
  return ii;
}

void FrontEnd::importConfiguration(const u32 * pa, s32& index){
  serialutil::gets64(pa, index, SAMPLE_FREQ_NUMERATOR_);
  serialutil::gets32(pa, index, SAMPLE_FREQ_DENOMINATOR_);
  serialutil::gets32(pa, index, QUANTIZATION_);
  serialutil::gets32(pa, index, NUM_SUPPORTED_SIGNAL_TYPES_);
  createArrays();
  for(s32 ii=0;ii<NUM_SUPPORTED_SIGNAL_TYPES_;ii++){
    serialutil::getu32(pa, index, reinterpret_cast<u32&>(SUPPORTED_SIGNAL_TYPES_[ii]));
    serialutil::getbin(pa, index,
                       reinterpret_cast<u8*>(&signalParameters_[ii]),
                       sizeof(signalParameters_[ii]));
  }
}

void FrontEnd::exportConfiguration(u32 * pa, s32& index)const{
  serialutil::sets64(pa, index, SAMPLE_FREQ_NUMERATOR_);
  serialutil::sets32(pa, index, SAMPLE_FREQ_DENOMINATOR_);
  serialutil::sets32(pa, index, QUANTIZATION_);
  serialutil::sets32(pa, index, NUM_SUPPORTED_SIGNAL_TYPES_);
  for(s32 ii=0;ii<NUM_SUPPORTED_SIGNAL_TYPES_;ii++){
    serialutil::setu32(pa, index, SUPPORTED_SIGNAL_TYPES_[ii]);
    serialutil::setbin(pa, index,
                       reinterpret_cast<const u8*>(&signalParameters_[ii]),
                       sizeof(signalParameters_[ii]));
  }
}

