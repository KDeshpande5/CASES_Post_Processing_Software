// txid.cpp
//
// TxId (transmitter identifier) class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#include "txid.h"
#include "signaltype.h"

// Default constructor
TxId::TxId(){
  init();
}

// Constructor
TxId::TxId(System system, s32 number){
  system_ = system;
  number_ = number;
}

// Copy constructor
TxId::TxId(const TxId& txId){
  system_ = txId.system_;
  number_ = txId.number_;
}

// Initializer
void TxId::init(){
  system_ = UNDEFINED_SYSTEM;
  number_ = -1;
}

// Validity check
bool TxId::isValid() const {

  if(system_ == UNDEFINED_SYSTEM ||
     number_ < 0)
    return false;

  return true;
}

// Assignment operator
TxId& TxId::operator = (const TxId& txId){
  if(this == &txId)
    return *this;
  system_ = txId.system_;
  number_ = txId.number_;
  return *this;
}

// Post-increment operator
TxId TxId::operator++(int){
  TxId txIdTemp(*this);
  number_++;
  if(system_ == GPS && number_ > GPS_SVID_MAX)
    number_ = GPS_SVID_MIN;
  return txIdTemp;
}

// Logical equal-to operator
bool operator == (const TxId& txId1, const TxId& txId2){
  return (txId1.system() == txId2.system() &&
          txId1.number() == txId2.number());
}

// Logical not-equal-to operator
bool operator != (const TxId& txId1, const TxId& txId2){
  return ((txId1 == txId2) ? false : true);
}



