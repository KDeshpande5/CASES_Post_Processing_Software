// util.cpp
//
// General utility functions
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cstdlib>
#include "util.h"

namespace util {

  // clearDisplayScreen
  //
  // Platform-independent method for clearing the display screen.
  //
  void clearDisplayScreen(){
#ifndef DSPARCH
#ifdef __CYGWIN__
;
#elif WIN32 // any other cases to catch here?
    system("cls"); 
#else
    system("clear");
#endif
#endif

  }
  
} // namespace




