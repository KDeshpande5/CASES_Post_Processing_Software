// binhelper.cpp
// 
// Binflate helper functions
// 
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "binhelper.h"
#include "report.h"
#include "ReportWrapper.h"
#include <ios>

// Global variable
bool gRunning = true;

// checkVersionAndAlign
//
// Check to ensure that the version number of incoming reports matches the
// version number of reports with which binflate was compiled.  Also align the
// binary file pointer (as returned by binFile_.tellg()) with the beginning of
// a report.
//
ReturnValue checkVersionAndAlign(std::fstream& binFile, s32 waitTimeout,
                                 bool verboseLevel){

  char byteVal;
  u32 headerVal = 0;
  bool streaming = false;
  
  // Determine if streaming file
  binFile.seekg(0, std::ios::cur);
  streaming = !binFile.good();
  binFile.clear();
  if(streaming && verboseLevel)
    std::cout << "Detected streaming file." << std::endl;
  
  // Fill up buffer
  for(u32 ii=0; ii<8; ii++){
    if(!readFile(binFile, &byteVal, 1, waitTimeout, verboseLevel)){
      std::cerr << "Could not locate report version number in input file." 
            << std::endl;
      return RETVAL_FAILURE; 
    }
    headerVal = (headerVal >> 8) | (byteVal << 24);
  }
  
  // Check the version number of incoming reports
  while(true){
    if(((headerVal >> 8) & 0xFFFFFF) == Report::SYNCHRONIZATION_SEQUENCE){
      if((headerVal & 0xFF) == Report::VERSION){
        if(verboseLevel)
          std::cout << "Version number of incoming reports: " << 
            Report::VERSION << std::endl;
        if(streaming)
          // Ignore this report since we can't back up in a streaming file
          binFile.ignore(sizeof(ReportObservablesMeasurementTime)-8);
        else
          // Back up 8 bytes to align to the beginning of a report.
          binFile.seekg(-8, std::ios::cur);
        return RETVAL_SUCCESS;        
      }
      else{
        std::cerr << "Unrecognized report version number: " 
          << (headerVal & 0xFF) << "." << std::endl;
        return RETVAL_FAILURE;         
      }
    }
    if(!readFile(binFile, &byteVal, 1, waitTimeout, verboseLevel))
      break;
    headerVal = (headerVal >> 8) | (byteVal << 24);
  }
  std::cerr << "Could not locate report version number in input file." 
            << std::endl;
  return RETVAL_FAILURE; 
}

bool readFile(std::istream& logFile, char * buffer, u32 bytes, s32 waitTimeout,
              bool verboseLevel){

  s32 timeoutCounter = 0;
  u32 ii = 0;
  while(ii < bytes){
    ii += logFile.read(buffer + ii, bytes-ii).gcount();
    if(logFile.eof()){
      if(++timeoutCounter > waitTimeout && waitTimeout >= 0)
        return false;
      if(!gRunning)
        return false;
      if(verboseLevel) std::cout << "Waiting for data...\n";
      sleep(1); 
    }
    logFile.clear();
  }
  return true;
}


bool syncAndStripDummies(std::string inFileName, bool verboseLevel, std::string& outFileName){
  FILE *inFile, *outFile;
  bool retval=false;
  u8 inBuffer[REP_BUFFSIZE];
  bool go = true;
  s32 syncIdx, totalRead = 0;
  u32 j, size, dataRead=0;
  Report::ReportType reportType;
  
  inFile = fopen(inFileName.c_str(), "r");
  outFileName = inFileName;
  outFileName.append(".synced");
  outFile = fopen(outFileName.c_str(), "w+");
  if(!inFile || !outFile){
    if(verboseLevel)
      std::cout<<"Error: could not open input and/or output file.\n";
    retval = false;
    goto closeFiles;
  }
  
  while(go){
    fread(inBuffer,1, REP_BUFFSIZE, inFile);
    if(feof(inFile)){
      if(verboseLevel)
        std::cout << "Sync failed: insufficient data\n";
      retval = false;
      goto closeFiles;
    }
    totalRead+=REP_BUFFSIZE;
    if(ReportWrapper::attemptSync(inBuffer, syncIdx))
      go = false;
  }
  totalRead+=syncIdx;
  if(verboseLevel)
    std::cout<< "Synced at byte " << totalRead << "\n";
  fseek(inFile,syncIdx, SEEK_CUR);
  go = true;
  while(go){
    dataRead = fread(inBuffer, 1, REP_BUFFSIZE, inFile);
    j = 0;
    while(j<dataRead){
      reportType = Report::getReportTypeAndSize(*reinterpret_cast<u32*>(&inBuffer[j]), size);
      switch(reportType){
        // this works because we never completely fill up a buffer
        // see ReportWrapper::enqueue()
        case Report::DUMMY_REPORT:
          fwrite(inBuffer, 1, j, outFile);
          j = dataRead;
          break;
        case Report::IQ: 
        case Report::GNSS_OBSERVABLES:
        case Report::OBSERVABLES_MEASUREMENT_TIME:
        case Report::NAVIGATION_SOLUTION:
        case Report::DATA_LOG_CONFIG:
        case Report::COMMAND_MSG:
        case Report::ASSIMILATOR_STATUS:
        case Report::TRANSMITTER_INFO:
        case Report::IQ_METADATA:
        case Report::SCINTILLATION_PARAMETERS:
        case Report::IONOSPHERE:
        case Report::DIAGNOSTICS_INFO:
        case Report::TASK_CPU:
        case Report::BENCHMARK:
          j+=size;
          break;
        default:
          std::cout << "Warning: found unknown report type "<< reportType << " at "<< j << std::endl; 
          j = dataRead;
          break;
      }
    }
    totalRead+=dataRead;
    if(feof(inFile)){
      if(verboseLevel)
        std::cout << "Sync complete, processed " << totalRead <<" bytes \n";
      retval = true;
      go = false;
    }
  }
  closeFiles:
  fclose(inFile);
  fclose(outFile);
  return retval;
}

















