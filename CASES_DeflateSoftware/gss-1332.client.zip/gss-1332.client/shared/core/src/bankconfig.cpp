// bankconfig.cpp
//
// BankConfig class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cmath>
#include "bankconfig.h"
#include "util.h"
#include "serialutil.h"

f64 computeQuantSum(const s32 Na, const s32 * a, const f64 * p_a){
  f64 sum = 0;
  for(s32 ii=0; ii<Na; ii++)
    sum += a[ii]*a[ii]*p_a[ii];
  return sum;
}

// See Section 3 of "CALCULATING THE CARRIER-TO-NOISE RATIO IN A GPS RECEIVER".
s32 computeTwoSigmaIQSq(const s32 Na, const s32 * a, const f64 * p_a, f64 N){
  // Compute quantization values for local carrier replica.
  const s32 Nb = 2;
  const s32 b[Nb] = {1, 3};
  f64 p_b[Nb];
  p_b[0] = std::asin(LOCAL_CARRIER_THRESH)/(PI/2);
  p_b[1] = 1-p_b[0];
  
  f64 sum_FE = computeQuantSum(Na, a, p_a);
  f64 sum_LC = computeQuantSum(Nb, b, p_b);
  return static_cast<s32>(std::floor(2*N*sum_FE*sum_LC + 0.5));
}

void BankConfig::updateTwoSigmaIQSq(s32 numOnesM, s32 numBitsM){
  const s32 Na = 2;
  const s32 a[Na] = {1, 3};
  f64 p_a[Na];
  p_a[1] = static_cast<f64>(numOnesM)/numBitsM;
  p_a[0] = 1-p_a[1];
  
  TWO_SIGMAIQSQ_ = computeTwoSigmaIQSq(Na, a, p_a, NOM_SAMPS_PER_SUBACCUM_);
  TWO_SIGMAIQSQ_FFTACQ_ = 
    static_cast<s32>(std::floor(TWO_SIGMAIQSQ_*(FFT_NFFT/NOM_SAMPS_PER_SUBACCUM_) + 0.5)); 
  FLL_WEAK_THRESH_ = 3*TWO_SIGMAIQSQ_;
}

void BankConfig::checkParameterValidity(){
  ASSERT(NUM_CHIPS_PER_CODE() % NUM_CHIPS_PER_SUBACCUM() == 0);
}

void BankConfig::setDependentParameters(){
  checkParameterValidity();
  NUM_SUBACCUM_PER_CODE_ = NUM_CHIPS_PER_CODE()/NUM_CHIPS_PER_SUBACCUM();
  SUBACCUM_PERIOD_ = NUM_CHIPS_PER_SUBACCUM()/NOM_CHIPRATE_CPS();
  TACCUM_SEC_ = SUBACCUM_PERIOD()*NUM_SUBACCUM_PER_ACCUM();  
  SAMPLE_FREQ_HZ_ = 
    static_cast<f64>(SAMPLE_FREQ_NUMERATOR())/SAMPLE_FREQ_DENOMINATOR();
  DELTA_T_ = 1.0/SAMPLE_FREQ_HZ_;
  FREQ_IF_PIC_AND_FRAC_PIC_ = static_cast<u64>(std::floor(
    FREQ_IF_HZ()*DELTA_T_*SF_P*SF_F + 0.5));
  FP_FREQ_CARRIER_HZ_ = static_cast<s64>(std::floor(FREQ_CARRIER_HZ()*SF_S + 0.5));
  FREQ_CARRIER_PIC_ = 
    static_cast<s64>(std::floor(FREQ_CARRIER_HZ()*DELTA_T_*SF_P + 0.5));
  NOM_SAMPS_PER_SUBACCUM_ =
    SAMPLE_FREQ_HZ_*SUBACCUM_PERIOD();
  FP_NOM_SAMPS_PER_SUBACCUM_ = 
    static_cast<s64>(std::floor(NOM_SAMPS_PER_SUBACCUM_*SF_H + 0.5));
  FLOOR_NOM_SAMPS_PER_SUBACCUM_ = 
    static_cast<s32>(std::floor(NOM_SAMPS_PER_SUBACCUM_));
  CEIL_NOM_SAMPS_PER_SUBACCUM_ = 
    static_cast<s32>(std::ceil(NOM_SAMPS_PER_SUBACCUM_));
  DELTA_SAMPS_PER_SUBACCUM_ = NOM_SAMPS_PER_SUBACCUM_*(1./(1 - 
    (FFT_DOPP_FREQ_STEP/2.)/FREQ_CARRIER_HZ()) - 1); 
  FP_DELTA_SAMPS_PER_SUBACCUM_ = 
    static_cast<s64>(std::floor(DELTA_SAMPS_PER_SUBACCUM_*SF_H + 0.5)); 
  FFT_DELT_ = SUBACCUM_PERIOD()/FFT_NFFT;
  FP_FFT_DX_ = 
    static_cast<s32>(std::floor((FFT_DELT_/DELTA_T_)*SF_I));
  FFT_CYC_PER_SAMP_ =  static_cast<f32>((0x1<<SF_DDSL)*.001)/FFT_NFFT;
  CH_IQSQ_FILTER_K_ = 
    static_cast<f32>(TACCUM_SEC_/CH_IQSQ_FILTER_TAU_SEC()); 
  CH_IQSQ_FILTER_K_SUB_ = 
    static_cast<f32>(SUBACCUM_PERIOD()/CH_IQSQ_FILTER_TAU_SEC());  
  FLL_TRANSIENT_NOM_MS_ = 
    static_cast<s32>(std::ceil(5.0F/(4.0F*FLL_NOM_BANDWIDTH_HZ()*SUBACCUM_PERIOD()))); 
  FLL_TRANSIENT_WEAK_MS_ = 
    static_cast<s32>(std::ceil(5.0F/(4.0F*FLL_WEAK_BANDWIDTH_HZ()*SUBACCUM_PERIOD())));  
  FLL_WEAK_THRESH_ = 0;
  TWO_SIGMAIQSQ_ = 0;
  TWO_SIGMAIQSQ_FFTACQ_ = 0;
  FP_CH_IQSQ_FILTER_K_SUB_ = 
    static_cast<s32>(std::floor(CH_IQSQ_FILTER_K_SUB_*SF_S + 0.5));
  
  setDependentParametersDerived();
}

void BankConfig::setCarrierGenerator(const CarrierGenerator* c){
  carrierGenerator_=c;
  if(c!=NULL){
    FP_IF_OFFSET_ = static_cast<s64>(std::floor((c->config().InterFreqHz-
                                                 FREQ_IF_HZ())*SF_B*DELTA_T_+0.5));
    NWORD_PER_SUBACCUM_ = c->NWORD_PER_SUBACCUM();
  }
}

void BankConfig::importConfiguration(const u32 * pa, s32& index){
  serialutil::getbin(pa, index, reinterpret_cast<u8*>(&indep_), sizeof(indep_));
  importConfigurationDerived(pa, index);
  setDependentParameters();
}

void BankConfig::exportConfiguration(u32 * pa, s32& index)const{
  serialutil::setbin(pa, index, reinterpret_cast<const u8*>(&indep_), sizeof(indep_));
  exportConfigurationDerived(pa, index);
}
  

