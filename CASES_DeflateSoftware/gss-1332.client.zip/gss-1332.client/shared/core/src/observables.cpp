// observables.cpp
//
// Observables classes
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "observables.h"

BaseTime Observables::tMeasurement_;
BaseTime Observables::tOffset_;
bool Observables::tOffsetValid_ = false;


// init_tOffset
//
// Initialize the offset time to zero and set validity to false for all
// instantiated Observables objects.
//
void Observables::init_tOffset(){
  tOffset_.init();
  tOffsetValid_ = false;
}

void  Observables::set_tMeasurement(const BaseTime& tMeasurement){
  tMeasurement_ = tMeasurement;
}

void  Observables::set_tOffset(const BaseTime& tOffset){
  tOffset_ = tOffset;
}

void  Observables::set_tOffsetValid(bool tOffsetValid){
  tOffsetValid_ = tOffsetValid;
}

void  Observables::set_signalType(SignalType signalType){
  signalType_ = signalType;
}

void  Observables::set_nChannels(s32 nChannels){
  nChannels_ = nChannels;
}
