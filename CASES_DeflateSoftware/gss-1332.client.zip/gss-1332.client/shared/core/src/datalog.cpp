// datalog.cpp
//
// DataLog class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "datalog.h"
#include "util.h"
#include "serialutil.h"

void displayAndLogChannel(s32 channelIn,
                          const ReportGnssObservables& rpObs, 
                          const std::vector<ReportTransmitterInfo>& rpTxInfo,
                          const ReportObservablesMeasurementTime& rpTime,
                          FILE * displayFp,
                          FILE * logFp);

#ifdef WIN32
  const char* nullName = "nul";
#else
  const char* nullName = "/dev/null";
#endif
// Where we send output when we don't actually want to display it
FILE * nullFp = fopen(nullName, "w");

DataLog::DataLog(){
  logFilePointers_.resize(NUM_LOG_TYPES);
  for(u32 ii=0;ii<logFilePointers_.size();ii++)
    logFilePointers_[ii] = NULL;
  uploadCommand_ = "\n";
  redrawPeriod_ = 1;
  isConfigured_ = false;
  isAssimilator_ = false;
  receivedReportTaskCpu_ = false;
  receivedReportBenchmark_ = false;
  reportId_ = 0;
  buildId_ = 0;
  firstFlag = true;
  rpTime_.init();
  init();
}

DataLog::~DataLog(){
  cleanup();
  for(u32 ii=0;ii<logFilePointers_.size();ii++)
    closeLog(static_cast<LogType>(ii));
}

void DataLog::cleanup(){
  if(isConfigured_){
    for(s32 nn=0;nn<numBanks_;nn++){
      delete[] rpObs_[nn];
    }
    delete[] rpObs_;
  }
  numBanks_ = 0;
  isConfigured_ = false;
}

void DataLog::init(){
  if(isConfigured_){
    for(s32 nn=0;nn<numBanks_;nn++)
      for(s32 ii=0;ii<numChannels_[nn];ii++)
        rpObs_[nn][ii].init();
  }
  else{
    numBanks_ = 0;
    for(s32 ii=0;ii<NUM_SIGNAL_TYPES;ii++){
      signalTypeToIndexMap_[ii] = -1;
      numChannels_[ii] = 0;
    }
  }
  rpNav_.init();
}

// insertReport
//
// Insert the report stored in tempArray into DataLog
//
// 1) Determine the report type.
// 2) Write the report as binary data to the binary output file.
// 3) Insert the report into the proper slot in DataLog (or, if the report is
//    a configuration report, use it to configure the DataLog object).
// 4) When a complete batch of reports has been assembled, display and log the
//    data.
//
// Note: To ensure that observables are synchronized with their time stamp
// (same reportId), always insert the ReportObservablesMeasurementTime report
// first in a batch of report insertions.  Also, to ensure that partial
// records can be interpreted, be sure to send ReportDataLogConfig reports
// periodically.  When presented with a new data stream, DataLog will not
// display or print to file until it has been configured by one or more
// ReportDataLogConfig objects.  A typical way to sequence the stream would be
// as follows:
//
// [ReportObservablesMeasurementTime,ReportDataLogConfig_1,ReportDataLogConfig_2,
// ..., ReportDataLogConfig_N, ReportGnssObservables, other reports of same
// batch, ReportObservablesMeasurementTime (of new batch), ...]
//
void DataLog::insertReport(u32 * tempArray){

  Report::ReportType reportType; 
  SignalType signalType; 
  s32 reportId,configId,txIdNum,channel,index,numChannels;
  u32 repSize = 0;
  f32 measIntervalLengthSec;
  s32 pllSignFpll,dataBit,refId;

  reportType = Report::getReportTypeAndSize(tempArray[0], repSize);
  // If DataLog is unconfigured, do not proceed unless incoming report is of type
  // DATA_LOG_CONFIG or OBSERVABLES_MEASUREMENT_TIME or IQ.
  if(!isConfigured_ && reportType != Report::DATA_LOG_CONFIG &&
     reportType != Report::OBSERVABLES_MEASUREMENT_TIME && reportType != Report::IQ &&
     reportType != Report::IQ_METADATA)
    return;
  switch(reportType){
  case Report::IQ:
    {
      ReportIQ * rPtr = reinterpret_cast<ReportIQ *>(tempArray);
      rPtr->unpackHeader(reportType,signalType,txIdNum,dataBit);
      rpIq_[signalType].push_back(*rPtr);
    }
    break;
  case Report::OBSERVABLES_MEASUREMENT_TIME:
    {
      ReportObservablesMeasurementTime * rPtr = 
        reinterpret_cast<ReportObservablesMeasurementTime *>(tempArray);
      if(firstFlag){
        rPtr->unpackHeader(reportType,signalType,reportId_);
        firstFlag = false;
      }
      rPtr->unpackHeader(reportType,signalType,reportId);
      // Process the received reports when a new reportId is detected.
      if(reportId != reportId_){
        reportId_ = reportId;
        // DataLog is complete; display and log data provided that DataLog is
        // configured.
        if(isConfigured_)
          displayAndLog();
        logTxInfoData();
        logIqData();
        if(isConfigured_)
          init();
      }
      // If a reset occured, then deinitialize object
      if(diff(rPtr->tMeasurement,rpTime_.tMeasurement) < 0.0)
        cleanup();
      rpTime_ = *rPtr;
    }
    break;
  case Report::GNSS_OBSERVABLES:
    {
      ReportGnssObservables * rPtr = 
        reinterpret_cast<ReportGnssObservables *>(tempArray);
      rPtr->unpackHeader(reportType,signalType,txIdNum,channel);
      index = signalTypeToIndexMap_[signalType];
      ASSERT(index!=-1);
      ASSERT(channel<numChannels_[index]);
      rpObs_[index][channel] = *rPtr;
    }
    break;
  case Report::NAVIGATION_SOLUTION:
    {    
      ReportNavigationSolution * rPtr = 
        reinterpret_cast<ReportNavigationSolution *>(tempArray);
      rpNav_ = *rPtr;  
    }
    break;
  case Report::ASSIMILATOR_STATUS:
    {
      ReportAssimilatorStatus * rPtr = 
        reinterpret_cast<ReportAssimilatorStatus *>(tempArray);
      rpAssim_ = *rPtr;
      if(!isAssimilator_)
        isAssimilator_ = true;
    }
    break;
  case Report::DATA_LOG_CONFIG:
    {
      ReportDataLogConfig * rPtr = 
        reinterpret_cast<ReportDataLogConfig *>(tempArray);
      rPtr->unpackHeader(reportType,configId,signalType,numChannels);
      buildId_ = rPtr->buildId();
      
      if(!isConfigured_){
        // if signalType == UNDEFINED_SIGNAL_TYPE then this is the last
        // DataLog config report for the current configId. We can now
        // initialize the object.
        if(signalType == UNDEFINED_SIGNAL_TYPE){
          rpObs_ = new ReportGnssObservables*[numBanks_];
          for(s32 nn=0;nn<numBanks_;nn++){
            rpObs_[nn] = new ReportGnssObservables[numChannels_[nn]];
          }
          isConfigured_ = true;
          for(s32 ii=0;ii<NUM_SIGNAL_TYPES;ii++)
            rpIqMetadata_[ii].init();
          init();
          openLog(CHANNEL);
        }else{
          if(numChannels>0){
            signalTypeToIndexMap_[signalType] = numBanks_;
            numChannels_[numBanks_] = numChannels;
            numBanks_++;
          }
        }
      }
    }
    break;
  case Report::TRANSMITTER_INFO:
    {
      ReportTransmitterInfo * rPtr = 
        reinterpret_cast<ReportTransmitterInfo *>(tempArray);
      rpTxInfo_.push_back(*rPtr);
    }
    break;
  case Report::IQ_METADATA:
    {
      ReportIQMetadata * rPtr =
        reinterpret_cast<ReportIQMetadata *>(tempArray);
      rPtr->unpackHeader(reportType,signalType,pllSignFpll);
      rpIqMetadata_[signalType] = *rPtr;
    }
    break;
  case Report::SCINTILLATION_PARAMETERS:
    {
      ReportScintillationParameters * rPtr =
        reinterpret_cast<ReportScintillationParameters *>(tempArray);
      rPtr->unpackHeader(reportType, signalType, txIdNum, refId);
      rPtr->unpackHeader2(measIntervalLengthSec);
      if(logFilePointers_[SCINT] == NULL)
        if(openLog(SCINT))
          break;
      fprintf(logFilePointers_[SCINT],
              "%5d  %6d  %14.12f  %4.1f  %4.3f  %4.3f  %4.3f  %5.3f  %5.3f"
              "  %5.3f  %5.3f  %7.3f  %2d  %2d  %2d \n",
              rPtr->tReceiver.getWeek(),
              rPtr->tReceiver.getSecondsOfWeek(),
              rPtr->tReceiver.getFractionOfSecond(),
              measIntervalLengthSec,
              rPtr->S4_Full, rPtr->S4_Half[0], rPtr->S4_Half[1],
              rPtr->sigmaPhi_Full, rPtr->sigmaPhi_Half[0], rPtr->sigmaPhi_Half[1],
              rPtr->tau0, rPtr->SPRdB, refId, signalType, txIdNum);
    }
    break;
  case Report::IONOSPHERE:
    {
      if(logFilePointers_[IONO]==NULL)
        if(openLog(IONO))
          break;
      f32 tec;
      ReportIonosphere * rPtr = 
        reinterpret_cast<ReportIonosphere *>(tempArray);
      rPtr->unpackHeader(reportType, txIdNum);
      rPtr->unpackHeader2(tec);
      fprintf(logFilePointers_[IONO], "%5d  %6d  %14.12f  %8.3f  %10.6f  %2d\n",
              rPtr->tReceiver.getWeek(),
              rPtr->tReceiver.getSecondsOfWeek(),
              rPtr->tReceiver.getFractionOfSecond(),
              tec,rPtr->deltaPhiTec,txIdNum);
      break;
    }
  case Report::DIAGNOSTICS_INFO:
    {
      ReportDiagnosticsInfo * rPtr = 
        reinterpret_cast<ReportDiagnosticsInfo *>(tempArray);
      rpDiagsInfoVec_.push_back(*rPtr);
    }
    break;
  case Report::TASK_CPU:
    {
      receivedReportTaskCpu_ = true;
      Report::TaskId taskId;
      ReportTaskCpu * rPtr = 
        reinterpret_cast<ReportTaskCpu *>(tempArray);
      rPtr->unpackHeader2(taskId);
      rpTaskCpuArray_[taskId] = *rPtr;
    }
    break;
  case Report::BENCHMARK:
    {
      receivedReportBenchmark_ = true;
      Report::BenchmarkId benchmarkId;
      ReportBenchmark * rPtr = 
        reinterpret_cast<ReportBenchmark *>(tempArray);
      rPtr->unpackHeader2(benchmarkId);
      rpBenchmarkArray_[benchmarkId] = *rPtr;
    }
    break;
  default:
    fprintf(stderr, "Unknown report type %d!\n", reportType);
  }
  if(logFilePointers_[BINARY]!=NULL)
    fwrite(tempArray, repSize, 1, logFilePointers_[BINARY]);
}

// displayAndLog
//
// Format and print contents of DataLog.
// 
void DataLog::displayAndLog(){
  static int refreshPeriod = 0;
  BaseTime tSolutionTrue = rpNav_.tSolution;
  tSolutionTrue.addSeconds(rpNav_.deltatRxMeters/SPEED_LIGHT_MPS);
  FILE* displayFP;
  Report::TaskId taskId;
  Report::BenchmarkId benchmarkId;
  Report::DiagnosticsType diagnosticsType;

  // If refreshPeriod periods have elapsed, create the display output file
  // otherwise just log the data to file.
  if(++refreshPeriod==redrawPeriod_)
    displayFP = logFilePointers_[DISPLAY];
  else
    displayFP = nullFp;
  if(displayFP==stdout)
    util::clearDisplayScreen();
  else
  rewind(displayFP);
#if 0
    fprintf(displayFP,"\n============ GRID: General Radionavigation Interfusion Device =============\n");
#else
    // Previous name
  fprintf(displayFP,"\n=============== GRID: GNSS Receiver Implementation on a DSP ===============\n");
#endif
  fprintf(displayFP,  " Receiver time: %4d weeks %8.1f seconds        Build ID:  %10d\n",
          rpTime_.tMeasurement.getWeek(),
          rpTime_.tMeasurement.getSecondsOfWeek() +
          rpTime_.tMeasurement.getFractionOfSecond(),
          buildId_);
  fprintf(displayFP,  " GPS time:      %4d weeks %8.1f seconds\n",
          tSolutionTrue.getWeek(),
          tSolutionTrue.getSecondsOfWeek() + tSolutionTrue.getFractionOfSecond());
  if(numBanks_>0){
    fprintf(displayFP,"---------------------------------------------------------------------------\n");
    fprintf(displayFP,"CH  TXID    Doppler       BCP           PR      C/N0     Az     El   Status\n");  
    fprintf(displayFP,"             (Hz)       (cycles)     (meters)  (dB-Hz)  (deg)  (deg)        \n");
    for(s32 nn=0;nn<numBanks_;nn++){
      s32 signalType = util::findIndex<s32>(nn,signalTypeToIndexMap_,NUM_SIGNAL_TYPES);
      ASSERT(signalType!=-1);
      fprintf(displayFP,"-------------------------%s Channels-----------------",
              (getSignalTypeNames()[signalType]).c_str());
      s32 nHyphens = 24 - (getSignalTypeNames()[signalType]).size();
      for(s32 ii=0;ii<nHyphens;ii++) fprintf(displayFP,"-");
      fprintf(displayFP,"\n");
      for(s32 ii=0;ii<numChannels_[nn];ii++)
        displayAndLogChannel(ii,rpObs_[nn][ii],rpTxInfo_,
                             rpTime_,displayFP,logFilePointers_[CHANNEL]);
    }
  }
  fprintf(displayFP,  "------------------------------Navigation Data------------------------------\n");
  fprintf(displayFP,  " X: %11.2f   Y: %11.2f   Z: %11.2f   deltRx: %12.2f\n", 
          rpNav_.xval,rpNav_.yval,rpNav_.zval,rpNav_.deltatRxMeters);
  fprintf(displayFP,  " Xvel: %8.2f   Yvel: %8.2f   Zvel: %8.2f   deltRxDot: %9.2f \n" ,
          rpNav_.xvelocity,rpNav_.yvelocity,rpNav_.zvelocity,
          rpNav_.deltatRxDotMetersPerSecond);
  if(isAssimilator_) {
    Report::ReportType reportType;
    s32 databitPredictionEnabled, phaseLockEnabled, feedbackEnabled, equalizeAmplitude;
    u32 digitalAttenuatorSettingdB;
    rpAssim_.unpackHeader(reportType, databitPredictionEnabled, phaseLockEnabled, 
                          feedbackEnabled, equalizeAmplitude, digitalAttenuatorSettingdB);
    fprintf(displayFP,  "----------------------------Assimilator Status-----------------------------\n");
    fprintf(displayFP,  "dX: %11.2f  dY: %11.2f  dZ: %11.2f  ddeltRx: %11.2f\n", 
            rpAssim_.dxval,rpAssim_.dyval,rpAssim_.dzval,
            rpAssim_.ddeltatRxMeters);
    fprintf(displayFP,  "dXvel: %8.2f  dYvel: %8.2f  dZvel: %8.2f  ddeltRxDot: %8.2f \n",
            rpAssim_.dxvelocity,rpAssim_.dyvelocity,rpAssim_.dzvelocity,
            rpAssim_.ddeltatRxDotMetersPerSecond);
    fprintf(displayFP,  " tIndexkAlignmentOffset:   %4d    tFracIndexkAlignmentOffset: %4d \n",
            rpAssim_.tIndexkAlignmentOffset, rpAssim_.tFracIndexkAlignmentOffset);
    fprintf(displayFP,  " databitPredictionEnabled: %4d    phaseLockEnabled:           %4d \n",
            databitPredictionEnabled, phaseLockEnabled);
    fprintf(displayFP,  " feedbackEnabled:          %4d    equalizeAmplitude:          %4d \n",
            feedbackEnabled, equalizeAmplitude);
    fprintf(displayFP,  " digitalAttenuatorSetting: %4.1f dB\n",
            static_cast<f32>(digitalAttenuatorSettingdB)/2);
    fprintf(displayFP,  " spoofed SVs: ");
    for(s32 ii=TxId::GPS_SVID_MIN; ii<=TxId::GPS_SVID_MAX; ii++)
      if(rpAssim_.isSvSpoofed(ii))
        fprintf(displayFP,  "%d ", ii);
    fprintf(displayFP,  "\n");
  }
  if(receivedReportTaskCpu_){
    fprintf(displayFP,  "---------------------------------CPU Usage---------------------------------\n");
    fprintf(displayFP,  "                    Task Name              Percent CPU\n");
    for(u32 ii=0;ii < Report::NUM_TASK_IDS;ii++) {
      if(taskId != Report::NO_TASK_ID)
        fprintf(displayFP,"                    %-20s          %3d%%\n",
                rpTaskCpuArray_[ii].getTaskName().c_str(),
                rpTaskCpuArray_[ii].taskPercCpu);
    }
  }
  if(receivedReportBenchmark_){
    fprintf(displayFP,  "--------------------------------Benchmarks---------------------------------\n");
    fprintf(displayFP,  "    Benchmark Name             Avg Time       Max Time       Min Time\n");
    for(u32 ii=0;ii < Report::NUM_BENCHMARK_IDS;ii++) {
      rpBenchmarkArray_[ii].unpackHeader2(benchmarkId);
      if(benchmarkId != Report::NO_BENCHMARK_ID)
        fprintf(displayFP,"    %-20s     %10d     %10d     %10d\n",
                rpBenchmarkArray_[ii].getBenchmarkName().c_str(),
                rpBenchmarkArray_[ii].avgTime,rpBenchmarkArray_[ii].maxTime,
                rpBenchmarkArray_[ii].minTime);
    }
  }
  if(rpDiagsInfoVec_.size() != 0) {
    fprintf(displayFP,  "-----------------------------Diagnostics Info------------------------------\n");
    for(u32 ii=0;ii < rpDiagsInfoVec_.size();ii++) {
      rpDiagsInfoVec_[ii].unpackHeader2(diagnosticsType);
      fprintf(displayFP,"%d : %s\n",diagnosticsType,
              rpDiagsInfoVec_[ii].diagnosticsMessage);
    }
  }
  fprintf(displayFP,  "===========================================================================\n\n\n");
  fflush(displayFP);

  if(rpNav_.xval != 0)
    logNavData(); 
    
  if(refreshPeriod==redrawPeriod_){
    system(uploadCommand_.c_str());
    refreshPeriod=0;
  }
}

// Log IQ data
void DataLog::logIqData(){
  for(s32 nn=0; nn<NUM_SIGNAL_TYPES; nn++){
    if(rpIq_[nn].size() && rpIqMetadata_[nn].sampleFreqDenominator){
      if(logFilePointers_[IQ]==NULL)
        if(openLog(IQ)){
          rpIq_[nn].clear();
          continue;
        }
      BaseTime iqTime, fullTime;
      u64 tIndex;
      s32 tFracIndex,dataBit;
      Report::ReportType reportType; 
      SignalType signalType; 
      s32 txIdNum, scaleFactorPL;
      s64 scaleFactorP = 1;
      rpIqMetadata_[nn].unpackHeader2(scaleFactorPL);
      // compatibility with metadata reports before scaleFactor was stored
      if(scaleFactorPL == 0)
        scaleFactorPL = 37;
      scaleFactorP <<= scaleFactorPL;
      for(u32 ii=0; ii<rpIq_[nn].size(); ii++){
        rpIq_[nn][ii].unpackHeader(reportType,signalType,txIdNum,dataBit);
        rpIq_[nn][ii].unpackHeader2(tIndex, tFracIndex);
        iqTime.setWithTruncatedSampleTime(rpTime_.tMeasurement,
                                          tIndex, tFracIndex,
                                          rpIqMetadata_[nn].sampleFreqNumerator,
                                          rpIqMetadata_[nn].sampleFreqDenominator);
        s32 weekFull = iqTime.getWeek() + rpTime_.tOffset.getWeek();
        weekFull = (weekFull == 0 ? NV_WN_INVALID : weekFull);
        BaseTime iqTimeFull(weekFull,
                            iqTime.getSecondsOfWeek()+
                            rpTime_.tOffset.getSecondsOfWeek(),
                            iqTime.getFractionOfSecond()+
                            rpTime_.tOffset.getFractionOfSecond());
        fprintf(logFilePointers_[IQ], 
                "%5d   %16.10f  %5d  %6d  %14.12f  %18.6f  %8d  %8d  %2d  %2d  %2d \n",
                iqTime.getWeek(),
                iqTime.getSecondsOfWeek() + iqTime.getFractionOfSecond(),
                iqTimeFull.getWeek(),
                iqTimeFull.getSecondsOfWeek(),
                iqTimeFull.getFractionOfSecond(),
                static_cast<f64>(rpIq_[nn][ii].thetahat)/scaleFactorP, 
                rpIq_[nn][ii].I, rpIq_[nn][ii].Q, dataBit, signalType, txIdNum);
      }
      fflush(logFilePointers_[IQ]);
    }
    rpIq_[nn].clear();
  }
}

// log transmitter info data
void DataLog::logTxInfoData() {
  if(rpTxInfo_.empty())
    return;
  
  if(logFilePointers_[TXINFO]==NULL)
    if(openLog(TXINFO)){
      rpTxInfo_.clear();
      return;
    }
  
  s32 weekFull = rpTime_.tMeasurement.getWeek() + rpTime_.tOffset.getWeek();
  weekFull = (weekFull == 0 ? NV_WN_INVALID : weekFull);
  BaseTime tMeasurementFull(weekFull,
                            rpTime_.tMeasurement.getSecondsOfWeek()+
                            rpTime_.tOffset.getSecondsOfWeek(),
                            rpTime_.tMeasurement.getFractionOfSecond()+
                            rpTime_.tOffset.getFractionOfSecond());
  Report::ReportType reportType;
  SignalType signalType;
  s32 healthStatus,reportIdTime,reportIdInfo;
  TxId txId;
  rpTime_.unpackHeader(reportType,signalType,reportIdTime);
  for(u32 ii=0; ii<rpTxInfo_.size(); ii++){
    rpTxInfo_[ii].unpackHeader(reportType,healthStatus,reportIdInfo);
    if(reportIdTime!=reportIdInfo)
      fprintf(stderr, "Warning: mismatched time and txinfo reportIds\n");
    rpTxInfo_[ii].unpackHeader2(txId);
    fprintf(logFilePointers_[TXINFO],
            "%5d  %6d  %14.12f  %8.3f  %8.3f  %3d  %3d  %3d\n",
            tMeasurementFull.getWeek(),
            tMeasurementFull.getSecondsOfWeek(),
            tMeasurementFull.getFractionOfSecond(),
            rpTxInfo_[ii].azimuthDeg,rpTxInfo_[ii].elevationDeg,
            healthStatus,txId.system(),txId.number());
  }
  
  rpTxInfo_.clear();
}

// displayAndLogChannel
// 
// Display and log contents of a single channel.
//
// To prevent data logging (e.g., on the SBC), set logFp to NULL.
//
void displayAndLogChannel(s32 channelIn,
                          const ReportGnssObservables& rpObs, 
                          const std::vector<ReportTransmitterInfo>& rpTxInfo,
                          const ReportObservablesMeasurementTime& rpTime,
                          FILE * displayFp,
                          FILE * logFp){

  s32 weekFull = rpTime.tMeasurement.getWeek() + rpTime.tOffset.getWeek();
  weekFull = (weekFull == 0 ? NV_WN_INVALID : weekFull);
  BaseTime tMeasurementFull(weekFull,
                            rpTime.tMeasurement.getSecondsOfWeek()+
                            rpTime.tOffset.getSecondsOfWeek(),
                            rpTime.tMeasurement.getFractionOfSecond()+
                            rpTime.tOffset.getFractionOfSecond());
  Report::ReportType reportType; 
  SignalType signalType; 
  s32 reportIdObs,reportIdTime,txIdNum,channel; 
  ChannelStatus channelStatus;
  bool phaseErrorFlag,validObsFlag;
  rpTime.unpackHeader(reportType,signalType,reportIdTime);
  rpObs.unpackHeader(reportType,signalType,txIdNum,channel); 
  rpObs.unpackHeader2(channelStatus,phaseErrorFlag,reportIdObs,validObsFlag);
  f32 azDeg = 0.0;
  f32 elDeg = 0.0;
  TxId txIdInfo, txIdObs(getSystem(signalType),txIdNum);
  for(u32 kk=0;kk<rpTxInfo.size();kk++){
    rpTxInfo[kk].unpackHeader2(txIdInfo);
    if(txIdInfo == txIdObs){
      azDeg = rpTxInfo[kk].azimuthDeg;
      elDeg = rpTxInfo[kk].elevationDeg;
      break;
    }
  }   
  if(channelStatus >= STATUS_ACQUIRED){
    // See the header to insertReport() for more details on syncing reportIds.
    if(reportIdTime!=reportIdObs)
      fprintf(stderr, "Warning: mismatched time and obs reportIds\n");
    // Put a 'u' after the txIdNum to indicate invalid pseudorange/BCP due to
    // unhealthy SV or otherwise.
    fprintf(displayFp,"%2d   %2d%1c  %9.2f  %12.2f  %11.2f  %4.1f   %6.1f  %5.1f    %1d%1c\n", 
            channelIn+1,txIdNum,validObsFlag?' ':'u',rpObs.fpll,
            rpObs.thetahatk,rpObs.pseudoRange,
            rpObs.C_N0dB,azDeg,elDeg,channelStatus,
            phaseErrorFlag?'-':' ');
    if(logFp!=NULL){
      // Log channel data to file
      fprintf(logFp,"%5d   %16.10f  %5d  %6d  %14.12f  %10.4f  %18.6f  " 
              "%15.4f  %6.3f  %1d  %1d  %2d  %2d  %2d\n", 
              rpTime.tMeasurement.getWeek(),
              rpTime.tMeasurement.getSecondsOfWeek() + 
              rpTime.tMeasurement.getFractionOfSecond(),
              tMeasurementFull.getWeek(),
              tMeasurementFull.getSecondsOfWeek(),
              tMeasurementFull.getFractionOfSecond(),
              rpObs.fpll,rpObs.thetahatk,
              rpObs.pseudoRange,rpObs.C_N0dB,validObsFlag,
              phaseErrorFlag,channelStatus,signalType,txIdNum);
      fflush(logFp);
    }
  }
  else
    fprintf(displayFp,"%2d   --   ---------  ------------  -----------  ----   ------  -----    - \n",
            channelIn+1);
}

// logNavData
//
// Log navigation solution data to file
//
void DataLog::logNavData(){
  if(logFilePointers_[NAVSOL]==NULL)
    if(openLog(NAVSOL))
      return;
  Report::ReportType reportType;
  SolverResult solverResult;
  rpNav_.unpackHeader(reportType,solverResult);
  fprintf(logFilePointers_[NAVSOL], 
          "%5d  %6d  %14.12f  %16.6f  %16.6f  %16.6f  %16.6f   %10.4f"
          "   %10.4f   %10.4f   %10.4f  %2d\n",
          rpNav_.tSolution.getWeek(),
          rpNav_.tSolution.getSecondsOfWeek(), 
          rpNav_.tSolution.getFractionOfSecond(), 
          rpNav_.xval,rpNav_.yval,rpNav_.zval,rpNav_.deltatRxMeters,
          rpNav_.xvelocity,rpNav_.yvelocity,rpNav_.zvelocity,         
          rpNav_.deltatRxDotMetersPerSecond,
          solverResult);
}

void DataLog::setCommand(std::string& cmd){
  uploadCommand_ = cmd;
}

s32 DataLog::openLog(LogType lt){
  switch(lt){
  case CHANNEL:
    logFilePointers_[CHANNEL] = fopen("channel.log", "w");
    return logFilePointers_[CHANNEL]==NULL;
  case IQ:
    logFilePointers_[IQ] = fopen("iq.log", "w");
    return logFilePointers_[IQ]==NULL;
  case NAVSOL:
    logFilePointers_[NAVSOL] = fopen("navsol.log", "w");
    return logFilePointers_[NAVSOL]==NULL;
  case TXINFO:
    logFilePointers_[TXINFO] = fopen("txinfo.log", "w");
    return logFilePointers_[TXINFO]==NULL;
  case SCINT:
    logFilePointers_[SCINT] = fopen("scint.log", "w");
    return logFilePointers_[SCINT]==NULL;
  case IONO:
    logFilePointers_[IONO] = fopen("iono.log", "w");
    return logFilePointers_[IONO]==NULL;
  default:
    ASSERT(!"Unrecognized LogType.");
  }
}

s32 DataLog::closeLog(LogType lt){
  if(logFilePointers_[lt]==NULL)
    return 0;
  return fclose(logFilePointers_[lt]);
}


s32 DataLog::openBinlog(const std::string& binName){
  logFilePointers_[BINARY] = fopen(binName.c_str(), "wb+");
  if(logFilePointers_[BINARY]==NULL){
    fprintf(stderr, "Warning: failed to open fifo %s\n", binName.c_str());
    return -1;
  }
  return 0;
}

s32 DataLog::openDisplay(const std::string& dispName, s32 redrawPer){
  redrawPeriod_ = redrawPer;
  if(dispName.compare("stdout")==0)
    logFilePointers_[DISPLAY]=stdout;
  else
    logFilePointers_[DISPLAY] = fopen(dispName.c_str(),"w");
  return logFilePointers_[DISPLAY]==NULL;
}

