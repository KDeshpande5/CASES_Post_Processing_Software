// basetime.cpp
//
// BaseTime class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cmath>
#include <cstdlib>
#include "basetime.h"
#include "observables.h"

const f64 EPSILON = 1e-15;
s32 BaseTime::gpsWeekReference_ = 1600;

// Constructor
BaseTime::BaseTime(s32 week, s32 secondsOfWeek, f64 fractionOfSecond){
  set(week,secondsOfWeek,fractionOfSecond);
}


// Copy constructor
BaseTime::BaseTime(const BaseTime& right) 
  : week_(right.week_), 
    secondsOfWeek_(right.secondsOfWeek_), 
    fractionOfSecond_(right.fractionOfSecond_)
{}

// init
//
// Initialize a BaseTime object
void BaseTime::init(){
  week_ = 0;
  secondsOfWeek_ = 0;
  fractionOfSecond_ = 0.0;  
}

// disambiguateGpsWeek
//
// Disambiguate the 10-bit GPS week (which rolls over at GPS_WEEK_ROLLOVER)
// and return a full unambiguous GPS week.
//
// Notes: We choose the integer N that minimizes the cost function 
//
// J = abs(N*GPS_WEEK_ROLLOVER + WN - gpsWeekReference_)
//
s32 BaseTime::disambiguateGpsWeek(s32 WN){
  f64 WNr = static_cast<f64>(gpsWeekReference_);
  s32 N = static_cast<s32>(std::floor((WNr - WN)/GPS_WEEK_ROLLOVER + 0.5));
  return N*GPS_WEEK_ROLLOVER + WN;
}

// ensureApproximateGpsWeekReference
//
// Ensures that gpsWeekReference_ is a good approximation of the true
// unambiguous GPS week by comparing it with the predicted unambiguous GPS
// week derived from the GPS-UTC leap seconds.  Updates gpsWeekReference_ if
// it is not within less than GPS_WEEK_ROLLOVER/2 of the predicted value,
// making concomitant changes to other representations of receiver time as
// necessary.
//
//
// Notes: One can estimate the unambiguous GPS week number from the GPS - UTC
// leap seconds as follows:
//
// WNfullEstimate = p[0]*leapSeconds^2 + p[1]*leapSeconds + p[2]
//
// where p = [1.8727563730955 62.8957079152731 2.10714892392605] is a
// 2nd-order polynomial derived from a polynomial fit to historical leap
// second data. 
//
//
// INPUTS
//
// leapSeconds ------- GPS - UTC leap seconds, in seconds.
//
// WN ---------------- The 10-bit GPS week number taken from the GPS L1 C/A
//                     nagivation data stream (rolls over at 1024).
//
// OUTPUTS
// 
// (return value) ---- Returns true if gpsWeekReference_ was changed.
//
bool BaseTime::ensureApproximateGpsWeekReference(s32 leapSeconds, s32 WN){
  
  // leapSeconds = 0 means we're operating on simulated data with the default
  // leap seconds value (which is zero).  In this case, do not attempt to
  // update gpsWeekReference_.
  if(leapSeconds == 0)
    return false;

  const f64 p[3] = {1.8727563730955, 62.8957079152731, 2.10714892392605};
  f64 WNfullEstimateF = p[0]*leapSeconds*leapSeconds + p[1]*leapSeconds + p[2];
  s32 WNfullEstimate = static_cast<s32>(std::floor(WNfullEstimateF + 0.5));
  if(std::abs(WNfullEstimate - gpsWeekReference_) >= (GPS_WEEK_ROLLOVER/2)){
    // Observables::tOffset_ is now invalid and must be re-initialized.
    Observables::init_tOffset();
    gpsWeekReference_ = WNfullEstimate;
    return true;
  }
  return false;
}

// set
//
// Set time elements.
//
//
// INPUTS
// 
// week ------------- Unambiguous GPS week. 
//
// secondsOfWeek ---- Integer seconds of the GPS week. 
//
// fractionOfSecond - Fraction of second beyond the integer seconds of GPS
//                    week.
//
// Returns RETVAL_SUCCESS if set time is within expected range; otherwise
// returns RETVAL_FAILURE.
//
ReturnValue BaseTime::set(s32 week, s32 secondsOfWeek, f64 fractionOfSecond){
  
  week_ = week;
  secondsOfWeek_ = secondsOfWeek;
  fractionOfSecond_ = fractionOfSecond;
  return normalize();
}

// setWithTruncatedSampleTime
//
// Set a BaseTime object with time expressed in a reference BaseTime object
// that is close to but before the actual time, a truncated sample index tIndex 
// and fractional samples tFracIndex (scaled by SF_T).  The sampling rate in Hz 
// is assumed to be equal to the ratio of the integers sampFreqNumerator and
// sampFreqDenominator.  For example, the sampling frequency for the
// Zarlink/Plessey front end is 40e6/7 Hz, which would correspond to
// sampFreqNumerator = 40e6 and sampFreqDenominator = 7.  It is further
// assumed that double precision is sufficient to represent the time within a
// single interval of sampFreqDenominator seconds.
//
// Returns RETVAL_SUCCESS if set time is within expected range; otherwise
// returns RETVAL_FAILURE.
//
ReturnValue BaseTime::setWithTruncatedSampleTime(
                                         const BaseTime& ref,
                                         const u64 tIndex,
                                         const s32 tFracIndex,
                                         const s64 sampFreqNumerator, 
                                         const s32 sampFreqDenominator){
  const s32 truncL = 39-SF_SL;
  const u64 trunc = 1<<truncL;
  const u64 truncHalf = trunc>>1;
  const u64 truncM = trunc-1;
  ASSERT(tIndex < trunc);
  u64 nWholeSeconds = ref.week_*SEC_PER_WEEK + ref.secondsOfWeek_;
  u64 samplesTimesDenom = nWholeSeconds*sampFreqNumerator;
  f64 fracSecsTimesNum = ref.fractionOfSecond_*sampFreqNumerator;
  f64 fracSecsTimesNumFloor = std::floor(fracSecsTimesNum);
  samplesTimesDenom += static_cast<u64>(fracSecsTimesNumFloor);
  u64 reftIndex = samplesTimesDenom/sampFreqDenominator;
  u64 reftIndexRem = samplesTimesDenom%sampFreqDenominator;
  f64 fracSamples = (reftIndexRem+(fracSecsTimesNum-fracSecsTimesNumFloor))
    /sampFreqDenominator;
  s32 reftFracIndex = static_cast<s32>(std::floor(fracSamples*SF_T + 0.5));
  reftIndex += (reftFracIndex >> SF_TL);
  reftFracIndex = (reftFracIndex & SF_T_MASK);
  u64 fulltIndex = (reftIndex & ~truncM) | tIndex;
  u64 truncReftIndex = reftIndex & truncM;
  if(truncReftIndex >= truncHalf){
    if(tIndex < truncReftIndex-truncHalf)
      fulltIndex += trunc;
  }else{
    if(tIndex > truncReftIndex+truncHalf)
      fulltIndex -= trunc;
  }
  return setWithSampleTime(fulltIndex, tFracIndex,
                           sampFreqNumerator, sampFreqDenominator);
}

// setWithSampleTime
//
// Set a BaseTime object with time expressed in sample index tIndex and
// fractional samples tFracIndex (scaled by SF_T).  The sampling rate in Hz is
// assumed to be equal to the ratio of the integers sampFreqNumerator and
// sampFreqDenominator.  For example, the sampling frequency for the
// Zarlink/Plessey front end is 40e6/7 Hz, which would correspond to
// sampFreqNumerator = 40e6 and sampFreqDenominator = 7.  It is further
// assumed that double precision is sufficient to represent the time within a
// single interval of sampFreqDenominator seconds.
//
// Returns RETVAL_SUCCESS if set time is within expected range; otherwise
// returns RETVAL_FAILURE.
//
ReturnValue BaseTime::setWithSampleTime(const u64 tIndex,const s32 tFracIndex,
                                        const s64 sampFreqNumerator, 
                                        const s32 sampFreqDenominator){

  // Why is this done every function call?  This constant is calculated
  // in parameters.cpp and its value will never change.                                
  const f64 delt = (static_cast<f64>(sampFreqDenominator))/sampFreqNumerator;
  // One interval is equal to sampFreqDenom seconds
  const s32 nWholeIntervals = static_cast<s32>(tIndex/sampFreqNumerator);
  // Whole samples remaining after an integer number of whole intervals has
  // been removed
  const s32 nWholeRemainingSamples = static_cast<s32>(tIndex % sampFreqNumerator);
  const f64 secondsWithinFractionalInterval = 
    (static_cast<f64>(nWholeRemainingSamples) + 
     (static_cast<f64>(tFracIndex)/SF_T))*delt;
  const s32 nWholeSecondsInWholeIntervals = nWholeIntervals*sampFreqDenominator;
  const s32 nWholeSecondsWithinFractionalInterval = 
    static_cast<s32>(std::floor(secondsWithinFractionalInterval));
  
  week_ = nWholeSecondsInWholeIntervals/SEC_PER_WEEK;
  secondsOfWeek_ = (nWholeSecondsInWholeIntervals % SEC_PER_WEEK) + 
    nWholeSecondsWithinFractionalInterval;
  fractionOfSecond_ = secondsWithinFractionalInterval - 
    nWholeSecondsWithinFractionalInterval;

  return normalize();
}

// setWithNavDataTime
//
// Set a BaseTime object with time expressed in parameters derived from the
// GPS L1 C/A navigation data.  The input 'week' is assumed to be a 10-bit GPS
// week representation (which rolls over at GPS_WEEK_ROLLOVER). The BaseTime
// object will correspond to the beginning of the iiSubSym period within the
// data bit identified by index iiDataBit.
//
// Returns RETVAL_SUCCESS if set time is within expected range.  Otherwise
// returns RETVAL_FAILURE.
//
ReturnValue BaseTime::setWithNavDataTime(const u32 week,const u32 truncTOW,
                                         const u32 iiDataBit,const u32 iiSubSym, 
                                         const f64 secPerSubaccum){
  const s32 secPerTruncTOW = 6;
  const f64 secPerDataBit = 0.02;
  f64 temp = iiDataBit*secPerDataBit + iiSubSym*secPerSubaccum;
  f64 integerSeconds;
  f64 fractionalSeconds = std::modf(temp,&integerSeconds);
  s32 nWholeSecondsOfWeek = 
    truncTOW*secPerTruncTOW + static_cast<s32>(integerSeconds);
  s32 unambiguousWeek = disambiguateGpsWeek(week);
  return set(unambiguousWeek,nWholeSecondsOfWeek,fractionalSeconds);
}

// get
//
// Get time elements.
//
void BaseTime::get(s32& week, s32& secondsOfWeek, f64& fractionOfSecond) const {
  week = week_;
  secondsOfWeek = secondsOfWeek_;
  fractionOfSecond = fractionOfSecond_;
}

// Assignment operator
BaseTime& BaseTime::operator=(const BaseTime& right){
  week_ = right.week_;
  secondsOfWeek_ = right.secondsOfWeek_;
  fractionOfSecond_ = right.fractionOfSecond_;
  return *this;
}

// Equality operator
bool BaseTime::operator==(const BaseTime& right) const {
  const f64 epsilon = 1.0e-13;
  return (week_ == right.week_ &&
          secondsOfWeek_ == right.secondsOfWeek_ &&
          std::fabs(fractionOfSecond_ - right.fractionOfSecond_) < epsilon);
}

// Non-equality operator
bool BaseTime::operator!=(const BaseTime& right) const {
  return (!operator==(right)); 
}

// Add seconds to the BaseTime object.  To preserve precision, the number of
// seconds added is required to be less than SEC_PER_WEEK.
BaseTime& BaseTime::addSeconds(f64 seconds){
  ASSERT(std::fabs(seconds) < static_cast<f64>(SEC_PER_WEEK));
  add(0,0,seconds);
  return *this;
}

// Difference operator with output as a BaseTime object
BaseTime BaseTime::operator-(const BaseTime& right) const {

  return BaseTime(*this).add(-right.week_,-right.secondsOfWeek_,
                             -right.fractionOfSecond_);
}

// Addition operator with BaseTime operand
BaseTime BaseTime::operator+(const BaseTime& right) const {

  return BaseTime(*this).add(right.week_,right.secondsOfWeek_,
                             right.fractionOfSecond_);
}

// add
//
// Add quantities to the BaseTime elements.
//
BaseTime& BaseTime::add(const s32 week,const s32 secondsOfWeek,
                        const f64 fractionOfSecond){
  week_ += week;
  secondsOfWeek_ += secondsOfWeek;
  fractionOfSecond_ += fractionOfSecond;
  ReturnValue retVal = normalize();
  ASSERT(retVal == RETVAL_SUCCESS);
  return *this;
}

// normalize
//
// Normalize the time element values to their expected ranges.  Returns
// RETVAL_SUCCESS if all time quantities remain within bounds.  Otherwise
// returns RETVAL_FAILURE.
//
ReturnValue BaseTime::normalize(){

  if(std::fabs(fractionOfSecond_) >= 1.0){
    s32 sec = static_cast<s32>(fractionOfSecond_);
    secondsOfWeek_ += sec;
    fractionOfSecond_ -= static_cast<f64>(sec);
  }
  // volatile keywork here because of TI optimizer bug
  if(std::abs(secondsOfWeek_) >= SEC_PER_WEEK){
    volatile s32 week = secondsOfWeek_/SEC_PER_WEEK;
    week_ += week;
    secondsOfWeek_ -= (week*SEC_PER_WEEK);
  }
  if(std::fabs(fractionOfSecond_) < EPSILON){
    fractionOfSecond_ = 0.0;
  }
  if(fractionOfSecond_ < 0){
    fractionOfSecond_ += 1.0;
    --secondsOfWeek_;
  }
  if(secondsOfWeek_ < 0){
    secondsOfWeek_ += SEC_PER_WEEK;
    --week_;
  }
  if((week_ < GPS_WEEK_MIN) || (week_ > GPS_WEEK_MAX)){
    return RETVAL_FAILURE;
  }
  return RETVAL_SUCCESS;
}

// Small-difference operator with output in seconds: result = left-right.
// Ignores week numbers and assumes that the magnitude of the time difference
// is less than 1/2 week. If a full difference is desired, use the function
// operator-.
f64 diff(const BaseTime& left, const BaseTime& right){
  
  const f64 halfWeek = static_cast<f64>(SEC_PER_WEEK>>1);
  s32 leftWeek,rightWeek,leftSecondsOfWeek,rightSecondsOfWeek;
  f64 leftFractionOfSecond,rightFractionOfSecond;

  left.get(leftWeek,leftSecondsOfWeek,leftFractionOfSecond);
  right.get(rightWeek,rightSecondsOfWeek,rightFractionOfSecond);

  f64 diff = static_cast<f64>(leftSecondsOfWeek - rightSecondsOfWeek) +
    leftFractionOfSecond - rightFractionOfSecond;
  
  if(diff > halfWeek)
    diff -= static_cast<f64>(SEC_PER_WEEK);
  else if(diff < -halfWeek)
    diff += static_cast<f64>(SEC_PER_WEEK);
  
  return diff; 
}
