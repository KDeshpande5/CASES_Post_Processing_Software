// gridframework.cpp
// 
// GRID Extension of the basic framework for programs in the GPS toolkit
// 
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "gridframework.h"

#include "Exception.hpp"
#include "StringUtils.hpp"

#include <string>
#include <fstream>
#include <cstring>

using namespace std;

// preprocessArgs
//
// Pre-process the command line arguments:
//
//   If present, pull out -f <f> and --file <f> options and draw options from
//   an options file.
//
//   Print version information on --version.
//
void preprocessArgs(const std::string& programName,
                    const std::string& versionNumber,
                    const char *arg, std::vector<std::string>& Args) 
  throw(gpstk::Exception){
  using namespace gpstk;
  using namespace std;

  try {
    static bool found_cfg_file=false;

    if(found_cfg_file || (arg[0]=='-' && arg[1]=='f')) {
      if(arg[2]=='\0'){found_cfg_file = true; return;}
      string filename(arg);
      if(!found_cfg_file) filename.erase(0,2); else found_cfg_file = false;
      ifstream infile(filename.c_str());
      if(!infile) {
        cout << "\nError: could not open options file " << filename << endl;
        exit(EXIT_FAILURE);
        return;
      }

      bool again_cfg_file=false;
      string buffer,word;
      while(1) {
        getline(infile,buffer);
        StringUtils::stripTrailing(buffer,'\r');
        // Process the buffer before checking eof or bad b/c there can be a
        // line at EOF that has no CRLF.
        while(!buffer.empty()) {
          word = StringUtils::firstWord(buffer);
          if(again_cfg_file) {
            word = "-f" + word;
            again_cfg_file = false;
            preprocessArgs(programName,versionNumber,word.c_str(),Args);
          }
          else if(word[0] == '#') { // skip to end of line
            buffer = "";
          }
          else if(word == "--file" || word == "-f")
            again_cfg_file = true;
          else if(word[0] == '"') {
            word = StringUtils::stripFirstWord(buffer,'"');
            buffer = "dummy " + buffer;               // to be stripped later
            preprocessArgs(programName,versionNumber,word.c_str(),Args);
          }
          else
            preprocessArgs(programName,versionNumber,word.c_str(),Args);

          word = StringUtils::stripFirstWord(buffer); // now remove it from buffer
        }
        if(infile.eof() || !infile.good()) break;
      }
    }
    else if(string(arg) == "--file" || string(arg) == "-f")
      found_cfg_file = true;
    else if (string(arg) == "--version"){
      cout << programName << " version " << versionNumber << ".\n\n";
      exit(EXIT_SUCCESS);
    }

    // regular arg
    else Args.push_back(arg);
  }
  catch(Exception& e) { GPSTK_RETHROW(e); }
  catch(exception& e) 
    { Exception E("std except: "+string(e.what())); GPSTK_THROW(E); }
  catch(...) { Exception e("Unknown exception"); GPSTK_THROW(e); }
}

GRIDFramework :: GRIDFramework( const std::string& applName,
                                const std::string& applDesc,
                                const std::string& programName,
                                const std::string& versionNumber,
                                const std::string& maintainerEmail )
      : BasicFramework(applName, applDesc),
        versionOption(0, "version","Print version information and quit"),
        programName(programName),
        versionNumber(versionNumber),
        maintainerEmail(maintainerEmail)
{}

bool GRIDFramework::initialize(int argc, char *argv[], bool pretty) throw() {

  //----- Process options input via an options file
  std::vector<std::string> Args;
  for(int j=1; j<argc; j++) 
    preprocessArgs(programName,versionNumber,argv[j],Args);
  if(Args.size()==0) Args.push_back(std::string("-h"));
  //std::cout << "List after preprocessArgs\n";
  //for(u32 i=0; i<Args.size(); i++) std::cout << i << " " << Args[i] << std::endl;

  // Pass the rest of the arguments
  argc = Args.size()+1;
  char **CArgs=new char*[argc];
  if(!CArgs) { std::cout << "Failed to allocate CArgs\n"; return false; }
  CArgs[0] = argv[0];
  for(int j=1; j<argc; j++) {
    CArgs[j] = new char[Args[j-1].size()+1];
    if(!CArgs[j]){std::cout << "Failed to allocate CArgs[j]\n";return false;}
    strcpy(CArgs[j],Args[j-1].c_str());
  }
  //std::cout << "List passed to parser\n";
  //for(int i=0; i<argc; i++) std::cout << i << " " << CArgs[i] << std::endl;
  
  //----- Proceed with standard command-line parsing
  bool retVal = BasicFramework::initialize(argc,CArgs,pretty);
  
  // Deallocate CArgs
  for(int j=1; j<argc; j++) {
    delete[] CArgs[j];
  }
  delete[] CArgs;
  
  if(helpOption.getCount()) 
    std::cout << "\nMail bug reports and suggestions to <"
              << maintainerEmail << ">.\n\n";
              
  return retVal;
}
