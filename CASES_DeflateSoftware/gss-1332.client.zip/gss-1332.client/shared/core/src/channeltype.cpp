// channeltype.cpp
//
// ChannelType enumerations
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "channeltype.h"

ChannelType signalTypeToChannelTypeMap_[NUM_SIGNAL_TYPES];
bool initialized_ = false;

ChannelType signalTypeToChannelTypeMap(SignalType signalType){

  if(!initialized_){
    signalTypeToChannelTypeMap_[GPS_L1_CA]  = CT_GPS_L1_C;
    signalTypeToChannelTypeMap_[GPS_L2_CM]  = CT_GPS_L2_C;
    signalTypeToChannelTypeMap_[GPS_L2_CL]  = CT_GPS_L2_C;
    signalTypeToChannelTypeMap_[GPS_L2_CLM] = CT_GPS_L2_C;
    signalTypeToChannelTypeMap_[CDMA_UHF_PILOT] = CT_CDMA;
    signalTypeToChannelTypeMap_[CDMA_UHF_SYNC]  = CT_CDMA;
    signalTypeToChannelTypeMap_[GPS_L1_CA_ALT1] = CT_GPS_L1_C;
    initialized_ = true;
  }
  return signalTypeToChannelTypeMap_[signalType];
}

