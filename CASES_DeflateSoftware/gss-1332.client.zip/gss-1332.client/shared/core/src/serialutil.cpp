// serialutil.cpp
//
// Serialization utility functions
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "serialutil.h"
#include <cstring>

namespace serialutil {
  
  void getbin(const u32 * pa, s32& index, u8 * val, s32 size){
    std::memcpy(val,&pa[index],size);
    index += ((size-1)>>2)+1;
  }
  void gets32(const u32 * pa, s32& index, s32& val){
    std::memcpy(&val,&pa[index],sizeof(val));
    index += sizeof(val)>>2;
  }
  void gets64(const u32 * pa, s32& index, s64& val){
    std::memcpy(&val,&pa[index],sizeof(val));
    index += sizeof(val)>>2;
  }
  void getu32(const u32 * pa, s32& index, u32& val){
    val = pa[index];
    index += sizeof(val)>>2;
  }
  void getu64(const u32 * pa, s32& index, u64& val){
    std::memcpy(&val,&pa[index],sizeof(val));
    index += sizeof(val)>>2;
  }
  void getf32(const u32 * pa, s32& index, f32& val){
    std::memcpy(&val,&pa[index],sizeof(val));
    index += sizeof(val)>>2;
  }
  void getf64(const u32 * pa, s32& index, f64& val){
    std::memcpy(&val,&pa[index],sizeof(val));
    index += sizeof(val)>>2;
  }
  
  
  void setbin(u32 * pa, s32& index, const u8 * val, s32 size){
    if(pa!=NULL)
      std::memcpy(&pa[index],val,size);
    index += ((size-1)>>2)+1;
  }
  void sets32(u32 * pa, s32& index, s32 val){
    if(pa!=NULL)
      std::memcpy(&pa[index],&val,sizeof(val));
    index += sizeof(val)>>2;
  }
  void sets64(u32 * pa, s32& index, s64 val){
    if(pa!=NULL)
      std::memcpy(&pa[index],&val,sizeof(val));
    index += sizeof(val)>>2;
  }
  void setu32(u32 * pa, s32& index, u32 val){
    if(pa!=NULL)
      pa[index] = val;
    index += sizeof(val)>>2;
  }
  void setu64(u32 * pa, s32& index, u64 val){
    if(pa!=NULL)
      std::memcpy(pa,&val,sizeof(val));
    index += sizeof(val)>>2;
  }
  void setf32(u32 * pa, s32& index, f32 val){
    if(pa!=NULL)
      std::memcpy(&pa[index],&val,sizeof(val));
    index += sizeof(val)>>2;
  }
  void setf64(u32 * pa, s32& index, f64 val){
    if(pa!=NULL){
      std::memcpy(&pa[index],&val,sizeof(val));
    }
    index += sizeof(val)>>2;
  }
  

} // namespace



