// navsolconfig.cpp
//
// NavSolConfig class
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "navsolconfig.h"
#include "serialutil.h"
#include "parameters.h"

// Constructor sets default configuration
NavSolConfig::NavSolConfig(){
  AVERAGE_NAV_SOLN_ = true; 
  NAV_FILTER_K_ = .01f; 
  USE_CORR_ = IONO_CORR | TROPO_CORR; 
  ALLOW_DELTRX_FIXUPS_ = true;
  MAX_ABS_DELTRX_SEC_ = 0.032;
  ENFORCE_STRICT_SELECTION_ = true;
  ELEVATION_MASK_ANGLE_RAD_ = DEG_TO_RAD*10.0;
  setDependentParameters();
}

void NavSolConfig::importConfiguration(const u32 * pa, s32& index){
  serialutil::getbin(pa, index, reinterpret_cast<u8*>(this), sizeof(*this));
  setDependentParameters();
}

void NavSolConfig::exportConfiguration(u32 * pa, s32& index)const{
  serialutil::setbin(pa, index, reinterpret_cast<const u8*>(this), sizeof(*this));
}

void NavSolConfig::setDependentParameters(){
  checkParameterValidity();
}

void NavSolConfig::checkParameterValidity(){
  ASSERT(NAV_FILTER_K_ >= 0);
  ASSERT(MAX_ABS_DELTRX_SEC_ >= DELTRX_FIXUP_RESOLUTION_SEC());
  // Limit the size of MAX_ABS_DELTRX_SEC_ to prevent overflow in
  // Channel.nco.thetak.  The current strategy is to limit the change in phase
  // due to a receiver time fixup to 1/10 the available range in the
  // Channel.nco.thetak variable assuming the L1 carrier frequency.  This
  // should prevent overflow for any signal with a center frequency of 2*L1 or
  // below.
#ifndef NDEBUG
  const u64 one = 0x1;
  const f64 deltRxFixupMaxToAvoidOverflow = (one<<63)/(FREQ_L1_HZ*SF_P)/10;
#endif
  ASSERT(MAX_ABS_DELTRX_SEC_ < deltRxFixupMaxToAvoidOverflow);
  ASSERT(ELEVATION_MASK_ANGLE_RAD_ <= PI/2 && ELEVATION_MASK_ANGLE_RAD_ >= -PI/2);
}
