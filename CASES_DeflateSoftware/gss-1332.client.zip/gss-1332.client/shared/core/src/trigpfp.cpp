// trigpfp.cpp
//
// Implementation file for the fixed-point trigonometric functions that are
// based on pic arithmetic.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cmath>
#include "trigpfp.h"

//======= Trigonometric parameters 
// Independent parameters
#ifndef DSPARCH
const s32 TRIGP_SIN_COS_XL = 10; // Number of bits used to address the sine and cosine tables.  The actual tables are of size 2^TRIGP_SIN_COS_XL.  10 appears to be more than adequate.  In fact, there is no noticeable difference until this drops to 4.
#endif
extern const s32 TRIGP_SIN_COS_YL = 14; // Scaling for the sine and cosine table y-axis.
extern const s32 TRIGP_ATAN_XL = 8;     // Scaling for the fixed-point atan x-axis (8 is adequate for 0.001 cycle accuracy).
extern const s32 TRIGP_ATAN_YL = 16;    // Scaling for the fixed-point atan y-axis.
// Dependent parameters
#ifndef DSPARCH
const s32 TRIGP_SIN_COS_X_MASK = (0x1<<TRIGP_SIN_COS_XL) - 1;
const s32 TRIGP_SIN_COS_Y = (0x1 << TRIGP_SIN_COS_YL);
#endif
const s32 TRIGP_ATAN_X = (0x1 << TRIGP_ATAN_XL);
const s32 TRIGP_ATAN_Y = (0x1 << TRIGP_ATAN_YL);
const s32 TRIGP_ATAN_XMAX = (10*TRIGP_ATAN_X);      // atanTable will be valid over the range [-FP_ATAN_X_MAX, FP_ATAN_X_MAX].  Outside this interval, the function atan will return a constant -pi/2 or pi/2.
const s32 TRIGP_SIZE_ATAN_TABLE = TRIGP_ATAN_XMAX;  // The number of elements that will make up the atanTable lookup table.  N is equal to the number of subintervals equally subdividing the interval [0, TRIGP_ATAN_X_MAX).
const u8  TRIGP_ATAN_Y2PL = SF_PL - TRIGP_ATAN_YL;  // scaling used to convert the output of the fixed-point atan function to units of pics
const s64 TRIGP_QUARTER_CYCLE = static_cast<s64>(std::floor(0.25*SF_P + 0.5));


#ifdef DSPARCH
#pragma DATA_SECTION("onchip")
#pragma DATA_ALIGN(8)
s32 atanTable[TRIGP_SIZE_ATAN_TABLE];
// sin and cos tables not used on DSP
#else
s32 atanTable[TRIGP_SIZE_ATAN_TABLE]= {0};
s16 cosTable[0x1<<TRIGP_SIN_COS_XL] = {0};
s16 sinTable[0x1<<TRIGP_SIN_COS_XL] = {0};
#endif

//======= Function definitions
/* TRIGP_atan
 * Fixed-point arctangent function
 *
 * NOTE: For values of |x|>TRIX_ATAN_XMAX, TRIGP_atan returns +/-
 * 1/4 cycle.
 * 
 * INPUTS:
 * x               Input value in units scaled by TRIGP_ATAN_X
 *
 * OUTPUTS:
 * (return value)  atan(x/TRIGP_ATAN_X) with output in pics
 *
 */
s64 TRIGP_atan(const s32 x){
  s64 theta;
  if(x>=TRIGP_ATAN_XMAX)
    return TRIGP_QUARTER_CYCLE;
  else if(x<= -TRIGP_ATAN_XMAX)
    return -TRIGP_QUARTER_CYCLE;
  if(x>0)
    theta = atanTable[x];
  else
    theta = -atanTable[-x];
  return theta<<TRIGP_ATAN_Y2PL;
}

/* TRIGP_atan2
 * Four quadrant fixed-point arctangent 
 *
 * INPUTS:
 * Y               Unscaled input y-axis value.
 *
 * X               Unscaled input x-axis value.
 *
 * OUTPUTS:
 * (return value)  atan2(Y,X) with output in pics
 *
 */
s64 TRIGP_atan2(const s64 Y,const s64 X){
  s32 x;   // scale the ratio of the inputs
  if(X == 0){
    x = static_cast<s32>((Y<<TRIGP_ATAN_XL));
    return TRIGP_atan(x);
  }
  else if(X > 0){
    x = static_cast<s32>((Y<<TRIGP_ATAN_XL)/X);
    return TRIGP_atan(x);
  }
  else{
    x = static_cast<s32>((Y<<TRIGP_ATAN_XL)/X);
    if(Y >= 0)
      return (TRIGP_atan(x) + (SF_P>>1));
    else
      return (TRIGP_atan(x) - (SF_P>>1));
  }
}

/* TRIGP_fillAtanTable
 * Fill the lookup table used to caculate atan
 *
 * Notes on global variables:
 *
 * TRIGP_SIZE_ATAN_TABLE
 * The number of elements that will make up the atanTable lookup
 * table.  N is equal to the number of subintervals equally
 * subdividing the interval [0, TRIGP_ATAN_XMAX).
 *
 * atanTable 
 * The N-by-1 arctangent lookup table, in cycles scaled by TRIGP_ATAN_Y.
 * Because of symmetry it is only necessary to tabulate input values
 * from 0 to TRIGP_ATAN_XMAX.  Hence, the ith element of the table
 * atanTable represents atan(xi) where xi = i*dx < TRIGP_ATAN_XMAX and
 * dx = TRIGP_ATAN_XMAX/N units.  Note that for use in the PLL, this
 * table's precision (TRIGP_ATAN_Y) must be converted to pic precision (SF_P).
 *
 * Todd Humphreys
 * 15 Feb., 2008
 */
void TRIGP_fillAtanTable(void){
  s32 ii;
  f32 tmp;
  f32 dx = f32(TRIGP_ATAN_XMAX)/TRIGP_ATAN_X/TRIGP_SIZE_ATAN_TABLE;
  
  for(ii=0;ii<TRIGP_SIZE_ATAN_TABLE;ii++){
    tmp = std::atan(ii*dx)/TWOPI;
    atanTable[ii] = static_cast<s32>(std::floor(TRIGP_ATAN_Y*tmp + 0.5F));
  }
}

#ifndef DSPARCH

/* TRIGP_fillSinCosTables
 * 
 * Fill the arrays that are used to convert phase in pics to quantized sine
 * and cosine values.
 *
 */
void TRIGP_fillSinCosTables(void){
  s32 tableSize = 0x1<<TRIGP_SIN_COS_XL;
  f64 delTheta = TWOPI_DOUBLE/tableSize;
  for(s32 ii=0;ii<tableSize;ii++){
    cosTable[ii] = 
      static_cast<s16>(std::floor(std::cos(ii*delTheta)*TRIGP_SIN_COS_Y + 0.5));
    sinTable[ii] = 
      static_cast<s16>(std::floor(std::sin(ii*delTheta)*TRIGP_SIN_COS_Y + 0.5));
  }
}


/* TRIGP_sin
 *
 * Fixed-point sin function.
 * 
 * INPUTS
 * theta            Phase in pics.
 *
 * OUTPUTS
 * (return val)     sin of the input phase, scaled by TRIGP_SIN_COS_YL.
 *
 */
s16 TRIGP_sin(const s64 theta){
  const u32 Nshift = SF_PL - TRIGP_SIN_COS_XL;
  return sinTable[(theta>>Nshift)&TRIGP_SIN_COS_X_MASK];
}


/* TRIGP_cos
 *
 * Fixed-point cos function.
 * 
 * INPUTS
 * theta            Phase in pics.
 *
 * OUTPUTS
 * (return val)     cos of the input phase, scaled by TRIGP_SIN_COS_YL.
 *
 */
s16 TRIGP_cos(const s64 theta){
  const u32 Nshift = SF_PL - TRIGP_SIN_COS_XL;
  return cosTable[(theta>>Nshift)&TRIGP_SIN_COS_X_MASK];
}

#endif
