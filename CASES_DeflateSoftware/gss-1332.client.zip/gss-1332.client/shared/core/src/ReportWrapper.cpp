// ReportWrapper.cpp
//
// Handles transmission of various data reports
//
// Copyright (c) 2010 the GRID Software Project.  All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf


#ifdef DSPARCH
#include "targetcfg.h"
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/family/c64p/Cache.h>
#include <ti/sysbios/family/c64p/Hwi.h>
#endif
#include <string.h>
#include "ReportWrapper.h"
namespace ReportWrapper{

  // Buffers for report data
  s32 tmtSize = 0;
  s32 tmtIndex = 0;
#ifdef DSPARCH
  const s32 tmtMaxSize = 256;
#pragma DATA_ALIGN(8)
#pragma DATA_SECTION("offchip")
  u8 gBufRepTmtBuff[tmtMaxSize][REP_BUFFSIZE];
#pragma DATA_ALIGN(8)
#pragma DATA_SECTION("onchip")
  u8 gBufRepRcvPing[REP_BUFFSIZE];
#pragma DATA_ALIGN(8)
#pragma DATA_SECTION("onchip")
  u8 gBufRepRcvPong[REP_BUFFSIZE];
#pragma DATA_ALIGN(8)
#pragma DATA_SECTION("onchip")
  // contains a known data set for synchronizing with SBC
  // also transmitted whenever there is not real data to tx
  u8 gBufReportDummy[REP_BUFFSIZE];
  u32 taskState, hwiState; 
#else
  const s32 tmtMaxSize = 2;
  u8 gBufRepTmtBuff[tmtMaxSize][REP_BUFFSIZE];
  u8 gBufReportDummy[REP_BUFFSIZE]; 
#endif
  s32 writeBuffIdx = 0;
// Takes a report object and size and copies to the appropriate transmit buffer.
// Marks a buffer as ready to transmit when it is full.
// This function is thread-safe.
// inputs:  void* rep: the report to be transmitted
//          s32 repSize: the size of the report being transmitted
  void enqueue(const void* rep, s32 repSize){
    u8* destAddr;
    
#ifdef DSPARCH
    taskState = Task_disable();
#endif

    // ==REP_BUFFSIZE is a corner case and I am ignoring it
    if((writeBuffIdx+repSize)<REP_BUFFSIZE){
      destAddr = &gBufRepTmtBuff[tmtIndex][writeBuffIdx];    
      memcpy(destAddr, rep, repSize);
      writeBuffIdx+=repSize;
    }else{ //current buffer is full
      //pad remainder of buffer with zeros
      memset(&gBufRepTmtBuff[tmtIndex][writeBuffIdx], 0, REP_BUFFSIZE-writeBuffIdx);
#ifdef DSPARCH
      Cache_wb(gBufRepTmtBuff[tmtIndex],REP_BUFFSIZE,Cache_Type_ALL,true);
      hwiState = Hwi_disable();
#endif
      tmtIndex++;
      if(tmtIndex==tmtMaxSize)
        tmtIndex=0;
      tmtSize++;
#ifdef DSPARCH
      Hwi_restore(hwiState);
#endif
      destAddr = gBufRepTmtBuff[tmtIndex];
      // write report to the other buffer and mark this one ready for tx
      memcpy(destAddr, rep, repSize);
      writeBuffIdx = repSize;
    }
    
#ifdef DSPARCH
    Task_restore(taskState);
#endif
  }

  // Returns the address of the current buffer ready for transmit.  
  // If no buffer is full, returns the dummy buffer address.
  u8* nextBuffer(){
    u8* bufptr;
    s32 index;
    if(tmtSize>0){
      index = tmtIndex-tmtSize;
      if(index<0)
        index += tmtMaxSize;
      bufptr = gBufRepTmtBuff[index];
      tmtSize--;
    }
    else
      bufptr = gBufReportDummy;
    return bufptr;  
  }
  
  // Rather than waiting for the buffer to become full before transmit,
  // this forces transmission of the current buffer.
  // This function is thread-safe.
  void forceReady(){
#ifdef DSPARCH
    taskState = Task_disable();
#endif

    //pad remainder of buffer with zeros
    memset(&gBufRepTmtBuff[tmtIndex][writeBuffIdx], 0, REP_BUFFSIZE-writeBuffIdx);
#ifdef DSPARCH
    Cache_wb(gBufRepTmtBuff[tmtIndex],REP_BUFFSIZE,Cache_Type_ALL,true);
    hwiState= Hwi_disable();
#endif
    tmtIndex++;
    if(tmtIndex==tmtMaxSize)
      tmtIndex=0;
    tmtSize++;
#ifdef DSPARCH
    Hwi_restore(hwiState);
#endif
    writeBuffIdx = 0;
    
#ifdef DSPARCH
    Task_restore(taskState);
#endif
  }



  // Class initialization function
  void init(){
    //clear the global report buffers
    for(s32 ii=0; ii<tmtMaxSize; ii++)
      memset(gBufRepTmtBuff[ii], 0, sizeof(gBufRepTmtBuff[ii]));
    memset(gBufReportDummy, 0, sizeof(gBufReportDummy));
    ASSERT(static_cast<s32>(REP_BUFFSIZE) > SYNC_LENGTH);
    for(s32 ii=0; ii<SYNC_LENGTH; ii++)   
      gBufReportDummy[ii+4] = ii; //the first 4 bytes of dummy must be zero
    return;
  }

  // returns false on sync failure, otherwise returns true and
  // sets offset to index of beginning of data from transmitter
  bool attemptSync(u8 syncbuf[REP_BUFFSIZE], s32 &offset){
    for(s32 jj=0; jj<REP_BUFFSIZE; jj++){
      s32 ii;
      for(ii=0; ii<SYNC_LENGTH; ii++){
        //offset by 4 since first word of the dummy buffer is zeros
        if(syncbuf[(jj+ii+4)&REP_BUFFSIZEM]!=static_cast<u8>(ii)) 
          break;
      }
      if(ii==SYNC_LENGTH){
        offset=jj;
        return true;
      }
    }
    return false;
  }

}//namespace






