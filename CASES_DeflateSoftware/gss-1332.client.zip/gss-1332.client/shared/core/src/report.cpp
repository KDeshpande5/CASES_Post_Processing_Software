// report.cpp
//
// Report classes
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cstring>
#include <string.h>
#include "report.h"

namespace Report {
  enum {
    // TTT The build id is a unique number that identifies the build of the
    // GRID code. At the moment, this number needs to be set manually (we will
    // use the current svn revision number), but there should be a way to
    // automate this process.
    BUILD_ID = 1332
  };

  ReportType getReportType(u32 header){
    return static_cast<ReportType> ((header >> 24)&0xFF);
  }
  ReportType getReportTypeAndSize(u32 header, u32& size){
    ReportType reportType = getReportType(header);
    switch(reportType){
      case IQ:
        size = sizeof(ReportIQ);
        break;
      case GNSS_OBSERVABLES:
        size = sizeof(ReportGnssObservables);
        break;
      case OBSERVABLES_MEASUREMENT_TIME:
        size = sizeof(ReportObservablesMeasurementTime);
        break;
      case NAVIGATION_SOLUTION:
        size = sizeof(ReportNavigationSolution);
        break;
      case ASSIMILATOR_STATUS:
        size = sizeof(ReportAssimilatorStatus);
        break;
      case DATA_LOG_CONFIG:
        size = sizeof(ReportDataLogConfig);
        break;
      case COMMAND_MSG:
        size = sizeof(ReportCommand);
        break;
      case TRANSMITTER_INFO:
        size = sizeof(ReportTransmitterInfo);
        break;
      case IQ_METADATA:
        size = sizeof(ReportIQMetadata);
        break;
      case SCINTILLATION_PARAMETERS:
        size = sizeof(ReportScintillationParameters);
        break;
      case IONOSPHERE:
        size = sizeof(ReportIonosphere);
        break;
      case DIAGNOSTICS_INFO:
        size = sizeof(ReportDiagnosticsInfo);
        break;
      case TASK_CPU:
        size = sizeof(ReportTaskCpu);
        break;
      case BENCHMARK:
        size = sizeof(ReportBenchmark);
        break;
      default:
        size = 0;
        break;
    }
    return reportType;
  }
}

u32 commonPackHeader(s32 A, s32 B, s32 C, s32 D){
  return (((A&0xFF) << 24) | ((B&0xFF) << 16) |
    ((C&0xFF) << 8) | (D&0xFF));
}

void commonUnpackHeader(u32 header, s32& A, s32& B, s32& C, s32& D) {
  A = ((header >> 24)&0xFF);
  B = ((header >> 16)&0xFF);
  C = ((header >> 8)&0xFF);
  D = header&0xFF;
}

ReportIQ::ReportIQ(){
  init();
}

void ReportIQ::init(){
  header = Report::IQ<<24;
  header2 = 0;
  I = 0;
  Q = 0;
  thetahat = 0;
}

void ReportIQ::packHeader(SignalType signalType, s32 svId, s32 dataBit){
  header = commonPackHeader(Report::IQ,signalType,svId,(dataBit&0x1)<<7);
}

void ReportIQ::unpackHeader(Report::ReportType& reportType, 
                            SignalType& signalType, 
                            s32& svId, s32& dataBit) const {
  commonUnpackHeader(header,(s32&)(reportType),
                     (s32&)(signalType),svId,dataBit);
  dataBit>>=7;
}

void ReportIQ::packHeader2(u64 tIndexk, s32 tFracIndexk){
  header &= 0xFFFFFF80;
  header |= static_cast<u32>(tIndexk >> (32-SF_SL)) & 0x7F;
  header2 = static_cast<u32>(tIndexk << SF_SL) | (tFracIndexk >> (SF_TL-SF_SL));
}

void ReportIQ::unpackHeader2(u64& tIndexk, s32& tFracIndexk) const {
  tFracIndexk = (header2 & SF_S_MASK) << (SF_TL-SF_SL);
  tIndexk  = header2 >> SF_SL;
  tIndexk |= (header & 0x7F) << (32-SF_SL);
}

void ReportIQ::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportIQ::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportObservablesMeasurementTime::ReportObservablesMeasurementTime(){
  init();
}

void ReportObservablesMeasurementTime::init(){
  header = Report::OBSERVABLES_MEASUREMENT_TIME << 24;
  header2 = (Report::SYNCHRONIZATION_SEQUENCE << 8) | (0xFF & Report::VERSION);
  tMeasurement.init();
  tOffset.init();
}

void ReportObservablesMeasurementTime::packHeader(SignalType signalType, 
                                                  s32 reportId){
  header = commonPackHeader(Report::OBSERVABLES_MEASUREMENT_TIME,
                            signalType,reportId,0xFF);
}

void ReportObservablesMeasurementTime::unpackHeader(Report::ReportType& reportType, 
                                                    SignalType& signalType, 
                                                    s32& reportId) const {
  s32 dum;
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),
                     reinterpret_cast<s32&>(signalType),reportId,dum);
}

void ReportObservablesMeasurementTime::unpackHeader2(u32& synchronizationSequence,
                                                     u8& version) const {
  synchronizationSequence = (header2>>8)&0xFFFFFF;
  version = header2&0xFF;
}

void ReportObservablesMeasurementTime::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportObservablesMeasurementTime::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}


ReportGnssObservables::ReportGnssObservables(){
  init();
}

void ReportGnssObservables::init(){
  header = Report::GNSS_OBSERVABLES<<24;
  header2 = 0;
  thetahatk = 0;
  C_N0dB = 0;
  fpll = 0;
  pseudoRange = 0;
}

void ReportGnssObservables::packHeader(SignalType signalType, 
                                       s32 svId, s32 channel){
  header = commonPackHeader(Report::GNSS_OBSERVABLES,signalType,svId,channel);
}


void ReportGnssObservables::unpackHeader(Report::ReportType& reportType, 
                                         SignalType& signalType, 
                                         s32& svId, s32& channel) const {
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),
                     reinterpret_cast<s32&>(signalType),svId,channel);
}

void ReportGnssObservables::packHeader2(ChannelStatus channelStatus, 
                                        bool phaseErrorFlag,
                                        s32 reportId,
                                        bool validObsFlag){
  header2 = commonPackHeader(channelStatus,phaseErrorFlag?1:0,
                             reportId, validObsFlag?1:0);
}

void ReportGnssObservables::unpackHeader2(ChannelStatus& channelStatus, 
                                          bool& phaseErrorFlag, 
                                          s32& reportId,
                                          bool& validObsFlag) const {
  channelStatus = static_cast<ChannelStatus>((header2>>24)&0xFF);
  phaseErrorFlag = (((header2>>16)&0xFF) == 0 ? false : true);
  reportId = (header2>>8)&0xFF;
  validObsFlag = ((header2&0xFF) == 0 ? false : true);
}

void ReportGnssObservables::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportGnssObservables::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}


ReportNavigationSolution::ReportNavigationSolution(){
  init();
}

void ReportNavigationSolution::init(){
  header = Report::NAVIGATION_SOLUTION<<24;
  tSolution.init();
  xval = 0;  
  yval = 0;
  zval = 0;
  deltatRxMeters = 0;
  xvelocity = 0; 
  yvelocity = 0;
  zvelocity = 0;
  deltatRxDotMetersPerSecond = 0; 
}

void ReportNavigationSolution::packHeader(SolverResult solverResult){
  header = commonPackHeader(Report::NAVIGATION_SOLUTION,solverResult,
                            0xFF,0xFF);
}

void ReportNavigationSolution::unpackHeader(Report::ReportType& reportType, 
                                            SolverResult& solverResult) const {
  reportType = static_cast<Report::ReportType>(header>>24);
  solverResult = static_cast<SolverResult>((header>>16)&0xFF);
}

void ReportNavigationSolution::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportNavigationSolution::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportAssimilatorStatus::ReportAssimilatorStatus(){
  init();
}

ReportDataLogConfig::ReportDataLogConfig(){
  init();
}

void ReportDataLogConfig::init(){
  header = Report::DATA_LOG_CONFIG<<24;
  header2 = Report::BUILD_ID;
}

void ReportDataLogConfig::packHeader(const s32 configId,
                                     const SignalType signalType,
                                     const s32 numChannels){
  header = commonPackHeader(Report::DATA_LOG_CONFIG,configId,
                            signalType,numChannels);
}

void ReportDataLogConfig::unpackHeader(Report::ReportType& reportType,
                                       s32& configId,
                                       SignalType& signalType,
                                       s32& numChannels) const {
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),configId,
                     reinterpret_cast<s32&>(signalType),numChannels);
}


void ReportDataLogConfig::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportDataLogConfig::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportTransmitterInfo::ReportTransmitterInfo(){
  init();
}

void ReportTransmitterInfo::init(){
  header  = Report::TRANSMITTER_INFO<<24;
  header2 = UNDEFINED_SYSTEM<<24;
  azimuthDeg = 0;
  elevationDeg = 0;
}

void ReportTransmitterInfo::packHeader(s32 healthStatus,
                                       s32 reportId){
  header = commonPackHeader(Report::TRANSMITTER_INFO,
                            healthStatus,reportId,0xFF);
}

void ReportTransmitterInfo::unpackHeader(Report::ReportType& reportType,
                                         s32& healthStatus,
                                         s32& reportId) const {
  s32 dum;
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),healthStatus,
                     reportId,dum);
}

void ReportTransmitterInfo::packHeader2(TxId txId){
  header2 = commonPackHeader(txId.system(),txId.number(),0xFF,0xFF);
}

void ReportTransmitterInfo::unpackHeader2(TxId& txId) const {
  System txIdSystem = static_cast<System>(header2>>24);
  s32 txIdNumber = (header2>>16)&0xFF;
  txId.set_system(txIdSystem);
  txId.set_number(txIdNumber);
}


void ReportTransmitterInfo::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportTransmitterInfo::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}


ReportCommand::ReportCommand(){
  init();
}

void ReportCommand::init(){
  packHeader(Report::NO_TYPE);
}

void ReportCommand::packHeader(Report::DataTransType dataTransType){
  header = commonPackHeader(Report::COMMAND_MSG,dataTransType,0xFF,0xFF);
}

void ReportCommand::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportCommand::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

void ReportCommand::setCommandMsg(Report::CommandMsgs msg){
  header2 = static_cast<s32>(msg);
}

Report::CommandMsgs ReportCommand::commandMsg() const {
  return static_cast<Report::CommandMsgs>(header2);
}

Report::DataTransType ReportCommand::dataTransType() const {
  return static_cast<Report::DataTransType>(header>>16 & 0xFF);
}

void ReportAssimilatorStatus::init(){
  header = commonPackHeader(Report::ASSIMILATOR_STATUS,0x00,0xFF,0xFF);
  header2 = 0;
  dxval = 0;  
  dyval = 0;
  dzval = 0;
  ddeltatRxMeters = 0;
  dxvelocity = 0; 
  dyvelocity = 0;
  dzvelocity = 0;
  ddeltatRxDotMetersPerSecond = 0; 
}

void ReportAssimilatorStatus::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportAssimilatorStatus::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

void ReportAssimilatorStatus::packHeader(s32 databitPredictionEnabled,
                                         s32 phaseLockEnabled,
                                         s32 feedbackEnabled,
                                         s32 equalizeAmplitude,
                                         u32 digitalAttenuatorSettingdB) {
  s32 val = databitPredictionEnabled << 7 | phaseLockEnabled << 6 |
    feedbackEnabled << 5 | equalizeAmplitude << 4;
  header = commonPackHeader(Report::ASSIMILATOR_STATUS,val,0xFF,digitalAttenuatorSettingdB);
}

void ReportAssimilatorStatus::unpackHeader(Report::ReportType& reportType,
                                           s32& databitPredictionEnabled,
                                           s32& phaseLockEnabled, 
                                           s32& feedbackEnabled, 
                                           s32& equalizeAmplitude,
                                           u32& digitalAttenuatorSettingdB) const {
  s32 val, dummy1;
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),val,dummy1,
                     reinterpret_cast<s32&>(digitalAttenuatorSettingdB));
  databitPredictionEnabled = (val>>7)&0x1;
  phaseLockEnabled = (val>>6)&0x1;
  feedbackEnabled = (val>>5)&0x1;
  equalizeAmplitude = (val>>4)&0x1;
}

void ReportAssimilatorStatus::setSvSpoofed(s32 svId){
  header2 = header2|(1<<(svId-1));
}

bool ReportAssimilatorStatus::isSvSpoofed(s32 svId){
  return (header2>>(svId-1))&0x1;
}

ReportIQMetadata::ReportIQMetadata(){
  init();
}

void ReportIQMetadata::init(){
  header = commonPackHeader(Report::IQ_METADATA,0xFF,0xFF,0xFF);
  header2 = 0;
  twoSigmaIqSq = 0;
  sampleFreqDenominator = 0;
  accumPeriod = 0;
  sampleFreqNumerator = 0;
}

void ReportIQMetadata::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportIQMetadata::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

void ReportIQMetadata::packHeader(const SignalType signalType,
                                  const s32 pllSignFpll){
  header = commonPackHeader(Report::IQ_METADATA,signalType,0,pllSignFpll);
}

void ReportIQMetadata::packHeader2(const s32 scaleFactorPL){
  header2 = scaleFactorPL<<24;
}

void ReportIQMetadata::unpackHeader(Report::ReportType& reportType,
                                    SignalType& signalType,
                                    s32& pllSignFpll) const {
  s32 flag;
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),
                     reinterpret_cast<s32&>(signalType),flag,pllSignFpll);
}

void ReportIQMetadata::unpackHeader2(s32& scaleFactorPL) const {
  scaleFactorPL = header2>>24;
}


ReportScintillationParameters::ReportScintillationParameters(){
  init();
}

void ReportScintillationParameters::init(){
  header = Report::SCINTILLATION_PARAMETERS << 24;
  tReceiver.init();
  S4_Full = 0; S4_Half[0] = 0; S4_Half[1] = 0;
  sigmaPhi_Full = 0; sigmaPhi_Half[0] = 0; sigmaPhi_Half[1] = 0;
  tau0 = 0;
  SPRdB = 0;
}

void ReportScintillationParameters::packHeader(SignalType signalType, s32 svId,
                                               s32 refId){
  header = 
    commonPackHeader(Report::SCINTILLATION_PARAMETERS,signalType,svId,refId);
}

void ReportScintillationParameters::unpackHeader(Report::ReportType& reportType, 
                                                 SignalType& signalType, 
                                                 s32& svId, s32& refId) const {
  commonUnpackHeader(header,reinterpret_cast<s32&>(reportType),
                     reinterpret_cast<s32&>(signalType),svId,refId);
}

void ReportScintillationParameters::packHeader2(f32 measurementIntervalLengthSec){
  std::memcpy(&header2, &measurementIntervalLengthSec, sizeof(header2));
}

void ReportScintillationParameters::unpackHeader2(
    f32& measurementIntervalLengthSec) const {
  std::memcpy(&measurementIntervalLengthSec, &header2, sizeof(header2));
}

void ReportScintillationParameters::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportScintillationParameters::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportIonosphere::ReportIonosphere(){
  init();
}

void ReportIonosphere::init(){
  header = Report::IONOSPHERE << 24;
  tReceiver.init();
}

void ReportIonosphere::packHeader(s32 svId){
  header = Report::IONOSPHERE << 24 | (svId & 0xFF);
}

void ReportIonosphere::unpackHeader(Report::ReportType& reportType, s32& svId) const {
  reportType = static_cast<Report::ReportType>((header >> 24) & 0xFF);
  svId = header & 0xFF;
}

void ReportIonosphere::packHeader2(f32 TEC){
  std::memcpy(&header2, &TEC, sizeof(header2));
}

void ReportIonosphere::unpackHeader2(f32& TEC) const {
  std::memcpy(&TEC, &header2, sizeof(header2));
}

void ReportIonosphere::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportIonosphere::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportDiagnosticsInfo::ReportDiagnosticsInfo() {
  init();
}

void ReportDiagnosticsInfo::init() {
  header = Report::DIAGNOSTICS_INFO<<24;
  header2 = Report::NO_DIAGNOSTICS_TYPE;
  diagnosticsMessage[0] = '\0';
}

void ReportDiagnosticsInfo::unpackHeader(Report::ReportType& reportType) const {
  reportType = static_cast<Report::ReportType>((header >> 24) & 0xFF);
}

void ReportDiagnosticsInfo::packHeader2(Report::DiagnosticsType diagsType) {
  header2 = static_cast<u32>(diagsType);
}

void ReportDiagnosticsInfo::unpackHeader2(Report::DiagnosticsType& diagsType) const {
  diagsType = static_cast<Report::DiagnosticsType>(header2);
}

void ReportDiagnosticsInfo::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportDiagnosticsInfo::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

ReportTaskCpu::ReportTaskCpu() {
  init();
}

void ReportTaskCpu::init() {
  header = Report::TASK_CPU<<24;
  header2 = Report::NO_TASK_ID;
  taskPercCpu = 0;
}

void ReportTaskCpu::unpackHeader(Report::ReportType& reportType) const {
  reportType = static_cast<Report::ReportType>((header >> 24) & 0xFF);
}

void ReportTaskCpu::packHeader2(Report::TaskId taskId) {
  header2 = static_cast<u32>(taskId);
}

void ReportTaskCpu::unpackHeader2(Report::TaskId& taskId) const {
  taskId = static_cast<Report::TaskId>(header2);
}

void ReportTaskCpu::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportTaskCpu::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

std::string ReportTaskCpu::getTaskName() {
  switch(static_cast<Report::TaskId>(header2)) {
    case Report::TASK_TOTAL_CPU:
      return "Total CPU";
    case Report::TASK_ACQUIRE:
      return "Acquisition";
    case Report::TASK_UPDATE:
      return "Update";
    case Report::TASK_NAVSOL:
      return "NavSol";
    default:
      return "Unknown";
  }
}

ReportBenchmark::ReportBenchmark() {
  init();
}

void ReportBenchmark::init() {
  header = Report::BENCHMARK<<24;
  header2 = Report::NO_BENCHMARK_ID;
  avgTime = 0;
  maxTime = 0;
  minTime = 0;
}

void ReportBenchmark::unpackHeader(Report::ReportType& reportType) const {
  reportType = static_cast<Report::ReportType>((header >> 24) & 0xFF);
}

void ReportBenchmark::packHeader2(Report::BenchmarkId benchmarkId) {
  header2 = static_cast<u32>(benchmarkId);
}

void ReportBenchmark::unpackHeader2(Report::BenchmarkId& benchmarkId) const {
  benchmarkId = static_cast<Report::BenchmarkId>(header2);
}

void ReportBenchmark::serialize(u32 * pa) const {
  std::memcpy(pa,this,sizeof(*this));
}

void ReportBenchmark::deserialize(const u32 * pa) {
  std::memcpy(this,pa,sizeof(*this));
}

std::string ReportBenchmark::getBenchmarkName() {
  switch(static_cast<Report::BenchmarkId>(header2)) {
    case Report::BM_UPDATE_L1C:
      return "L1C Update";
    case Report::BM_UPDATE_L2C:
      return "L2C Update";
    case Report::BM_CORRELATION:
      return "Correlation";
    case Report::BM_NAVSOL:
      return "NavSol";
    case Report::BM_CODE_GEN_L2C:
      return "L2C Code Gen";
    case Report::BM_CARRIER_GEN:
      return "Carrier Gen";
    case Report::BM_UPDATE_SPOOFER:
      return "Spoofer Update";
    default:
      return "Unknown";
  }
}
