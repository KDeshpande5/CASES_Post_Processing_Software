// signaltype.cpp
//
// SignalType enumerations
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "signaltype.h"

std::string SIGNAL_TYPE_NAMES[NUM_SIGNAL_TYPES] = 
  {"GPS_L1_CA","GPS_L2_CM","GPS_L2_CL","GPS_L2_CLM",
   "GPS_L1_CA_ALT1","CDMA_UHF_PILOT","CDMA_UHF_SYNC"};

bool isCombinationValid(SignalType signalType, TxId txId){
  if(signalType == UNDEFINED_SIGNAL_TYPE)
    return false;
  if(!txId.isValid())
    return false;
  if(getSystem(signalType) == GPS && 
     (txId.number() < TxId::GPS_SVID_MIN || txId.number() > TxId::GPS_SVID_MAX))
    return false;

  return true;
}

System getSystem(SignalType signalType){
  if(signalType == GPS_L1_CA  ||
     signalType == GPS_L2_CM  ||
     signalType == GPS_L2_CL  ||
     signalType == GPS_L2_CLM ||
     signalType == GPS_L1_CA_ALT1)
    return GPS;
  if(signalType == CDMA_UHF_PILOT ||
     signalType == CDMA_UHF_SYNC)
    return CDMA;
  return UNDEFINED_SYSTEM;
}

const std::string * getSignalTypeNames(){
  return SIGNAL_TYPE_NAMES;
}

