#include "logger.h"

#include <cstdio>
#include <cstdarg>
#include <cstdlib>
#include <ctime>

#include <string>

#include <pthread.h>

pthread_mutex_t logMutex = PTHREAD_MUTEX_INITIALIZER;
enum { MAXSIZE = 80 };

void logger::printf(const char* file, int line, const char* format, ...){
#ifdef __GRID_ARM
  time_t rawtime;
  struct tm * ptm;
  char buffer[MAXSIZE];
  va_list args;
  pthread_mutex_lock(&logMutex);
  time(&rawtime);
  ptm = localtime(&rawtime);
  strftime(buffer, MAXSIZE, "%x %X", ptm);
  std::string filePath(file);
  std::string fileName = filePath.substr(filePath.find_last_of('/')+1);
  va_start(args, format);
  fprintf(stderr, "%s %s:%d: ", buffer, fileName.c_str(), line);
  vfprintf(stderr, format, args);
  va_end(args);
  pthread_mutex_unlock(&logMutex);
#endif
}

void pabort(const char* s){
  pthread_mutex_lock(&logMutex);
  perror(s);
  pthread_mutex_unlock(&logMutex);
  //sleep(1);
  //system("reboot");
  exit(-1);
}

