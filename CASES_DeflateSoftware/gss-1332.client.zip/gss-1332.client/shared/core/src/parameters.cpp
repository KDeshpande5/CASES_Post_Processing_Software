// parameters.cpp
//
// GRID configuration file containing all constants whose values are not used
// to statically allocate arrays.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include <cmath>
#include "parameters.h"

//======= Immutable constants
const f32 TWOPI = 6.2831853F;
const f64 PI = 3.1415926535898;
const f64 TWOPI_DOUBLE = 6.28318530717959;
const s32 SPEED_LIGHT_MPS  = 299792458;  
const f64 NOM_CACODE_PERIOD_SEC = 0.001;
const f64 FREQ_L1_HZ = 1575.42e6;
const f64 FREQ_L2_HZ = 1227.6e6;
const f64 DEG_TO_RAD = 0.0174532925199433;  // = pi/180 rad/deg
// Given one period of a finely-sampled sinusoid with unity amplitude, the
// best 2-bit quantization scheme, in terms of minimizing distortion between
// the sinusoid and the quantized data, sets the quantization decision level L
// to be equal to 0.573 and sets the ratio of the higher to lower quantization
// value to be approximately 3.  If the ratio a1/a0 is constrained to be
// exactly 3 (as is practical within a software receiver), then the optimal
// quantization scheme sets L = 0.5675.  See quantstudy.m.
const f64 LOCAL_CARRIER_THRESH = 0.5675;

//======= FFT Parameters
// I am just setting this to the previous value, but it should be noted that
// freq. resolution for the fft dds routine is roughly 1ms*2^SF_DDSL/NFFT Hz
// (~128) -- Brady
const s32 FFT_DOPP_FREQ_STEP = 256;
// Arrays that associate the number of non-coherent integrations K and
// normalized detection threshold.  The "depth" of a GRID search is the index
// into these arrays (e.g., a depth of 3 corresponds to K = FFT_K_ARRAY_[3]
// and threshold = FFT_THRESH_ARRAY_[3]). Thresholds are for probability total
// search false alarm PF = 0.01.  See notes in GRID book 2 for Aug. 3 '06 and
// the Matlab routine performAcqHypothesisCalcs.m.  Scale by sigmaIQ^2 to get
// the actual value to be compared with I^2 and Q^2 quantities to assess the
// presence of a signal.  Scale by FFT_THRESH_ADDITIONAL_SCALE_FACTOR to
// account for minor correlation peaks that violate the Gaussian noise
// assumptions used in calculating the thresholds.
const s32 FFT_NUM_K_AND_THRESH = 13;  
const s32 FFT_THRESH_ADDITIONAL_SCALE_FACTOR = 2;
const u32 FFT_K_ARRAY[FFT_NUM_K_AND_THRESH] = 
  {1,2,3,4,5,6,8,11,15,21,29,41,58};
const u32 FFT_THRESH_ARRAY[FFT_NUM_K_AND_THRESH] = 
  {34,40,45,50,54,59,67,77,91,111,135,170,217};


//======= Fixed-point scaling factors
// Scaling factor conversion factors
const s32 SF_S2TL = SF_TL - SF_SL;
const s32 SF_ILMQL = SF_IL - SF_QL;
const s32 SF_NFFTLPQL = FFT_NFFTL + SF_QL;
// Actual scaling values
const s32 SF_S = 0x1 << SF_SL;
const s64 SF_H = (static_cast<s64>(0x1)) << SF_HL;
const s32 SF_T = 0x1 << SF_TL;
const s64 SF_A = (static_cast<s64>(0x1)) << SF_AL;
const s32 SF_I = 0x1 << SF_IL;
const s64 SF_P = (static_cast<s64>(0x1)) << SF_PL;
const s64 SF_F = (static_cast<s64>(0x1)) << SF_FL;
const s64 SF_B = (static_cast<s64>(0x1)) << SF_BL;
// Masking values 
const s64 SF_P_MASK = SF_P - 1; 
const s32 SF_S_MASK = SF_S - 1;
const s64 SF_H_MASK = SF_H - 1;
const s32 SF_T_MASK = SF_T - 1;
const s64 SF_B_MASK = SF_B - 1;

//======= Dependent constants
const f64 NOM_CA_CHIPRATE_CPS = NUM_CACODE_CHIPS/NOM_CACODE_PERIOD_SEC;
const s64 FP_L2_L1_RATIO = static_cast<s64>(
                           std::floor(SF_S*f64(FREQ_L2_HZ)/FREQ_L1_HZ+0.5));
const s32 FP_SF_H_HALF = 0x1<<(SF_HL-1);
const s32 FP_SF_S_HALF = SF_S>>1;
const s32 FP_SF_T_HALF = SF_T>>1;

//======= WGS84 constants
const f64 sqrt_muearth_WGS84 = std::sqrt(398600.5e9);  // (meters^3/second^2)^.5
const f64 AA_WGS84 = 6378137.00000;		  // meters
const f64 BB_WGS84 = 6356752.31425;		  // meters
const f64 OmegaE_WGS84 = 7.2921151467e-5;	  // radians/second
const f64 e_WGS84 = 0.0818191908334158;           // eccentricity
const f64 esquare_WGS84 = 0.00669437998863492;    // eccenctricity squared  


//======= Miscellaneous constants
const s32 NV_WN_INVALID  = 9999;




