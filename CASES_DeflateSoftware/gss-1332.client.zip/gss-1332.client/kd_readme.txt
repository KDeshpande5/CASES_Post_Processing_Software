run $make in following directories:
sbc/client/src
shared/gpstk/src/
shared/binflate/src/

This creates an executable file ./sbcclient in directory sbc/client/src/ and
./binflate in directory shared/binflate/src/

Copy these files to the folder you want to use them in.
