// transport.cpp
//
// Implementation file for Transport class.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "transport.h"
#include "logger.h"

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <signal.h>

#include <cstdio>

const u8 MessageSyncCode[4] = {0x55, 0xAA, 0x33, 0xCC};
const s32 MaxSize = 1<<24;

enum {
  ChunkSize = 4096
};

u16 FileTransport::computeChecksum(std::vector<u8>::const_iterator str, u32 nbytes) {
  u16 crc = 0;
  
  while ( nbytes-- > 0 ) {
    crc += *str;
    str++;
  }
  
  return crc;
}

FileTransport::FileTransport() {
  fd = -1;
  pthread_mutex_init(&writeLock, NULL);
  pthread_mutex_init(&readLock, NULL);
}

FileTransport::~FileTransport() {
  pthread_mutex_destroy(&writeLock);
  pthread_mutex_destroy(&readLock);
}

int FileTransport::readMessage(std::vector<u8>& m) {
  std::vector<u8> tmp;
  u32 i = 0;
  // Read and align message sync code
  while(i<4){
    if(readBytes(tmp, 1) != 1)
      return -1;
    if(tmp[0]==MessageSyncCode[i])
      i++;
    else
      i=0;
  }
  // Read message size
  if(readBytes(tmp, 4) != 4)
    return -1;
  s32 size = Message::readU32(tmp);
  if(size > MaxSize || size < 0)
    return -1;
  // Read message data
  if(readBytes(m, size) != size)
    return -1;
  // Compute expected checksum
  u16 computedChecksum = computeChecksum(m);
  // Read checksum
  if(readBytes(tmp, 2) != 2)
    return -1;
  u16 readChecksum = Message::readU16(tmp);
  // Compare checksum
  if(readChecksum != computedChecksum)
    return 1;
  // We've read a valid message
  return 0;
}

int FileTransport::readMessage(Message& m) {
  pthread_mutex_lock(&readLock);
  int retVal = readMessage(m.getMutableBytes());
  pthread_mutex_unlock(&readLock);
  return retVal;
}

int FileTransport::writeMessage(const Message& m) {
  std::vector<u8> tmp(MessageSyncCode, MessageSyncCode+4);
  Message::appendU32(tmp, m.getBytes().size());
  Message::appendVector(tmp, m.getBytes());
  Message::appendU16(tmp, computeChecksum(m.getBytes()));
  pthread_mutex_lock(&writeLock);
  int retVal = writeBytes(tmp);
  pthread_mutex_unlock(&writeLock);
  return retVal;
}

int FileTransport::readBytes(std::vector<u8>& bytes, int numBytes) {
  u8 b[ChunkSize];
  
  bytes.clear();
  while(numBytes>0){
    s32 s = read(fd, b, numBytes<ChunkSize ? numBytes : ChunkSize);
    if(s<=0)
      return s;
    bytes.insert(bytes.end(), b, b+s);
    numBytes -= s;
  }
  
  return bytes.size();
}

int FileTransport::writeBytes(const std::vector<u8>& bytes) {
  u32 ii = 0;
  while(ii < bytes.size()){
    // vector allocation should be contiguous memory
    s32 jj = write(fd, &bytes[ii], bytes.size()-ii);
    if(jj<0)
      return jj;
    ii += jj;
  }
  return bytes.size();
}

/********* BufferedTransport **********/

enum {
  NumUSecsToSleepWhenBufferIsEmpty = 250000,
  SelectTimeout = 30,
  BufferFullTimeout = 30,
  MaxBufferSize = 128*1024
};

BufferedTransport::BufferedTransport()
{
  isAlive = true;
  bufferSize = 0;
  lastBufferFullMsg = 0;
  read_thread = pthread_self();
  pthread_mutex_init(&writeQueueLock, NULL);
  pthread_create(&id, NULL, runWriteThread, this);
}

BufferedTransport::~BufferedTransport(){
  isAlive = false;
  pthread_join(id, NULL);
  pthread_mutex_destroy(&writeQueueLock);
}

int BufferedTransport::readBytes(std::vector<u8>& bytes, int numBytes) {
  read_thread = pthread_self();
  return FileTransport::readBytes(bytes, numBytes);
}

void* BufferedTransport::runWriteThread(void* arg){
  reinterpret_cast<BufferedTransport*>(arg)->writeThread();
  return arg;
}

void BufferedTransport::writeThread(){
  struct timeval timeout;
  fd_set writefds;
  LOG_printf("started writeThread\n");
  while(isAlive){
    if(fd < 0){
      sleep(1);
      continue;
    }
    timeout.tv_sec = SelectTimeout;
    timeout.tv_usec = 0;
    FD_ZERO(&writefds);
    FD_SET(fd, &writefds);
    if(select(fd+1, NULL, &writefds, NULL, &timeout)!=-1){
      if(FD_ISSET(fd, &writefds)){
        pthread_mutex_lock(&writeQueueLock);
        if(writeQueue.empty()){
          pthread_mutex_unlock(&writeQueueLock);
          usleep(NumUSecsToSleepWhenBufferIsEmpty);
        }else{
          // shallow copy
          if(FileTransport::writeBytes(writeQueue.front()) > 0){
            bufferSize -= writeQueue.front().size();
            writeQueue.pop();
          }else{
            if(errno == EPIPE){
              LOG_printf("connection pipe broken\n");
              ::close(fd);
              fd = -1;
              pthread_kill(read_thread, SIGUSR2);
            }
          }
          pthread_mutex_unlock(&writeQueueLock);
        }
      }else{
        LOG_printf("connection is not available to write\n");
      }
    }else{
      if(errno == EBADF){
        LOG_printf("connection descriptor went bad\n");
        ::close(fd);
        fd = -1;
        pthread_kill(read_thread, SIGUSR2);
      }
    }
  }
  LOG_printf("stopped writeThread\n");
}

int BufferedTransport::writeBytes(const std::vector<u8>& bytes) {
  pthread_mutex_lock(&writeQueueLock);
  // deep copy
  writeQueue.push(bytes);
  bufferSize += bytes.size();
  int retVal = bytes.size();
  time_t currTime = time(NULL);
  int timeDiff = currTime-lastBufferFullMsg;
  if(bufferSize > MaxBufferSize && fd >= 0 && timeDiff >= BufferFullTimeout){
    LOG_printf("buffer is full while connection is open\n");
    lastBufferFullMsg = currTime;
  }
  // if the buffer is full, pop the oldest data out
  while(bufferSize > MaxBufferSize){
    bufferSize -= writeQueue.front().size();
    writeQueue.pop();
  }
  pthread_mutex_unlock(&writeQueueLock);
  return retVal;
}


