// message.cpp
//
// Implementation file for Message class.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "message.h"
#include "logger.h"

#include <cstdio>
#include <cstdlib>

void Message::reset() {
  message_.clear();
}

bool Message::isValid() const {
  MessageID id = getMsgId();
  if(id == Undefined)
    return false;
  
  return true;
}

Message::MessageID Message::getMsgId(u8 id) {
  //make sure we have a known message id
  switch(id){
    case SoftReset:
    case HardReset:
    case UploadDSPImage:
    case UploadDSPConfiguration:
    case UploadSBCConfiguration:
    case UploadDatabits:
    case UploadSpooferTargetVelocity:
    case UploadSpooferAcceleration:
    case DownloadDatabits:
    case SetPowerState:
    case QueryStatus:
    case RetrieveFile:
    case ExecuteSystemCommand:
    case AssimilatorCommand:
    case ReportStatus:
    case ReportBatch:
    case ReportIQBatch:
    case TransferFile:
      return static_cast<Message::MessageID>(id);
    default:
      return Undefined;
  }
}

Message::MessageID Message::getMsgId() const {
  if(message_.size()==0)
    return Undefined;
  
  return getMsgId(message_[0]);
}

void Message::writePayloadToFile(const char* filename, const char* opts) const {
  FILE* f = fopen(filename, opts);
  if(f != NULL){
    fwrite(&message_[1], sizeof(message_[0]), message_.size()-1, f);
    fclose(f);
  }else
    LOG_printf("file could not be opened %s\n", filename);
}

void Message::getSpooferTargetVelocity(u32 *uvel) const {
  if(getMsgId() != UploadSpooferTargetVelocity || message_.size() != 17)
    return;
  
  for(u32 ii = 0;ii < 4;ii++)
    uvel[ii] = readU32(message_,ii*4+1);
}

void Message::getSpooferAcceleration(u32 *uacc) const {
  if(getMsgId() != UploadSpooferAcceleration || message_.size() != 17)
    return;
  
  for(u32 ii = 0;ii < 4;ii++)
    uacc[ii] = readU32(message_,ii*4+1);
}

bool Message::getSetPowerStateArgs(PowerState& p) const {
  if(getMsgId() != SetPowerState || message_.size() != 2)
    return false;
  
  p = static_cast<PowerState>(message_[1]);
  return true;
}

bool Message::getReportStatusArgs(u32& s) const {
  if(getMsgId() != ReportStatus || message_.size() != 5)
    return false;
  
  s = readU32(message_, 1);
  return true;
}

u32 Message::getAssimilatorCommand(AssimilatorCommandType &assimilatorCommandType) const {
  if(getMsgId() != AssimilatorCommand || message_.size() != 6) {
    assimilatorCommandType = NullACType;
    return 0;
  }
  
  assimilatorCommandType = static_cast<AssimilatorCommandType>(message_[1]);
  return readU32(message_,2);
}

bool Message::executeSystemCommand() const {
  if(getMsgId() != ExecuteSystemCommand)
    return false;

  std::string command(message_.begin()+1, message_.end());
  int i=system(command.c_str());
  
  return i==0;
}

bool Message::transferFile() const {
  if(getMsgId() != TransferFile)
    return false;
  
  u32 ii;
  for(ii=1;ii<message_.size();ii++)
    if(message_[ii] == '\n')
      break;
  
  std::string filename(message_.begin()+1, message_.begin()+ii);
  FILE* f = fopen(filename.c_str(), "w");
  if(f!=NULL){
    fwrite(&message_[ii+1], sizeof(message_[0]), message_.size()-(ii+1), f);
    fclose(f);
  }else
    LOG_printf("file could not be opened %s\n", filename.c_str());

  return true;
}

bool Message::transferFile(const std::string& filenameLocal,
                           std::string& filenameRemote) const {
  if(getMsgId() != TransferFile)
    return false;
  
  u32 ii;
  for(ii=1;ii<message_.size();ii++)
    if(message_[ii] == '\n')
      break;
    
  filenameRemote.assign(message_.begin()+1, message_.begin()+ii);
  FILE* f = fopen(filenameLocal.c_str(), "w");
  if(f!=NULL){
    fwrite(&message_[ii+1], sizeof(message_[0]), message_.size()-(ii+1), f);
    fclose(f);
  }else
    LOG_printf("file could not be opened %s\n", filenameLocal.c_str());

  return true;
}

void Message::makeSoftReset() {
  reset();
  message_.push_back(SoftReset);
}

void Message::makeHardReset() {
  reset();
  message_.push_back(HardReset);
}

void Message::makeUploadDSPImage(const std::vector<u8>& payload) {
  reset();
  message_.push_back(UploadDSPImage);
  appendVector(message_,payload);
}
  
void Message::makeUploadDSPConfiguration(const std::vector<u8>& payload) {
  reset();
  message_.push_back(UploadDSPConfiguration);
  appendVector(message_,payload);
}

void Message::makeUploadSBCConfiguration(const std::vector<u8>& payload) {
  reset();
  message_.push_back(UploadSBCConfiguration);
  appendVector(message_,payload);
}

void Message::makeUploadDatabits(const std::vector<u8>& payload) {
  reset();
  message_.push_back(UploadDatabits);
  appendVector(message_,payload);
}

void Message::makeUploadSpooferTargetVelocity(const u32 uvel[4]) {
  reset();
  message_.push_back(UploadSpooferTargetVelocity);
  for(u32 ii = 0;ii < 4;ii++)
    appendU32(message_,uvel[ii]);
}

void Message::makeUploadSpooferAcceleration(const u32 uacc[4]) {
  reset();
  message_.push_back(UploadSpooferAcceleration);
  for(u32 ii = 0;ii < 4;ii++)
    appendU32(message_,uacc[ii]);
}

void Message::makeDownloadDatabits() {
  reset();
  message_.push_back(DownloadDatabits);
}

void Message::makeDownloadDatabits(const std::vector<u8>& payload) {
  reset();
  message_.push_back(DownloadDatabits);
  appendVector(message_,payload);
}

void Message::makeSetPowerState(const PowerState p) {
  reset();
  message_.push_back(SetPowerState);
  message_.push_back(p);
}

void Message::makeQueryStatus() {
  reset();
  message_.push_back(QueryStatus);
}
  
void Message::makeReportStatus(const u32 s) {
  reset();
  message_.push_back(ReportStatus);
  appendU32(message_,s);
}

void Message::makeReportBatch(const std::vector<u8>& payload) {
  reset();
  message_.push_back(ReportBatch);
  appendVector(message_,payload);
}

void Message::makeReportIQBatch(const std::vector<u8>& payload) {
  reset();
  message_.push_back(ReportIQBatch);
  appendVector(message_,payload);
}

void Message::makeRetrieveFile(const std::string& filename) {
  reset();
  message_.push_back(RetrieveFile);
  message_.insert(message_.end(),filename.begin(),filename.end());
}

void Message::makeExecuteSystemCommand(const std::string& command) {
  reset();
  message_.push_back(ExecuteSystemCommand);
  message_.insert(message_.end(),command.begin(),command.end());
}

void Message::makeAssimilatorCommand(const AssimilatorCommandType assimilatorCommandType,
                                     const u32 val = 0) {
  reset();
  message_.push_back(AssimilatorCommand);
  message_.push_back(assimilatorCommandType);
  appendU32(message_,val);
}

void Message::makeTransferFile(const std::string& filename) {
  reset();
  message_.push_back(TransferFile);
  FILE* f = fopen(filename.c_str(), "r");
  if(f!=NULL){
    message_.insert(message_.end(),filename.begin(),filename.end());
    message_.push_back('\n');
    int c;
    while((c=fgetc(f))!=EOF)
      message_.push_back(c);
    fclose(f);
  }
}

void Message::makeTransferFile(const std::string& filenameRemote,
                               const std::string& filenameLocal) {
  reset();
  message_.push_back(TransferFile);
  FILE* f = fopen(filenameLocal.c_str(), "r");
  if(f!=NULL){
    message_.insert(message_.end(),filenameRemote.begin(),filenameRemote.end());
    message_.push_back('\n');
    int c;
    while((c=fgetc(f))!=EOF)
      message_.push_back(c);
    fclose(f);
  }
}

void Message::appendU32(std::vector<u8>& m, u32 v) {
  m.push_back(v>>24);
  m.push_back((v>>16)&0xFF);
  m.push_back((v>>8)&0xFF);
  m.push_back(v&0xFF);
}

void Message::appendU16(std::vector<u8>& m, u16 v) {
  m.push_back(v>>8);
  m.push_back(v&0xFF);
}

void Message::appendVector(std::vector<u8>& m, const std::vector<u8>& p) {
  m.insert(m.end(), p.begin(), p.end());
}

u32 Message::readU32(const std::vector<u8>& m, u32 i) {
  u32 s = m[i++]<<24;
  s += m[i++]<<16;
  s += m[i++]<<8;
  s += m[i++];
  return s;
}

u16 Message::readU16(const std::vector<u8>& m, u32 i) {
  u16 s = m[i++]<<8;
  s += m[i++];
  return s;
}
