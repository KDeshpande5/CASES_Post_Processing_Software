// serialtransport.cpp
//
// Implementation file for SerialTransport class.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "serialtransport.h"
#include "logger.h"

#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <cstdlib>
#include <cstring>
#include <cstdio>

SerialTransport::SerialTransport(std::string devname) {
  fd = open(devname.c_str(), O_RDWR);
  
  if(fd<0){
    pabort("could not open serial port");
  }
  
  termios attr;
  tcgetattr( fd, &attr );
  cfmakeraw( &attr ); // allows binary streams
  attr.c_cc[VMIN]  = 1; // min number of chars
  attr.c_cc[VTIME] = 1; // interchar timeout
  tcsetattr( fd, TCSANOW, &attr );
}

SerialTransport::~SerialTransport() {
  ::close(fd);
}
