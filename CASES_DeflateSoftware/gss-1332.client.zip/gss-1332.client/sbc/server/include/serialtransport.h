// serialtransport.h
//
// Implements the serial transport layer.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __SERIAL_TRANSPORT_GRID_H
#define __SERIAL_TRANSPORT_GRID_H

#include "transport.h"
#include <string>

class SerialTransport : public BufferedTransport {
public:
  SerialTransport(std::string devname);
  ~SerialTransport();
};

#endif
