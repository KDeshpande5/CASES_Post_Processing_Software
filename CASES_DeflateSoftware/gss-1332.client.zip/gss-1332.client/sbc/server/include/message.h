// message.h
//
// Structure defintions for messages in CASES interface.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf 

#ifndef __MESSAGE_GRID_H
#define __MESSAGE_GRID_H

#include <typedefs.h>
#include "signaltype.h"
#include <vector>
#include <string>

class Message {
public:
  enum MessageID {
    Undefined = 0x00,
    SoftReset = 0x01,
    HardReset = 0x02,
    UploadDSPImage = 0x10,
    UploadDSPConfiguration = 0x11,
    UploadSBCConfiguration = 0x12,
    UploadDatabits = 0x13,
    UploadSpooferTargetVelocity = 0x14,
    UploadSpooferAcceleration = 0x15,
    DownloadDatabits = 0x18,
    SetPowerState = 0x20,
    QueryStatus = 0x30,
    RetrieveFile = 0x38,
    ExecuteSystemCommand = 0x40,
    AssimilatorCommand = 0x41,
    ReportStatus = 0x80,
    ReportBatch = 0x88,
    ReportIQBatch = 0x89,
    TransferFile = 0xE0
  };
  
  enum AssimilatorCommandType {
    NullACType = 0x00,
    DbmStatus = 0x01,
    ZeroSpooferTargetVelocity = 0x02,
    PhaseLockStatus = 0x03,
    FeedbackStatus = 0x04,
    SetAttenuationLevel = 0x05,
    EqualizeAmplitudeStatus = 0x06,
    ProgramPllSynthesizer = 0x07,
    NumSpoofChan = 0x08,
    SwapSvId = 0x09
  };

  enum PowerState {
    Sleep = 0,
    Low = 1,
    Intermediate = 2,
    Full = 3
  };

  enum StatusFlagBitIndex {
    InstrumentHealthy = 0,
    UnusualTecValuesDetected = 1,
    ScintillationDetected = 2,
    InvalidMessageDetected = 3,
    FlashActive = 4,
    FlashSetupFailed = 5,
    FlashFailed = 6,
    DspNotAcknowledgingSync = 7,
    NotSyncedWithDsp = 8
  };
  
  Message() { reset(); }  
  void reset();
  static MessageID getMsgId(u8 id);
  
  MessageID getMsgId() const;
  bool isValid() const;
  std::vector<u8>& getMutableBytes() { return message_; }
  const std::vector<u8>& getBytes() const { return message_; }
  void writePayloadToFile(const char* filename, const char* opts) const;
  void getSpooferTargetVelocity(u32 *uvel) const;
  void getSpooferAcceleration(u32 *uacc) const;
  bool getSetPowerStateArgs(PowerState& p) const;
  bool getReportStatusArgs(u32& s) const;
  u32 getAssimilatorCommand(AssimilatorCommandType &assimilatorCommandType) const;
  bool executeSystemCommand() const;
  bool transferFile() const;
  bool transferFile(const std::string& filenameLocal,
                    std::string& filenameRemote) const;
  
  // Create messages using these functions
  void makeFromBytes(const std::vector<u8>& m) { message_ = m; }
  void makeSoftReset();
  void makeHardReset();
  void makeUploadDSPImage(const std::vector<u8>& payload);
  void makeUploadDSPConfiguration(const std::vector<u8>& payload);
  void makeUploadSBCConfiguration(const std::vector<u8>& payload);
  void makeUploadDatabits(const std::vector<u8>& payload);
  void makeUploadSpooferTargetVelocity(const u32 uvel[4]);
  void makeUploadSpooferAcceleration(const u32 uacc[4]);
  void makeDownloadDatabits();
  void makeDownloadDatabits(const std::vector<u8>& payload);
  void makeSetPowerState(const PowerState p);
  void makeQueryStatus();
  void makeRetrieveFile(const std::string& filename);
  void makeExecuteSystemCommand(const std::string& command);
  void makeAssimilatorCommand(const AssimilatorCommandType assimilatorCommandType,
                              const u32 val);
  void makeReportStatus(const u32 s);
  void makeReportBatch(const std::vector<u8>& payload);
  void makeReportIQBatch(const std::vector<u8>& payload);
  void makeTransferFile(const std::string& filename);
  void makeTransferFile(const std::string& filenameRemote,
                        const std::string& filenameLocal);
  
  static void appendU32(std::vector<u8>& m, u32 v);
  static void appendU16(std::vector<u8>& m, u16 v);
  static void appendVector(std::vector<u8>& m, const std::vector<u8>& p);
  static u32 readU32(const std::vector<u8>& m, u32 i = 0);
  static u16 readU16(const std::vector<u8>& m, u32 i = 0);
  
private:
  
  std::vector<u8> message_;
};

#endif
