// networktransport.h
//
// Implements the network transport layer.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __NETWORK_TRANSPORT_GRID_H
#define __NETWORK_TRANSPORT_GRID_H

#include "transport.h"

class NetworkTransport : public BufferedTransport {
public:
  NetworkTransport(u16 port);
  ~NetworkTransport();
  
  virtual bool accept();
  
private:
  int sock;
};

#endif
 
