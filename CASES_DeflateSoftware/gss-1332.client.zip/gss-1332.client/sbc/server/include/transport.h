// transport.h
//
// Defines an interface for different transport layers.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __TRANSPORT_GRID_H
#define __TRANSPORT_GRID_H

#include <typedefs.h>
#include <queue>
#include <vector>
#include <pthread.h>
#include <ctime>

#include "message.h"

class Transport {
public:
  Transport() {}
  virtual ~Transport() {}
  
  virtual bool accept() { return true; }
  
  virtual int readMessage(Message& m) = 0;
  virtual int writeMessage(const Message& m) = 0;
};

class FileTransport : public Transport {
public:
  FileTransport();
  virtual ~FileTransport();
  
  int readMessage(Message& m);
  int writeMessage(const Message& m);
  int get_fd() { return fd; }
  
  static u16 computeChecksum(const std::vector<u8>& m) {
    return computeChecksum(m.begin(), m.size());
  }
  static u16 computeChecksum(std::vector<u8>::const_iterator str, u32 nbytes);
  
protected:
  virtual int readBytes(std::vector<u8>& bytes, int numBytes);
  virtual int writeBytes(const std::vector<u8>& bytes);
  
  int fd;
  
private:
  int readMessage(std::vector<u8>& m);
  
  pthread_mutex_t writeLock;
  pthread_mutex_t readLock;
};

class BufferedTransport : public FileTransport {
public:
  BufferedTransport();
  virtual ~BufferedTransport();
  
protected:
  virtual int readBytes(std::vector<u8>& bytes, int numBytes);
  virtual int writeBytes(const std::vector<u8>& bytes);
  
private:
  void writeThread();
  static void* runWriteThread(void *arg);
  
  std::queue<std::vector<u8> > writeQueue;
  pthread_mutex_t writeQueueLock;
  pthread_t id, read_thread;
  bool isAlive;
  s32 bufferSize;
  time_t lastBufferFullMsg;
};

#endif
