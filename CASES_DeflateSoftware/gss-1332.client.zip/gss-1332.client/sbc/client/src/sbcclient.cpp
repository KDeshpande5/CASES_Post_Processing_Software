// sbcclient.cpp
//
// Implements the CASES interface on the host computer.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf 

#include "sbcclient.h"
#include "networksplittertransport.h"

#include <fstream>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <signal.h>
#include <time.h>

#include <logger.h>
#include <signaltype.h>

#include "Exception.hpp"
#include "StringUtils.hpp"


//======= File scope variables
const std::string gProgramName("sbcclient");
const std::string gVersionNumber("1.2.0"); 
const std::string gMaintainerEmail("todd.humphreys@mail.utexas.edu");
SbcClient * gClient = NULL;

//======= Prototypes
void sighandler(int sig);
void* readThreadHelper(void* arg);
void* listenThreadHelper(void* arg);

const char * skipSpaces(const char * str) {
  while(*str == ' ')
    str++;
  return str;
}

const char * get_arg(const char * str, std::string& arg) {
  const char * strbegin = str;
  if(*str == '\"') {
    while(*str != '\"' && *str != '\0') 
      str++;
    arg.assign(strbegin+1, str);
  } else {
    while(*str != ' ' && *str != '\n' && *str != '\0') 
      str++;
    arg.assign(strbegin, str);
  }
  return skipSpaces(str);
}

SbcClient::SbcClient(char* arg0)
  : GRIDFramework(arg0,"Interface for the CASES receiver on a host computer",
                  gProgramName, gVersionNumber, gMaintainerEmail),
    outputFileOption_('o',"output-file","Specify name of output binary file"),
    outputIQFileOption_('q',"output-iq-file","Specify name of output IQ binary file"),
    serialTransportOption_('s',"serial","Setup a serial connection for communication"
                                        " ARG=PORT"),
    networkTransportOption_('n',"network","Setup a network connection for commmunication"
                                          " ARG=IP:PORT"),
    networkListenOption_('l',"listen","Listen for a network connection to forward data"
                                      " ARG=PORT"),
    readOnlyOption_('r',"read-only","Forces connection to be read-only (useful"
                        " when reading from a file)"),
    root_("SBC Client Commands:", "")
{
  outputFileOption_.setMaxCount(1);
  outputIQFileOption_.setMaxCount(1);
  serialTransportOption_.setMaxCount(1);
  networkTransportOption_.setMaxCount(1);
  networkListenOption_.setMaxCount(1);
  readOnlyOption_.setMaxCount(1);
  
  alive_ = true;
  running_ = true;
  transport_ = NULL;
  ftransport_ = NULL;
  
  SuperCommand * super;
  
  root_.add(new ExecutableCommand("help", "",
                                  "display this help message",
                                  this,
                                  &SbcClient::help));
  root_.add(new ExecutableCommand("sleep", "[TIME]",
                                  "wait for a number of seconds to elapse before continuing excecution",
                                  this,
                                  &SbcClient::sleep));
  root_.add(new ExecutableCommand("kill", "",
                                  "terminate the connection to the sbc and exit",
                                  this,
                                  &SbcClient::kill));
  root_.add(new ExecutableCommand("script", "[FILENAME]",
                                  "run a set of commands consecutively from the input file",
                                  this,
                                  &SbcClient::script));
  root_.add(new ExecutableCommand("pow", "[LEVEL]",
                                  "set the power state of the SBC (0-3 with 3->FULL and 0->SLEEP)",
                                  this,
                                  &SbcClient::power_state));
  root_.add(new ExecutableCommand("query", "",
                                  "request a status message from the SBC server",
                                  this,
                                  &SbcClient::query));
  root_.add(new ExecutableCommand("system", "[CMD]",
                                  "execute a system command on the SBC",
                                  this,
                                  &SbcClient::execute_sys_cmd));
  root_.add(new ExecutableCommand("lsystem", "[CMD]",
                                  "execute a command on the system this instance of sbcclient is running on.",
                                  this,
                                  &SbcClient::execute_local_cmd));

  super = new SuperCommand("file", "SBC file transfer operations");
  super->add(new ExecutableCommand("get", "[REMOTE FILENAME] [LOCAL FILENAME]",
                                   "get a file from the SBC",
                                   this,
                                   &SbcClient::file_get));
  super->add(new ExecutableCommand("put", "[LOCAL FILENAME] [REMOTE FILENAME]",
                                   "put a file on the SBC",
                                   this,
                                   &SbcClient::file_put));
  root_.add(super);
  
  super = new SuperCommand("reset", "reset the DSP with the following options:");
  super->add(new ExecutableCommand("soft", "",
                                   "a soft reset",
                                   this,
                                   &SbcClient::soft_reset));
  super->add(new ExecutableCommand("hard", "",
                                   "a hard reset",
                                   this,
                                   &SbcClient::hard_reset));
  root_.add(super);
  
  super = new SuperCommand("upload", "upload data to the SBC/DSP with the following options:");
  super->add(new ExecutableCommand("dspimg", "[FILENAME]",
                                   "flash a new image to the DSP",
                                   this,
                                   &SbcClient::upload_DSP_image));
  super->add(new ExecutableCommand("dspconfig", "[FILENAME]",
                                   "send a new dspconfig file to the SBC",
                                   this,
                                   &SbcClient::upload_DSP_config));
  super->add(new ExecutableCommand("sbcconfig", "[FILENAME]",
                                   "send a new sbcconfig file to the SBC",
                                   this,
                                   &SbcClient::upload_SBC_config));
  super->add(new ExecutableCommand("databits", "[FILENAME]",
                                   "send databits to the databit manager",
                                   this,
                                   &SbcClient::upload_data_bits));
  root_.add(super);                                 
  
  super = new SuperCommand("download", "download data from the SBC/DSP with the following options:");
  super->add(new ExecutableCommand("databits", "[FILENAME]",
                                   "retrieve the databits from the databit manager",
                                   this,
                                   &SbcClient::download_databits));
  root_.add(super);
}

SbcClient::~SbcClient(){}

void SbcClient::additionalSetup() {
  // store the output file names
  outputFile_set = false;
  outputIQFile_set = false;
  readOnly_ = false;
  listen_ = false;
  
  if(outputFileOption_.getCount()) {
     outputFile_ = outputFileOption_.getValue()[0];
     outputFile_set = true;
  }

  if(outputIQFileOption_.getCount()) {
    outputIQFile_ = outputIQFileOption_.getValue()[0];
    outputIQFile_set = true;
  }
  
  if(readOnlyOption_.getCount()) {
    readOnly_ = true;
  }
  
  if(networkListenOption_.getCount()) {
    listen_ = true;
  }
}

void SbcClient::spinUp() {
  writeThread_ = pthread_self();
  
  signal(SIGPIPE, SIG_IGN);
  signal(SIGINT, sighandler);
  signal(SIGUSR2, sighandler);
  
  if(serialTransportOption_.getCount() == 1 
    && networkTransportOption_.getCount() == 0) {
    // setup serial transport
    transport_ = new SerialTransport(&(serialTransportOption_.getValue()[0][0]));
  }
  else if(networkTransportOption_.getCount() == 1
    && serialTransportOption_.getCount() == 0) {
    // setup network transport
    transport_ = new NetworkClientTransport(&(networkTransportOption_.getValue()[0][0]));
  }
  else {
    printf("must initialize either a serial or network transport\n");
    exit(EXIT_FAILURE);
  }
  
  if(!readOnly_){
    if(pthread_create(&readThread_,NULL,readThreadHelper,this)!=0){
      delete transport_;
      exit(EXIT_FAILURE);
    }
  }
  
  if(listen_){
    ftransport_ = new NetworkSplitterTransport(
      gpstk::StringUtils::asInt(networkListenOption_.getValue()[0]));
    pthread_create(&listenThread_,NULL,listenThreadHelper,this);
  }
}

void SbcClient::process() {
  if(readOnly_){
    alive_ = false;
    readThread();
  }else{
    char inpLine[InpLineBuffSize];
    
    printf(">> ");
    fflush(stdout);
    while(running_){
      if(fgets(inpLine,InpLineBuffSize,stdin) == NULL) {
        usleep(100000);
        continue;
      }
      root_.parse(skipSpaces(inpLine));
      
      printf(">> ");
      fflush(stdout);
    }
  }
}

void SbcClient::shutDown() {
  if(!readOnly_){
    alive_ = false;
    pthread_kill(readThread_, SIGUSR2);
    pthread_join(readThread_, NULL);
    if(listen_){
      pthread_kill(listenThread_, SIGUSR2);
      pthread_join(listenThread_, NULL);
    }
  }
  
  delete transport_;
  delete ftransport_;
}

void SbcClient::help(const char * str) {
  //print help info
  root_.printHelp(1);
  printf("\n");
}

void SbcClient::sleep(const char * str) {
  // wait for a number of seconds
  u32 t = atoi(str);
  printf("\tsleeping for %d s\n\n",t);
  usleep(t*1000000);
}

void SbcClient::kill(const char * str) {
  //terminate the connection
  running_ = false;
  printf("\tquitting...\n\n");
}

void SbcClient::script(const char * str) {
  // run a script with sbcclient commands
  FILE* f;
  std::string fileName;
  char inpLine[InpLineBuffSize];
  
  // open script
  str = get_arg(str, fileName);
  f = fopen(fileName.c_str(), "r");
  if(f == NULL){
    printf("\tcould not open file %s\n\n", str);
    return;
  }
  
  // read/excecute script
  while(running_) {
    if(fgets(inpLine,InpLineBuffSize,f) == NULL)
      return;
    
    root_.parse(skipSpaces(inpLine));
  }
}

void SbcClient::query(const char * str) {
  writeM_.makeQueryStatus();
  transport_->writeMessage(writeM_);
  printf("\tsent query status\n\n");
}

void SbcClient::soft_reset(const char * str) {
  //soft reset
  writeM_.makeSoftReset();
  transport_->writeMessage(writeM_);
  printf("\tsent soft reset\n\n");
}

void SbcClient::hard_reset(const char * str) {
  //hard reset 
  writeM_.makeHardReset();
  transport_->writeMessage(writeM_);
  printf("\tsent hard reset\n\n");
}

void SbcClient::upload_DSP_image(const char * str) {
  //load image
  if(!read_file_to_payload(str))
    return;
  
  //send message
  writeM_.makeUploadDSPImage(payload_);
  transport_->writeMessage(writeM_);
  printf("\tsent DSP image\n\n");
}

void SbcClient::upload_DSP_config(const char * str) {
  //load DSP config file
  if(!read_file_to_payload(str))
    return;
  
  //send message
  writeM_.makeUploadDSPConfiguration(payload_);
  transport_->writeMessage(writeM_);
  printf("\tsent DSP config\n\n");
}

void SbcClient::upload_SBC_config(const char * str) {
  //load SBC config file
  if(!read_file_to_payload(str))
    return;
  
  //send message
  writeM_.makeUploadSBCConfiguration(payload_);
  transport_->writeMessage(writeM_);
  printf("\tsent SBC config\n\n");
}

void SbcClient::upload_data_bits(const char * str) {
  //load data bits
  if(!read_file_to_payload(str))
    return;
  
  //send message
  writeM_.makeUploadDatabits(payload_);
  transport_->writeMessage(writeM_);
  printf("\tsent data bits\n\n");
}

void SbcClient::power_state(const char * str) {
  Message::PowerState s;
  
  if(*str == '\0') return;
  
  //read state
  switch(atoi(str)) {
    case Message::Sleep:
      s = Message::Sleep;
      break;
    case Message::Low:
      s = Message::Low;
      break;
    case Message::Intermediate:
      s = Message::Intermediate;
      break;
    case Message::Full:
    default:
      s = Message::Full;
      break;
  }  
  
  //send message
  writeM_.makeSetPowerState(s);
  transport_->writeMessage(writeM_);
  printf("\tsent set power state\n\n");
}

void SbcClient::execute_sys_cmd(const char * str) {
  if(*str == '\0') return;
  
  //send message
  writeM_.makeExecuteSystemCommand(str);
  transport_->writeMessage(writeM_);
  printf("\tsent execute system command\n\n");
}

void SbcClient::execute_local_cmd(const char* str){
  if(*str=='\0') return;

  std::system(str);
}

bool SbcClient::read_file_to_payload(const char * str) {
  FILE* f;
  u32 r;
  char fileBuff[FileBuffSize];
  std::string fileName;
  
  if(*str == '\0') return false;
  str = get_arg(str, fileName);
  
  f = fopen(fileName.c_str(), "r");
  if(f == NULL){
    printf("\tcould not open file %s\n", str);
    return false;
  }
  r = FileBuffSize;
  payload_.clear();
  while(r==FileBuffSize){
    r = fread(fileBuff, sizeof(fileBuff[0]), FileBuffSize, f);
    if(r>0)
      payload_.insert(payload_.end(), fileBuff, fileBuff+r);
  }
  fclose(f);

  return true;
}

void SbcClient::download_databits(const char * str) {
  if(*str == '\0') return;
  //store output filename for later use
  str = get_arg(str, databitFileName_);
  
  writeM_.makeDownloadDatabits();
  transport_->writeMessage(writeM_);
  printf("\tsent request for data bits\n\n");
}

void SbcClient::file_get(const char * str) {
  std::string remoteFile;
  if(*str == '\0') return;  
  str = get_arg(str, remoteFile);
  //store output filename for later use
  if(*str == '\0') return;
  str = get_arg(str, fileTransferFileName_);
  
  //send message
  writeM_.makeRetrieveFile(remoteFile);
  transport_->writeMessage(writeM_);
  printf("\tsent file get\n\n");
}

void SbcClient::file_put(const char * str) {
  std::string localFile, remoteFile;
  if(*str == '\0') return;  
  str = get_arg(str, localFile);
  if(*str == '\0') return;
  str = get_arg(str, remoteFile);
    
  //send message
  writeM_.makeTransferFile(remoteFile, localFile);
  transport_->writeMessage(writeM_);
  printf("\tsent file put\n\n");
}

void SbcClient::listenThread() {
  Message m;

  while(running_){
    if(ftransport_->accept())
      printf("\n\taccepted a forwarding connection\n");
  }
  
  while(alive_)
    usleep(25000);
}

void sighandler(int sig) {
  signal(sig, SIG_IGN);
  if(sig == SIGINT && gClient)
    gClient->kill("");
  signal(sig, sighandler);
}

void* readThreadHelper(void* arg){
  reinterpret_cast<SbcClient*>(arg)->readThread();
  return NULL;
}

void* listenThreadHelper(void* arg){
  reinterpret_cast<SbcClient*>(arg)->listenThread();
  return NULL;
}

void SbcClient::readThread() {
  while(running_){
    std::string remoteFile;
    Message readM;
    u32 rxStatus;
    int status;
    
    int isValid = transport_->readMessage(readM);
    
    if(!(isValid==0))
      break;
      
    if(!readM.isValid())
      continue;
    
    if (!outputFile_set || !outputIQFile_set){
      time_t rawtime;
      tm * ptm;
      rawtime = time(NULL);
      ptm = gmtime(&rawtime);
      char buffer[256];
      if (!outputFile_set){
        sprintf(buffer,"dataout_%04i_%03i.bin",ptm->tm_year+1900,ptm->tm_yday+1);
        outputFile_ = buffer;
      }
      if (!outputIQFile_set){
        sprintf(buffer,"dataoutiq_%04i_%03i.bin",ptm->tm_year+1900,ptm->tm_yday+1);
        outputIQFile_ = buffer;
      }
    }
    
    Message::MessageID id = readM.getMsgId();
    switch(id) {
      case Message::ReportStatus:
        readM.getReportStatusArgs(rxStatus);
        printf("\n\tMessage is ReportStatus: %d.\n\n>> ", rxStatus);
        fflush(stdout);
        break;
      case Message::ReportBatch:
        readM.writePayloadToFile(outputFile_.c_str(), "a");
        if(ftransport_)
          status = ftransport_->writeMessage(readM);
        break;
      case Message::ReportIQBatch:
        readM.writePayloadToFile(outputIQFile_.c_str(), "a");
        if(ftransport_)
          status = ftransport_->writeMessage(readM);
        break;
      case Message::DownloadDatabits:
        readM.writePayloadToFile(databitFileName_.c_str(), "w");
        printf("\n\tReceived Databit Database.\n\n>> ");
        fflush(stdout);
        break;
      case Message::TransferFile:
        readM.transferFile(fileTransferFileName_, remoteFile);
        printf("\n\tReceived remote file %s from the SBC and stored to local file %s.\n\n>> ",
               remoteFile.c_str(), fileTransferFileName_.c_str());
        fflush(stdout);
        break;
      default:
        break;
    }
  }
  
  running_ = false;
  pthread_kill(writeThread_, SIGUSR2);
  printf("\n\tconnection killed\n\n");
  
  while(alive_)
    usleep(25000);
}

int main(int argc, char* argv[]){
  try {
    SbcClient sbcclient(argv[0]);
    gClient = &sbcclient;
    if (!sbcclient.initialize(argc, argv))
      return 0;
    if (!sbcclient.run())
      return 1;
      
    return 0;
  }
  catch(gpstk::Exception& e) {
    std::cout << e << std::endl;
  }
  catch(std::exception& e) {
    std::cout << e.what() << std::endl;
  }
  catch(...) {
    std::cout << "unknown error" << std::endl;
  }
  return 0;
}



