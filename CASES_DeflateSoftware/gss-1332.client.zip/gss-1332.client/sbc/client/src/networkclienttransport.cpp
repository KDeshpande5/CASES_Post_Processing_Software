// networkclienttransport.cpp
//
// Implementation file for NetworkTransport class.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf
 
#include "networkclienttransport.h"
#include "logger.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include <cstdlib>
#include <cstring>

#include <unistd.h>

#define BUFFER_SIZE 1024

NetworkClientTransport::NetworkClientTransport(const char* dest) {
  char * hostname = NULL;
  char * servname = NULL;
  
  char buffer[BUFFER_SIZE+1] = {0};
  strncpy(buffer, dest, BUFFER_SIZE);
  
  hostname = buffer;
  
  int i = 0;
  while(buffer[i]!=':'&&buffer[i]!=0){
    i++;
  }
  if(buffer[i]==0){
    pabort("malformed address, no colon separator found");
    /* ERROR */
  }
  buffer[i] = 0;
  servname = &buffer[++i];
  
  struct addrinfo hints, *res, *res0;
  int error;
  const char *cause = NULL;

  memset(&hints, 0, sizeof(hints));
  hints.ai_family = PF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  error = getaddrinfo(hostname, servname, &hints, &res0);
  if (error) {
    pabort(gai_strerror(error));
    /*NOTREACHED*/
  }
  fd = -1;
  for (res = res0; res; res = res->ai_next) {
    fd = socket(res->ai_family, res->ai_socktype,
        res->ai_protocol);
    if (fd < 0) {
      cause = "could not create socket";
      continue;
    }


    if (connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
      cause = "socket could not connect";
      ::close(fd);
      fd = -1;
      continue;
    }

    break;  /* okay we got one */
  }
  if (fd < 0) {
    pabort(cause);
    /*NOTREACHED*/
  }
  freeaddrinfo(res0);
}

NetworkClientTransport::~NetworkClientTransport() {
  ::close(fd);
}
