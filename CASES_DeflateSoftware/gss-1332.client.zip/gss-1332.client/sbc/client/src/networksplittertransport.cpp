// networksplittertransport.cpp
//
// Implements the network splitter transport layer.
//
// Copyright (c) 2011 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#include "networksplittertransport.h"
#include "logger.h"

#include <unistd.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include <cstdlib>
#include <cstring>
#include <cstdio>

PrivateTransport::~PrivateTransport() {
  printf("\n\tforwarding connection killed\n");
  ::close(fd);
}

NetworkSplitterTransport::NetworkSplitterTransport(u16 port) {
  sock = socket(AF_INET, SOCK_STREAM, 0);
  if(sock<0){
    pabort("could not open server socket");
  }
  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(port);
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  
  if(bind(sock, (struct sockaddr *) &addr, sizeof(addr))<0){
    pabort("could not bind server socket");
  }
  
  if(listen(sock, SOMAXCONN)<0){
    pabort("could not listen on server socket");
  }
}

NetworkSplitterTransport::~NetworkSplitterTransport() {
  while(!tVec_.empty()){
    delete tVec_.front();
    tVec_.pop_front();
  }
  ::close(sock);
}

bool NetworkSplitterTransport::accept() {
  int fd = ::accept(sock, NULL, NULL);
  if(fd>=0) {
    tVec_.push_back(new PrivateTransport(fd));
    return true;
  }
  return false;
}

int NetworkSplitterTransport::readMessage(Message& m) {
  return 0;
}

int NetworkSplitterTransport::writeMessage(const Message& m) {
  std::list<PrivateTransport*>::iterator it;
  for(it=tVec_.begin(); it!=tVec_.end();){
    PrivateTransport* t = *it;
    if(t->get_fd()<0){
      delete t;
      it = tVec_.erase(it);
    }else{
      t->writeMessage(m);
      it++;
    }
  }
  return m.getBytes().size();
}

