// sbcclient.h
//
// Implements the CASES interface on the host computer.
//
// Copyright (c) 2010 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf 

#ifndef __SBC_CLIENT_H
#define __SBC_CLIENT_H

#include "gridframework.h"
#include "serialtransport.h"
#include "networkclienttransport.h"
#include "networktransport.h"
#include "message.h"
#include <vector>
#include <pthread.h>
#include <string>
#include <cstring>
#include <cstdio>
#include <time.h>

class SbcClient;

typedef void (SbcClient::*SbcClientCommand)(const char * str); 
const char * skipSpaces(const char * str);

class Command {
public:
  Command(const std::string& name,
          const std::string& args,
          const std::string& help)
    : name_(name), args_(args), help_(help) {}
  virtual ~Command() {}
  const std::string& name() const { return name_; }
  const std::string& help() const { return help_; }
  virtual void printHelp(int spaces) {
    for(s32 ii=0; ii<spaces; ii++)
      printf(" ");
    printf(name_.c_str());
    if(args_.size()>0){
      printf(" ");
      printf(args_.c_str());
    }
    if(help_.size()>0){
      printf(" - ");
      printf(help_.c_str());
    }
    printf("\n");
  }
  virtual void parse(const char * str) = 0;
private:
  std::string name_;
  std::string args_;
  std::string help_;
};

class SuperCommand : public Command {
public:
  SuperCommand(const std::string& name,
               const std::string& help)
    : Command(name, "", help) {}
  ~SuperCommand() {
    while(!cmds_.empty()) {
      delete cmds_.back();
      cmds_.pop_back();
    }
  }
  void add(Command * cmd) {
    cmds_.push_back(cmd);
  }
  virtual void printHelp(int spaces) {
    Command::printHelp(spaces);
    for(u32 ii=0; ii<cmds_.size(); ii++) {
      cmds_[ii]->printHelp(spaces+5);
    }
  }
  virtual void parse(const char * str) {
    bool found = false;
    for(u32 ii=0; ii<cmds_.size() && !found; ii++) {
      const std::string& name = cmds_[ii]->name();
      if(strncmp(str,name.c_str(),name.size())==0) {
        cmds_[ii]->parse(skipSpaces(str + name.size()));
        found = true;
      }
    }
    if(!found) {
      printf("\tunrecognized command or option\n\n");
    }
  }
private:
  std::vector<Command*> cmds_;
};

class ExecutableCommand : public Command {
public:
  ExecutableCommand(const std::string& name,
                    const std::string& args,
                    const std::string& help,
                    SbcClient * client,
                    SbcClientCommand cmd)
    : Command(name, args, help),
      client_(client),
      cmd_(cmd) {}
  virtual void parse(const char * str) {
    ((*client_).*cmd_)(str);
  } 
private:
  SbcClient * client_;
  SbcClientCommand cmd_;
};

class SbcClient : public GRIDFramework {
  public:
    enum {InpLineBuffSize = 256, FileBuffSize = 1024*16};
    
    SbcClient(char* arg0);
    ~SbcClient();
    
    void listenThread();
    void readThread();
    
    void help(const char * str);
    void sleep(const char * str);
    void kill(const char * str);
    void script(const char * str);
    void power_state(const char * str);
    void query(const char * str);
    void soft_reset(const char * str);
    void hard_reset(const char * str);
    void upload_DSP_image(const char * str);
    void upload_DSP_config(const char * str);
    void upload_SBC_config(const char * str);
    void upload_data_bits(const char * str);
    void download_databits(const char * str);
    void execute_sys_cmd(const char * str);
    void execute_local_cmd(const char* str);
    void file_get(const char * str);
    void file_put(const char * str);

  protected:
    virtual void additionalSetup();
    virtual void spinUp();
    virtual void process();
    virtual void shutDown();
    bool read_file_to_payload(const char * str);
    
  private:
    gpstk::CommandOptionWithAnyArg outputFileOption_, outputIQFileOption_,
    serialTransportOption_, networkTransportOption_, networkListenOption_;
    gpstk::CommandOptionNoArg readOnlyOption_;
    // transportation class for sending and receiving data to and from the SBC
    Transport* transport_;
    // forward data to another client
    Transport* ftransport_;
    bool readOnly_;
    bool listen_;
    bool running_;
    bool alive_;
    // file to write databits to
    std::string databitFileName_;
    std::string fileTransferFileName_;
    // read/write threads
    pthread_t readThread_;
    pthread_t writeThread_;
    pthread_t listenThread_;
    // read/write messages
    Message readM_;
    Message writeM_;
    std::vector<u8> payload_;
    SuperCommand root_;
    // output files
    std::string outputFile_;
    std::string outputIQFile_;
    bool outputFile_set;
    bool outputIQFile_set;
};

#endif
