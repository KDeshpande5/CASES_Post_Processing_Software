// networksplittertransport.h
//
// Defines the network splitter transport layer.
//
// Copyright (c) 2011 The GRID Software Project. All rights reserved.  Use of
// this source code is governed by the license dsprx/doc/GRID_LICENSE.pdf

#ifndef __NETWORK_SPLITTER_TRANSPORT_GRID_H
#define __NETWORK_SPLITTER_TRANSPORT_GRID_H

#include "transport.h"

#include <list>

class PrivateTransport : public BufferedTransport {
public:
  PrivateTransport(int fd) { this->fd = fd; }
  ~PrivateTransport();
};  

class NetworkSplitterTransport : public Transport {
public:
  NetworkSplitterTransport(u16 port);
  ~NetworkSplitterTransport();
  
  virtual bool accept();
  
  virtual int readMessage(Message& m);
  virtual int writeMessage(const Message& m);
  
private:
  std::list<PrivateTransport*> tVec_;
  
  int sock;
};

#endif
 
